# Dataset Download Link
Due to the large size of the ICFG graphs and processed path embeddings, please download the datasets from the following Google Drive link:
[https://drive.google.com/drive/folders/interfuse]

Once downloaded, extract the files so that `train.jsonl` and `test.jsonl` are located directly in this directory.
