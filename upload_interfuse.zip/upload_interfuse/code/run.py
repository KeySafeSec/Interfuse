# run.py (V5.0 - Hierarchical Context Fusion)

from __future__ import absolute_import, division, print_function
import time
from collections import Counter, defaultdict
import hashlib
import json
import os
import pickle
from functools import partial
import argparse
import logging
import random
import re
from concurrent.futures import ProcessPoolExecutor
import sys
import multiprocessing

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler, Subset
from torch.cuda import amp
from sklearn.metrics import recall_score, precision_score, f1_score, accuracy_score, roc_auc_score, confusion_matrix
from tqdm import tqdm, trange
from transformers import (
    AdamW, get_linear_schedule_with_warmup,
    RobertaConfig, RobertaModel, RobertaTokenizerFast
)
# ensure model.py has also been updated to V5.0
from model import Model

# --- global configuration ---
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"
if torch.cuda.is_available():
    torch.cuda.empty_cache()
os.environ["TOKENIZERS_PARALLELISM"] = "false"
MODEL_CLASSES = {'unixcoder': (RobertaConfig, RobertaModel, RobertaTokenizerFast)}

# ✨ V5.0 upgrade: semantic feature engineering with risk-level categorization
danger_op_keywords = {
    # very high-risk memory/string functions
    "strcpy", "strncpy", "sprintf", "vsprintf", "strcat", "strncat", "gets",
    # command injection
    "system", "popen", "exec", "execve",
    # SQL injection
    "mysql_query", "sqlite3_exec", "pqexec"
}
pointer_op_keywords = {
    # memory allocation/deallocation
    "malloc", "calloc", "realloc", "free", "alloca", "memset", "memcpy", "memmove",
    # I/O operations
    "read", "write", "fread", "fwrite", "recv", "send", "recvfrom", "sendto",
    # core pointer operations
    '->', '*', '&', '.'
}
defense_op_patterns = {
    # null-pointer checks
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*==\s*(NULL|nullptr|0)\s*\)'),
    re.compile(r'if\s*\(\s*(NULL|nullptr|0)\s*==\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    re.compile(r'if\s*\(\s*!\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    # non-null checks
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*!=\s*(NULL|nullptr|0)\s*\)'),
    re.compile(r'if\s*\(\s*(NULL|nullptr|0)\s*!=\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    re.compile(r'if\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
    # assertions
    re.compile(r'assert\s*\(\s*([a-zA-Z0-9_*->\.]+)\s*\)'),
}


def set_seed(args):
    random.seed(args.seed)
    os.environ['PYTHONHASHSEED'] = str(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    torch.backends.cudnn.deterministic = True


class InputFeatures(object):
    def __init__(self, idx, input_ids, special_token_pos, global_input_ids, label, vul_type, original_func):
        self.idx = idx
        self.input_ids = input_ids  # Path-level
        self.special_token_pos = special_token_pos
        self.global_input_ids = global_input_ids  # Global-level
        self.label = label
        self.vul_type = vul_type
        self.original_func = original_func


# ✨ V5.0 upgrade: feature-extraction function adapted to the new semantic features
def text_to_tokens_and_special_pos(text_str, tokenizer, args):
    special_token_spans = defaultdict(list)

    # find DANGER_OP
    for op in danger_op_keywords:
        try:
            pattern = re.compile(r'\b' + re.escape(op) + r'\b')
            for m in pattern.finditer(text_str):
                special_token_spans['[DANGER_OP]'].append(m.span())
        except re.error:
            pass

    # find POINTER_OP
    for op in pointer_op_keywords:
        try:
            pattern = re.compile(re.escape(op)) if op in ['->', '*', '&', '.'] else re.compile(
                r'\b' + re.escape(op) + r'\b')
            for m in pattern.finditer(text_str):
                special_token_spans['[POINTER_OP]'].append(m.span())
        except re.error:
            pass

    # find DEFENSE_OP
    for pattern in defense_op_patterns:
        for m in pattern.finditer(text_str):
            special_token_spans['[DEFENSE_OP]'].append(m.span())

    all_spans = []
    for token_type, spans in special_token_spans.items():
        for start, end in spans:
            all_spans.append((start, end, token_type))
    all_spans.sort()

    # merge overlapping spans, prioritizing the more important label (DANGER > DEFENSE > POINTER)
    merged_spans = []
    if all_spans:
        current_span = all_spans[0]
        for i in range(1, len(all_spans)):
            next_span = all_spans[i]
            if next_span[0] < current_span[1]:
                new_start = min(current_span[0], next_span[0])
                new_end = max(current_span[1], next_span[1])
                # priority: DANGER > DEFENSE > POINTER
                types = {current_span[2], next_span[2]}
                if '[DANGER_OP]' in types:
                    new_type = '[DANGER_OP]'
                elif '[DEFENSE_OP]' in types:
                    new_type = '[DEFENSE_OP]'
                else:
                    new_type = '[POINTER_OP]'
                current_span = (new_start, new_end, new_type)
            else:
                merged_spans.append(current_span)
                current_span = next_span
        merged_spans.append(current_span)

    last_pos = 0
    parts = []
    for start, end, token_type in merged_spans:
        if start > last_pos:
            parts.append(text_str[last_pos:start])
        parts.append(token_type)
        last_pos = end
    if last_pos < len(text_str):
        parts.append(text_str[last_pos:])
    enhanced_text_str = "".join(parts)

    # tokenization and padding
    seq_tokens = tokenizer.tokenize(enhanced_text_str)
    max_len_for_tokens = args.block_size - 2
    if len(seq_tokens) > max_len_for_tokens:
        half = max_len_for_tokens // 2
        seq_tokens = seq_tokens[:half] + seq_tokens[-(half + max_len_for_tokens % 2):]

    final_tokens = [tokenizer.cls_token] + seq_tokens + [tokenizer.sep_token]
    seq_ids = tokenizer.convert_tokens_to_ids(final_tokens)
    padding_length = args.block_size - len(seq_ids)
    seq_ids += [tokenizer.pad_token_id] * padding_length
    seq_ids = seq_ids[:args.block_size]

    # locate special-token positions
    pos_info = defaultdict(list)
    special_token_ids = {
        '[DANGER_OP]': tokenizer.convert_tokens_to_ids('[DANGER_OP]'),
        '[POINTER_OP]': tokenizer.convert_tokens_to_ids('[POINTER_OP]'),
        '[DEFENSE_OP]': tokenizer.convert_tokens_to_ids('[DEFENSE_OP]'),
    }
    for token_type, token_id_val in special_token_ids.items():
        for idx, token_id in enumerate(seq_ids):
            if token_id == token_id_val:
                pos_info[token_type].append(idx)

    return seq_ids, pos_info


def convert_examples_to_features(js, path_dict, tokenizer, args):
    try:
        current_idx = js.get('idx')
        idx_label = int(js.get('target'))
        vul_type = js.get('vul_type', 'unknown')
        original_func = js.get('func', '')
        if idx_label not in {0, 1}: return None, f"Invalid target label: {idx_label}"
        sample_entry = path_dict.get(current_idx)
        if not sample_entry:
            if isinstance(current_idx, str) and current_idx.isdigit():
                sample_entry = path_dict.get(int(current_idx))
            elif isinstance(current_idx, int):
                sample_entry = path_dict.get(str(current_idx))
        if not sample_entry: return None, f"IDX {current_idx} not found in path_dict"

        # 1. process paths (Path Stream)
        path_tokens_list = sample_entry.get('path_token', [])
        if not path_tokens_list: return None, "path_token is empty"
        all_seq_ids, all_pos_info = [], []
        for path_code_str in path_tokens_list[:args.max_paths]:
            if not isinstance(path_code_str, str) or not path_code_str.strip(): continue
            seq_ids, pos_info = text_to_tokens_and_special_pos(path_code_str, tokenizer, args)
            all_seq_ids.append(seq_ids)
            all_pos_info.append(pos_info)
        if not all_seq_ids: return None, "No valid path sequences generated"

        # 2. process the full function (Global Stream)
        global_tokens = tokenizer.tokenize(original_func)
        max_len_global = args.block_size - 2
        if len(global_tokens) > max_len_global:
            half = max_len_global // 2
            global_tokens = global_tokens[:half] + global_tokens[-(half + max_len_global % 2):]

        global_final_tokens = [tokenizer.cls_token] + global_tokens + [tokenizer.sep_token]
        global_input_ids = tokenizer.convert_tokens_to_ids(global_final_tokens)
        padding_length = args.block_size - len(global_input_ids)
        global_input_ids += [tokenizer.pad_token_id] * padding_length
        global_input_ids = global_input_ids[:args.block_size]

        return InputFeatures(current_idx, all_seq_ids, all_pos_info, global_input_ids, idx_label, vul_type,
                             original_func), None
    except Exception as e:
        import traceback
        return None, f"Unhandled exception for idx {js.get('idx', 'N/A')}: {e}\n{traceback.format_exc()}"


def _process_line_wrapper(line_info, **kwargs):
    line_index, line_content = line_info
    use_cache, cache_dir, worker_func_partial = kwargs['use_cache'], kwargs['cache_dir'], kwargs['worker_func_partial']
    line_strip = line_content.strip()
    if not line_strip: return None, "Empty line"
    CACHE_VERSION = "v5.0_hierarchical_fusion_20240804"  # ✨ V5.0 cache-version update
    cache_key = hashlib.md5(f"{line_strip}-{line_index}-{CACHE_VERSION}".encode('utf-8')).hexdigest()
    cache_file = os.path.join(cache_dir, f"{cache_key}.pkl")
    if use_cache and os.path.exists(cache_file):
        try:
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
        except Exception:
            pass
    try:
        js = json.loads(line_strip)
        if 'idx' not in js: js['idx'] = f"line_{line_index}"
        feature, reason = worker_func_partial(js=js)
        if use_cache and feature:
            os.makedirs(cache_dir, exist_ok=True)
            with open(cache_file, 'wb') as f: pickle.dump((feature, reason), f)
        return feature, reason
    except Exception as e:
        return None, f"JSON/Cache error on line {line_index}: {e}"


class TextDataset(Dataset):
    def __init__(self, tokenizer, args, file_path, pkl_file, use_cache=False, cache_dir='cached_features',
                 task_name=""):
        self.tokenizer = tokenizer
        self.args = args
        self.examples = []
        self.skipped_reasons = Counter()
        logger = logging.getLogger(f"{__name__}.TextDataset.{task_name}")
        logger.info(f"[{task_name}] 加载路径字典: {os.path.basename(pkl_file)}")
        try:
            with open(pkl_file, 'rb') as f:
                path_dict = pickle.load(f)
        except Exception as e:
            logger.error(f"无法加载 PKL 文件 {pkl_file}: {e}"); return
        logger.info(f"[{task_name}] 加载和处理数据源: {os.path.basename(file_path)}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = list(enumerate(f))
        except FileNotFoundError:
            logger.error(f"数据文件未找到: {file_path}"); return
        if use_cache: os.makedirs(cache_dir, exist_ok=True)
        worker_func = partial(convert_examples_to_features, path_dict=path_dict, tokenizer=tokenizer, args=args)
        process_line_func = partial(_process_line_wrapper, use_cache=use_cache, cache_dir=cache_dir,
                                    worker_func_partial=worker_func)
        with ProcessPoolExecutor(max_workers=args.num_preprocessing_workers) as executor:
            results = tqdm(executor.map(process_line_func, lines, chunksize=args.preprocessing_chunksize),
                           total=len(lines), desc=f"[{task_name}] 转换特征")
            for feature, reason in results:
                if feature:
                    self.examples.append(feature)
                else:
                    self.skipped_reasons[reason or "Unknown"] += 1
        logger.info(
            f"[{task_name}] 数据处理完成! 共加载 {len(self.examples)} 个样本. 跳过 {sum(self.skipped_reasons.values())} 个.")
        if self.skipped_reasons: logger.warning(
            f"[{task_name}] 跳过的主要原因 (Top 5): {self.skipped_reasons.most_common(5)}")

    def __len__(self):
        return len(self.examples)

    # ✨ V5.0 upgrade: adapt __getitem__ to the new model inputs
    def __getitem__(self, i):
        ex = self.examples[i]
        path_ids = [p[:self.args.block_size] for p in ex.input_ids]

        # create masks for the three features
        danger_masks, pointer_masks, defense_masks = [], [], []
        for path_pos_info in ex.special_token_pos:
            d_mask, p_mask, f_mask = ([0] * self.args.block_size for _ in range(3))
            for pos in path_pos_info.get('[DANGER_OP]', []):
                if 0 <= pos < self.args.block_size: d_mask[pos] = 1
            for pos in path_pos_info.get('[POINTER_OP]', []):
                if 0 <= pos < self.args.block_size: p_mask[pos] = 1
            for pos in path_pos_info.get('[DEFENSE_OP]', []):
                if 0 <= pos < self.args.block_size: f_mask[pos] = 1
            danger_masks.append(d_mask)
            pointer_masks.append(p_mask)
            defense_masks.append(f_mask)

        return {'path_ids': path_ids, 'danger_mask': danger_masks, 'pointer_mask': pointer_masks,
                'defense_mask': defense_masks, 'global_ids': ex.global_input_ids,
                'vuln_label': ex.label, 'original_index': i}


# ✨ V5.0 upgrade: adapt collate_fn to the new model inputs
def collate_fn(batch, pad_token_id, max_paths_global, path_dropout_rate=0.0):
    # extract all fields
    original_indices = [item['original_index'] for item in batch]
    path_ids_list = [item['path_ids'] for item in batch]
    danger_mask_list = [item['danger_mask'] for item in batch]
    pointer_mask_list = [item['pointer_mask'] for item in batch]
    defense_mask_list = [item['defense_mask'] for item in batch]
    global_ids_list = [item['global_ids'] for item in batch]
    vuln_labels_list = [item['vuln_label'] for item in batch]

    # Path Dropout
    if path_dropout_rate > 0:
        for i in range(len(path_ids_list)):
            num_paths = len(path_ids_list[i])
            if num_paths > 1:
                num_to_keep = max(1, int(num_paths * (1.0 - path_dropout_rate)))
                if num_to_keep < num_paths:
                    indices = sorted(random.sample(range(num_paths), num_to_keep))
                    path_ids_list[i] = [path_ids_list[i][j] for j in indices]
                    danger_mask_list[i] = [danger_mask_list[i][j] for j in indices]
                    pointer_mask_list[i] = [pointer_mask_list[i][j] for j in indices]
                    defense_mask_list[i] = [defense_mask_list[i][j] for j in indices]

    # prepare tensors
    batch_size = len(batch)
    block_size = len(path_ids_list[0][0]) if path_ids_list and path_ids_list[0] else 0
    actual_max_paths = min(max(len(p) for p in path_ids_list) if path_ids_list else 0, max_paths_global)

    # Path Tensors
    path_ids_tensor = torch.full((batch_size, actual_max_paths, block_size), pad_token_id, dtype=torch.long)
    danger_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    pointer_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    defense_mask_tensor = torch.zeros((batch_size, actual_max_paths, block_size), dtype=torch.long)
    path_mask_tensor = torch.zeros((batch_size, actual_max_paths), dtype=torch.float)

    for i in range(batch_size):
        paths_to_fill = min(len(path_ids_list[i]), actual_max_paths)
        if paths_to_fill > 0:
            path_ids_tensor[i, :paths_to_fill, :] = torch.tensor(path_ids_list[i][:paths_to_fill], dtype=torch.long)
            danger_mask_tensor[i, :paths_to_fill, :] = torch.tensor(danger_mask_list[i][:paths_to_fill],
                                                                    dtype=torch.long)
            pointer_mask_tensor[i, :paths_to_fill, :] = torch.tensor(pointer_mask_list[i][:paths_to_fill],
                                                                     dtype=torch.long)
            defense_mask_tensor[i, :paths_to_fill, :] = torch.tensor(defense_mask_list[i][:paths_to_fill],
                                                                     dtype=torch.long)
            path_mask_tensor[i, :paths_to_fill] = 1.0

    path_attn_mask = (path_ids_tensor != pad_token_id).long()

    # Global Tensors
    global_ids_tensor = torch.tensor(global_ids_list, dtype=torch.long)
    global_attn_mask = (global_ids_tensor != pad_token_id).long()

    # Labels
    vuln_labels = torch.tensor(vuln_labels_list, dtype=torch.long)

    return {
        'path_ids': path_ids_tensor, 'path_attention_mask': path_attn_mask, 'path_mask': path_mask_tensor,
        'danger_mask': danger_mask_tensor, 'pointer_mask': pointer_mask_tensor, 'defense_mask': defense_mask_tensor,
        'global_ids': global_ids_tensor, 'global_attention_mask': global_attn_mask,
        'vuln_labels': vuln_labels, 'original_indices': original_indices
    }


def evaluate(args, model, eval_dataloader, is_test=False, task_name="", save_preds_path=None, error_analysis=False):
    """ evaluate model performance Args: args: argument configuration model: model eval_dataloader: evaluation data loader is_test: whether this is the test stage (True = use the optimal threshold found on the validation set; False = search for the optimal threshold) task_name: task name (used for logging) save_preds_path: path for saving prediction results error_analysis: whether to perform error analysis Returns: results: dictionary containing all evaluation metrics """
    logger = logging.getLogger(__name__)
    desc_prefix = f"[{task_name}] 评估中"
    model.eval()
    all_logits, all_labels, all_original_indices = [], [], []

    # collect all predictions
    for batch in tqdm(eval_dataloader, desc=desc_prefix, leave=False):
        all_original_indices.extend(batch['original_indices'])
        batch = {k: v.to(args.device) for k, v in batch.items() if isinstance(v, torch.Tensor)}
        with torch.no_grad(), amp.autocast(enabled=args.fp16):
            logits = model(**batch)
        all_logits.append(logits.cpu())
        all_labels.append(batch["vuln_labels"].cpu())

    if not all_labels:
        return {}

    logits_concat = torch.cat(all_logits).numpy()
    labels_concat = torch.cat(all_labels).numpy()
    probs_c1_concat = F.softmax(torch.from_numpy(logits_concat).float(), dim=-1)[:, 1].numpy()

    # ✨ threshold-selection logic
    if is_test:
        # test stage: use the optimal threshold found on the validation set
        best_threshold = getattr(args, 'best_threshold', 0.5)
        logger.info(f"[{task_name}] 测试阶段：使用从验证集找到的最优阈值 {best_threshold:.4f}")
        preds = (probs_c1_concat >= best_threshold).astype(int)
    else:
        # validation stage: search for the F1-optimal threshold
        logger.info(f"[{task_name}] 验证阶段：开始搜索最优F1阈值...")
        best_f1, best_threshold = -1, 0.5
        for threshold in np.arange(0.1, 0.9, 0.01):
            temp_preds = (probs_c1_concat >= threshold).astype(int)
            f1 = f1_score(labels_concat, temp_preds, zero_division=0)
            if f1 > best_f1:
                best_f1, best_threshold = f1, threshold
        logger.info(f"[{task_name}] 验证阶段：最优F1为 {best_f1:.4f}，对应阈值为 {best_threshold:.4f}")
        args.best_threshold = best_threshold
        preds = (probs_c1_concat >= best_threshold).astype(int)

    # ✨ compute all evaluation metrics, including MCC and PR-AUC
    from sklearn.metrics import matthews_corrcoef, average_precision_score

    results = {
        "acc": accuracy_score(labels_concat, preds),
        "recall": recall_score(labels_concat, preds, zero_division=0),
        "precision": precision_score(labels_concat, preds, zero_division=0),
        "f1": f1_score(labels_concat, preds, zero_division=0),
        "mcc": matthews_corrcoef(labels_concat, preds),  # ✨ added
        "pr_auc": average_precision_score(labels_concat, probs_c1_concat),  # ✨ added
        "best_threshold": best_threshold
    }

    # compute AUC when class conditions permit
    if len(np.unique(labels_concat)) > 1:
        results["auc"] = roc_auc_score(labels_concat, probs_c1_concat)

    # confusion matrix
    cm = confusion_matrix(labels_concat, preds)
    logger.info(f"[{task_name}] 混淆矩阵 (使用阈值: {best_threshold:.4f}):\n{cm}")

    # save prediction details
    if save_preds_path:
        try:
            with open(save_preds_path, 'w') as f:
                f.write("Pred\tTrue\tProb_Class1\n")
                for i in range(len(preds)):
                    f.write(f"{preds[i]}\t{labels_concat[i]}\t{probs_c1_concat[i]:.4f}\n")
            logger.info(f"预测详情已保存到: {save_preds_path}")
        except Exception as e:
            logger.error(f"无法保存预测文件到 {save_preds_path}: {e}")

    # ✨ error analysis (enhanced version)
    if error_analysis and is_test:
        fp_list, fn_list = [], []
        eval_dataset = eval_dataloader.dataset
        original_dataset = eval_dataset.dataset if isinstance(eval_dataset, Subset) else eval_dataset

        for i in range(len(preds)):
            try:
                real_index = eval_dataset.indices[i] if isinstance(eval_dataset, Subset) else i
                if real_index >= len(original_dataset.examples):
                    continue

                example = original_dataset.examples[real_index]

                # ✨ enhancement: add confidence scores and code snippets
                example_dict = {
                    'idx': getattr(example, 'idx', f'unknown_{real_index}'),
                    'label': int(getattr(example, 'label', labels_concat[i])),
                    'prediction': int(preds[i]),
                    'confidence': float(probs_c1_concat[i]),  # ✨ added
                    'vul_type': getattr(example, 'vul_type', 'unknown'),
                    'original_func': getattr(example, 'original_func', '')[:500]  # ✨ added (first 500 characters)
                }

                if preds[i] == 1 and labels_concat[i] == 0:
                    fp_list.append(example_dict)
                elif preds[i] == 0 and labels_concat[i] == 1:
                    fn_list.append(example_dict)
            except Exception as e:
                logger.warning(f"处理样本 {i} 时出错: {e}")
                continue

        # save error-analysis files
        fp_file = os.path.join(args.output_dir, f"error_analysis_fp_{task_name}.jsonl")
        fn_file = os.path.join(args.output_dir, f"error_analysis_fn_{task_name}.jsonl")

        try:
            with open(fp_file, 'w', encoding='utf-8') as f:
                for item in fp_list:
                    f.write(json.dumps(item, ensure_ascii=False) + '\n')
            with open(fn_file, 'w', encoding='utf-8') as f:
                for item in fn_list:
                    f.write(json.dumps(item, ensure_ascii=False) + '\n')

            logger.info(f"错误分析完成 for [{task_name}]:")
            logger.info(f"  - 误报 (FP) 样本已保存到: {os.path.basename(fp_file)} ({len(fp_list)}个)")
            logger.info(f"  - 漏报 (FN) 样本已保存到: {os.path.basename(fn_file)} ({len(fn_list)}个)")
        except Exception as e:
            logger.error(f"保存错误分析文件时出错: {e}")

    return results


def train(args, model, tokenizer, train_dataloader, eval_dataloader=None):
    logger = logging.getLogger(__name__)
    t_total = len(train_dataloader) // args.gradient_accumulation_steps * args.num_train_epochs
    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_parameters = [
        {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay) and p.requires_grad],
         'weight_decay': args.weight_decay},
        {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay) and p.requires_grad],
         'weight_decay': 0.0}]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=int(t_total * args.warmup_ratio),
                                                num_training_steps=t_total)
    scaler = amp.GradScaler(enabled=args.fp16)
    criterion = args.criterion
    logger.info("***** 开始训练 *****")
    logger.info(f"  总样本数 = {len(train_dataloader.dataset)}")
    logger.info(f"  Epoch 总数 = {args.num_train_epochs}")
    logger.info(f"  即时批大小 = {args.train_batch_size}")
    logger.info(f"  梯度累积步数 = {args.gradient_accumulation_steps}")
    logger.info(f"  总优化步数 = {t_total}")
    global_step, best_metric_val, epochs_no_improve = 0, -1.0, 0
    model.zero_grad()
    train_iterator = trange(int(args.num_train_epochs), desc="Epoch")
    for epoch in train_iterator:
        model.train()
        epoch_iterator = tqdm(train_dataloader, desc="Iteration", leave=False)
        for step, batch in enumerate(epoch_iterator):
            batch = {k: v.to(args.device) for k, v in batch.items() if isinstance(v, torch.Tensor)}
            with amp.autocast(enabled=args.fp16):
                logits = model(**batch)
                loss = criterion(logits, batch["vuln_labels"])
            if args.n_gpu > 1: loss = loss.mean()
            if args.gradient_accumulation_steps > 1: loss = loss / args.gradient_accumulation_steps
            scaler.scale(loss).backward()
            epoch_iterator.set_postfix({'loss': loss.item()})
            if (step + 1) % args.gradient_accumulation_steps == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                model.zero_grad()
                global_step += 1
        if args.do_eval and eval_dataloader:
            if torch.cuda.is_available(): torch.cuda.empty_cache()
            eval_results = evaluate(args, model, eval_dataloader, task_name=f"Validation Epoch {epoch + 1}")
            current_metric_val = eval_results.get(args.metric_for_best_model, 0.0)
            logger.info(f"--- Epoch {epoch + 1} 验证结果 ---")
            for key, value in eval_results.items(): logger.info(f"  {key} = {value:.4f}")
            logger.info(
                f"  当前 {args.metric_for_best_model}: {current_metric_val:.4f}, 历史最佳: {best_metric_val:.4f}")
            if current_metric_val > best_metric_val:
                best_metric_val, epochs_no_improve = current_metric_val, 0
                logger.info(f"  新高! 已保存最佳模型。")
                save_checkpoint(args, model, optimizer, scheduler, scaler, epoch + 1, global_step, best_metric_val,
                                epochs_no_improve, is_best=True)
            else:
                epochs_no_improve += 1
                logger.info(f"  验证指标未提升. 已连续 {epochs_no_improve} 个 Epochs 未提升.")
                if epochs_no_improve >= args.early_stopping_patience:
                    logger.warning(f"触发早停机制! 训练在 Epoch {epoch + 1} 终止。")
                    train_iterator.close();
                    break
        save_checkpoint(args, model, optimizer, scheduler, scaler, epoch + 1, global_step, best_metric_val,
                        epochs_no_improve, is_best=False)
    logger.info(f"训练完成。最佳验证 {args.metric_for_best_model} 为: {best_metric_val:.4f}")


def save_checkpoint(args, model, optimizer, scheduler, scaler, epoch, global_step, best_metric_val, epochs_no_improve,
                    is_best=False):
    """ save a model checkpoint Args: args: argument configuration model: model optimizer: optimizer scheduler: learning-rate scheduler scaler: scaler for mixed-precision training epoch: current epoch global_step: global step best_metric_val: best validation metric value epochs_no_improve: number of consecutive epochs without improvement is_best: whether this is the best model """
    logger = logging.getLogger(__name__)
    model_to_save = model.module if hasattr(model, 'module') else model

    if is_best:
        best_output_dir = os.path.join(args.output_dir, 'checkpoint-best')
        os.makedirs(best_output_dir, exist_ok=True)

        # save model weights
        torch.save(model_to_save.state_dict(), os.path.join(best_output_dir, 'model.bin'))
        model_to_save.config.save_pretrained(best_output_dir)

        # save the tokenizer
        if hasattr(args, 'tokenizer'):
            args.tokenizer.save_pretrained(best_output_dir)

        # save training arguments
        torch.save(args, os.path.join(best_output_dir, 'training_args.bin'))

        # ✨ save the optimal threshold and other key parameters
        best_params = {
            'best_threshold': getattr(args, 'best_threshold', 0.5),
            'best_metric_val': best_metric_val,
            'epoch': epoch,
            'global_step': global_step,
            'metric_name': args.metric_for_best_model
        }
        with open(os.path.join(best_output_dir, 'best_params.json'), 'w') as f:
            json.dump(best_params, f, indent=2)

        logger.info(f"最佳模型及参数已保存到: {best_output_dir}")

    # save the latest checkpoint for training resumption
    latest_output_dir = os.path.join(args.output_dir, 'checkpoint-latest')
    os.makedirs(latest_output_dir, exist_ok=True)

    checkpoint = {
        'epoch': epoch,
        'global_step': global_step,
        'model_state_dict': model_to_save.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'best_metric_val': best_metric_val,
        'epochs_no_improve': epochs_no_improve,
        'args': args
    }

    if args.fp16:
        checkpoint['scaler_state_dict'] = scaler.state_dict()

    torch.save(checkpoint, os.path.join(latest_output_dir, 'checkpoint.bin'))


def main():
    if sys.platform.startswith('linux') and multiprocessing.get_start_method(allow_none=True) != 'spawn':
        try:
            multiprocessing.set_start_method('spawn', force=True)
        except RuntimeError:
            pass

    parser = argparse.ArgumentParser()
    parser.add_argument("--output_dir", required=True, type=str)
    parser.add_argument("--data_dir", required=True, type=str)
    parser.add_argument("--pkl_dir", required=True, type=str)
    parser.add_argument("--model_name_or_path", required=True, type=str)
    parser.add_argument("--train_file_name", default="mvd_multi_train_cdata_synced.jsonl")
    parser.add_argument("--valid_file_name", default="mvd_multi_valid_cdata_synced.jsonl")
    parser.add_argument("--test_file_name", default="mvd_multi_test_cdata_synced.jsonl")
    parser.add_argument("--pkl_file_name_train", default="cdata_nobalance_train.pkl")
    parser.add_argument("--pkl_file_name_valid", default="cdata_nobalance_valid.pkl")
    parser.add_argument("--pkl_file_name_test", default="cdata_nobalance_test.pkl")
    parser.add_argument("--do_train", action='store_true')
    parser.add_argument("--do_eval", action='store_true')
    parser.add_argument("--do_test", action='store_true')
    parser.add_argument("--use_cache", action='store_true')
    parser.add_argument("--fp16", action='store_true')
    parser.add_argument("--balance_test_set", action='store_true')
    parser.add_argument("--model_type", default="unixcoder")
    parser.add_argument("--block_size", default=860, type=int)
    parser.add_argument("--max_paths", default=15, type=int)
    parser.add_argument("--train_batch_size", default=1, type=int)
    parser.add_argument("--eval_batch_size", default=1, type=int)
    parser.add_argument("--gradient_accumulation_steps", default=12, type=int)
    parser.add_argument("--learning_rate", default=1e-5, type=float)
    parser.add_argument("--weight_decay", default=0.01, type=float)
    parser.add_argument("--adam_epsilon", default=1e-8, type=float)
    parser.add_argument("--max_grad_norm", default=1.0, type=float)
    parser.add_argument("--num_train_epochs", default=25.0, type=float)
    parser.add_argument("--warmup_ratio", default=0.06, type=float)
    parser.add_argument("--path_dropout_rate", default=0.2, type=float)
    parser.add_argument("--early_stopping_patience", default=7, type=int)
    parser.add_argument("--metric_for_best_model", default="f1")
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--cache_dir_name", default="cached_features_v5")
    parser.add_argument("--num_preprocessing_workers", default=8, type=int)
    parser.add_argument("--num_dataloader_workers", default=4, type=int)
    parser.add_argument("--preprocessing_chunksize", default=64, type=int)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    log_file_path = os.path.join(args.output_dir, "run_log_v5.log")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
                        handlers=[logging.FileHandler(log_file_path, mode='w'), logging.StreamHandler(sys.stdout)])
    logger = logging.getLogger(__name__)
    logger.info("=" * 20 + " V5 Model Run Start " + "=" * 20)
    logger.info("Parameters: %s", args)
    args.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()
    set_seed(args)

    config = MODEL_CLASSES[args.model_type][0].from_pretrained(args.model_name_or_path)
    tokenizer = MODEL_CLASSES[args.model_type][2].from_pretrained(args.model_name_or_path)
    new_special_tokens = ['[DANGER_OP]', '[POINTER_OP]', '[DEFENSE_OP]']
    tokenizer.add_special_tokens({'additional_special_tokens': new_special_tokens})

    encoder = MODEL_CLASSES[args.model_type][1].from_pretrained(args.model_name_or_path, config=config)
    encoder.resize_token_embeddings(len(tokenizer))

    model = Model(encoder, config, tokenizer, args).to(args.device)
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)
    args.tokenizer = tokenizer

    cache_dir_base = os.path.join(args.output_dir, args.cache_dir_name)

    # ==================== training stage ====================
    if args.do_train:
        logger.info("\n" + "=" * 50 + "\n***** V5 开始训练阶段 *****\n" + "=" * 50)
        train_dataset = TextDataset(tokenizer, args, os.path.join(args.data_dir, args.train_file_name),
                                    os.path.join(args.pkl_dir, args.pkl_file_name_train), args.use_cache,
                                    os.path.join(cache_dir_base, "train"), "Train")
        if not train_dataset.examples:
            logger.error("训练数据集为空，无法继续。")
            return

        counts = Counter([ex.label for ex in train_dataset.examples])
        weight_for_class_0 = (counts[0] + counts[1]) / (2.0 * counts[0]) if counts[0] > 0 else 1.0
        weight_for_class_1 = (counts[0] + counts[1]) / (2.0 * counts[1]) if counts[1] > 0 else 1.0
        class_weights = torch.tensor([weight_for_class_0, weight_for_class_1], dtype=torch.float).to(args.device)
        logger.info(f"训练集标签分布: {counts}. 计算出的损失权重: {class_weights.tolist()}")
        args.criterion = nn.CrossEntropyLoss(weight=class_weights)

        collate_partial = partial(collate_fn, pad_token_id=tokenizer.pad_token_id, max_paths_global=args.max_paths,
                                  path_dropout_rate=args.path_dropout_rate)
        train_dataloader = DataLoader(train_dataset, sampler=RandomSampler(train_dataset),
                                      batch_size=args.train_batch_size, collate_fn=collate_partial,
                                      num_workers=args.num_dataloader_workers, pin_memory=True)

        eval_dataloader = None
        if args.do_eval:
            eval_dataset = TextDataset(tokenizer, args, os.path.join(args.data_dir, args.valid_file_name),
                                       os.path.join(args.pkl_dir, args.pkl_file_name_valid), args.use_cache,
                                       os.path.join(cache_dir_base, "valid"), "Valid")
            if eval_dataset.examples:
                eval_dataloader = DataLoader(eval_dataset, sampler=SequentialSampler(eval_dataset),
                                             batch_size=args.eval_batch_size, collate_fn=collate_partial,
                                             num_workers=args.num_dataloader_workers, pin_memory=True)
        train(args, model, tokenizer, train_dataloader, eval_dataloader)

    # ==================== test stage ====================
    if args.do_test:
        logger.info("\n" + "=" * 50 + "\n***** V5 开始测试阶段 *****\n" + "=" * 50)
        best_checkpoint_dir = os.path.join(args.output_dir, 'checkpoint-best')

        # check whether the best model exists
        if not os.path.exists(os.path.join(best_checkpoint_dir, 'model.bin')):
            logger.error(f"未找到最佳模型: {os.path.join(best_checkpoint_dir, 'model.bin')}，无法测试。")
            return

        # load model weights
        logger.info(f"加载测试模型: {os.path.join(best_checkpoint_dir, 'model.bin')}")
        model_to_load = model.module if hasattr(model, 'module') else model
        model_to_load.load_state_dict(
            torch.load(os.path.join(best_checkpoint_dir, 'model.bin'), map_location=args.device)
        )

        # ✨ load the optimal threshold
        best_params_path = os.path.join(best_checkpoint_dir, 'best_params.json')
        if os.path.exists(best_params_path):
            with open(best_params_path, 'r') as f:
                best_params = json.load(f)
            args.best_threshold = best_params.get('best_threshold', 0.5)
            # args.best_threshold = 0.53
            logger.info(f"成功加载与最佳模型匹配的阈值: {args.best_threshold:.4f}")
            logger.info(
                f"  - 最佳验证 {best_params.get('metric_name', 'f1')}: {best_params.get('best_metric_val', 0.0):.4f}")
            logger.info(f"  - 对应 Epoch: {best_params.get('epoch', 'N/A')}")
        else:
            args.best_threshold = 0.5
            logger.warning(f"未找到 'best_params.json'。将使用默认阈值: 0.5")

        # load the test dataset
        full_test_dataset = TextDataset(tokenizer, args, os.path.join(args.data_dir, args.test_file_name),
                                        os.path.join(args.pkl_dir, args.pkl_file_name_test), args.use_cache,
                                        os.path.join(cache_dir_base, "test_merged"), "FullTest")
        if not full_test_dataset.examples:
            logger.error("完整的测试数据集为空，无法测试。")
            return

        all_results = []
        collate_partial_test = partial(collate_fn, pad_token_id=tokenizer.pad_token_id,
                                       max_paths_global=args.max_paths, path_dropout_rate=0.0)

        # ==================== overall performance evaluation ====================
        logger.info("\n--- 开始整体性能测试 ---")
        full_test_dataloader = DataLoader(full_test_dataset, sampler=SequentialSampler(full_test_dataset),
                                          batch_size=args.eval_batch_size, collate_fn=collate_partial_test,
                                          num_workers=args.num_dataloader_workers)
        overall_results = evaluate(args, model, full_test_dataloader, is_test=True, task_name="Overall",
                                   save_preds_path=os.path.join(args.output_dir, "predictions_overall.txt"),
                                   error_analysis=True)
        all_results.append({'task': 'Overall', **overall_results})

        # ==================== per-category performance evaluation (One-vs-Safe) ====================
        logger.info("\n--- 开始分项性能测试 (One-vs-Safe) ---")
        indices_by_type, nonvuln_indices = defaultdict(list), []
        for i, ex in enumerate(full_test_dataset.examples):
            if ex.vul_type == 'nonvuln' or ex.label == 0:
                nonvuln_indices.append(i)
            else:
                indices_by_type[ex.vul_type].append(i)

        vuln_types = sorted([vt for vt in indices_by_type.keys() if vt != 'unknown'])
        logger.info(f"找到的漏洞类型: {vuln_types}")

        for v_type in vuln_types:
            task_name = f"d2a-{v_type.replace('_', '-')}"
            logger.info(f"\n--- 测试任务: {task_name} ---")
            vuln_indices = indices_by_type.get(v_type, [])
            if not vuln_indices:
                continue

            current_nonvuln_indices = nonvuln_indices
            if args.balance_test_set:
                num_pos = len(vuln_indices)
                if num_pos <= len(nonvuln_indices):
                    current_nonvuln_indices = random.sample(nonvuln_indices, num_pos)
                    logger.info(f"[{task_name}] 已激活平衡测试模式，随机采样 {num_pos} 个负样本。")

            specialized_indices = vuln_indices + current_nonvuln_indices
            specialized_dataset = Subset(full_test_dataset, specialized_indices)
            logger.info(
                f"任务 [{task_name}] 数据集大小: {len(specialized_dataset)} ({len(vuln_indices)} 正, {len(current_nonvuln_indices)} 负)"
            )

            test_dataloader = DataLoader(specialized_dataset, sampler=SequentialSampler(specialized_dataset),
                                         batch_size=args.eval_batch_size, collate_fn=collate_partial_test,
                                         num_workers=0)
            results = evaluate(args, model, test_dataloader, is_test=True, task_name=task_name, error_analysis=True)
            all_results.append({'task': task_name, **results})

        # ==================== final test-results summary ====================
        if len(all_results) > 0:
            logger.info("\n\n" + "=" * 100)
            logger.info("***** 最终测试结果汇总 *****")
            logger.info("=" * 100)

            # ✨ change: add MCC and PR-AUC columns
            header = "{:<25} {:<8} {:<8} {:<10} {:<8} {:<8} {:<8} {:<8}".format(
                "Task", "Acc", "Recall", "Precision", "F1", "MCC", "PR-AUC", "AUC"
            )
            logger.info(header)
            logger.info("-" * 100)

            for res in all_results:
                row_str = "{:<25} {:<8.4f} {:<8.4f} {:<10.4f} {:<8.4f} {:<8.4f} {:<8.4f} {:<8.4f}".format(
                    res.get('task', 'N/A'),
                    res.get('acc', 0.0),
                    res.get('recall', 0.0),
                    res.get('precision', 0.0),
                    res.get('f1', 0.0),
                    res.get('mcc', 0.0),  # ✨ added
                    res.get('pr_auc', 0.0),  # ✨ added
                    res.get('auc', 0.0)
                )
                logger.info(row_str)

            logger.info("=" * 100)

          




if __name__ == "__main__":
    main()

