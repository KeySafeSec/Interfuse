import json
import random
import re
from tqdm import tqdm


def inject_noise(code):
    lines = code.split('\n')
    new_lines = []

    # define noise statements
    log_statements = [
        'printf("DEBUG: trace execution path %d\\n", __LINE__);',
        'fprintf(stderr, "Log: variable check\\n");',
        'log_info("Function entry/exit point");',
        'syslog(LOG_INFO, "Processing data chunk %d", i);'
    ]

    defensive_checks = [
        'if (ptr == NULL) { return -1; }',
        'if (buffer_size <= 0) { goto cleanup; }',
        'assert(index >= 0 && index < limit);',
        'if (!is_valid(ctx)) break;'
    ]

    for line in lines:
        new_lines.append(line)
        stripped = line.strip()

        # insert only after non-empty statement lines to avoid breaking structure
        if stripped.endswith(';') or stripped.endswith('{'):
            # 20% probability of inserting a logging statement
            if random.random() < 0.2:
                indent = line[:len(line) - len(stripped)]
                noise = random.choice(log_statements)
                new_lines.append(f"{indent}{noise}")

            # 15% probability of inserting a defensive check
            if random.random() < 0.15:
                indent = line[:len(line) - len(stripped)]
                noise = random.choice(defensive_checks)
                new_lines.append(f"{indent}{noise}")

    return '\n'.join(new_lines)


def main():
    # replace with the actual input path
    input_file = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/test_cdata_merged.jsonl"
    output_file = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/repair/test_cdata_noisy.jsonl"

    print(f"Generating noisy dataset from {input_file}...")

    with open(input_file, 'r', encoding='utf-8') as fin, \
            open(output_file, 'w', encoding='utf-8') as fout:

        for line in tqdm(fin):
            data = json.loads(line)
            # inject noise into the func field (source code)
            if 'func' in data:
                data['func'] = inject_noise(data['func'])

            fout.write(json.dumps(data) + '\n')

    print(f"Done! Saved to {output_file}")
    print("Next Step: Run 'build_combined_cfg...' on this file, then run 'run.py' --do_test")


if __name__ == "__main__":
    main()
