import json
import random
import re
from tqdm import tqdm


def inject_noise(code):
    lines = code.split('\n')
    new_lines = []

    # 定义噪声语句
    log_statements = [
        'printf("DEBUG: trace execution path %d\\n", __LINE__);',
        'fprintf(stderr, "Log: variable check\\n");',
        'log_info("Function entry/exit point");',
        'syslog(LOG_INFO, "Processing data chunk %d", i);'
    ]

    defensive_checks = [
        'if (ptr == NULL) { return -1; }',
        'if (buffer_size <= 0) { goto cleanup; }',
        'assert(index >= 0 && index < limit);',
        'if (!is_valid(ctx)) break;'
    ]

    for line in lines:
        new_lines.append(line)
        stripped = line.strip()

        # 仅在非空的语句行后插入，避免破坏结构
        if stripped.endswith(';') or stripped.endswith('{'):
            # 20% 概率插入日志
            if random.random() < 0.2:
                indent = line[:len(line) - len(stripped)]
                noise = random.choice(log_statements)
                new_lines.append(f"{indent}{noise}")

            # 15% 概率插入防御性检查
            if random.random() < 0.15:
                indent = line[:len(line) - len(stripped)]
                noise = random.choice(defensive_checks)
                new_lines.append(f"{indent}{noise}")

    return '\n'.join(new_lines)


def main():
    # 修改为您的真实输入路径
    input_file = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/test_cdata_merged.jsonl"
    output_file = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/repair/test_cdata_noisy.jsonl"

    print(f"Generating noisy dataset from {input_file}...")

    with open(input_file, 'r', encoding='utf-8') as fin, \
            open(output_file, 'w', encoding='utf-8') as fout:

        for line in tqdm(fin):
            data = json.loads(line)
            # 对 func 字段（源代码）注入噪声
            if 'func' in data:
                data['func'] = inject_noise(data['func'])

            fout.write(json.dumps(data) + '\n')

    print(f"Done! Saved to {output_file}")
    print("Next Step: Run 'build_combined_cfg...' on this file, then run 'run.py' --do_test")


if __name__ == "__main__":
    main()
