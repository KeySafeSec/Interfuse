import json
import os

# ================= configuration section =================
# 1. your output directory (where preds_*.txt is located)
OUTPUT_DIR = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/output/run_unixcoder_test_fine_grained"

# 2. your data directory (where the JSONL file is located)
DATA_DIR = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/pkl_dir"


# ===========================================

def load_source_code(jsonl_path):
    """load original code and build an idx -> code mapping"""
    code_map = {}
    print(f"Loading source code from {os.path.basename(jsonl_path)}...")
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        for line in f:
            item = json.loads(line)
            idx = str(item.get('idx'))
            code = item.get('func', '')
            code_map[idx] = code
    return code_map


def generate_report(scenario, jsonl_file):
    preds_file = os.path.join(OUTPUT_DIR, f"preds_{scenario}.txt")
    jsonl_path = os.path.join(DATA_DIR, jsonl_file)
    output_report = os.path.join(OUTPUT_DIR, f"error_analysis_{scenario}.txt")

    if not os.path.exists(preds_file):
        print(f"⚠️ Skip {scenario}: Preds file not found.")
        return

    # load code
    code_map = load_source_code(jsonl_path)

    fp_count = 0
    fn_count = 0

    with open(preds_file, 'r') as f_in, open(output_report, 'w', encoding='utf-8') as f_out:
        f_out.write(f"=== Error Analysis Report: {scenario} ===\n")
        f_out.write("FP: False Positive (Model says Vuln, Actual Safe)\n")
        f_out.write("FN: False Negative (Model says Safe, Actual Vuln)\n\n")

        # skip the header line
        next(f_in)

        for line in f_in:
            parts = line.strip().split('\t')
            if len(parts) < 4: continue

            idx, pred, label, prob = parts[0], int(parts[1]), int(parts[2]), float(parts[3])

            # only process errors
            if pred == label: continue

            error_type = "FP" if pred == 1 else "FN"
            if error_type == "FP":
                fp_count += 1
            else:
                fn_count += 1

            # to keep the output file manageable, save only the first 20 examples of each error type
            # if (error_type == "FP" and fp_count > 20) or (error_type == "FN" and fn_count > 20):
            #    continue

            code = code_map.get(idx, "Code not found")

            f_out.write(f"[{error_type}] ID: {idx} | Conf: {prob:.4f}\n")
            f_out.write("-" * 40 + "\n")
            f_out.write(code)
            f_out.write("\n" + "=" * 60 + "\n\n")

    print(f"✅ Generated report for {scenario}: {fp_count} FPs, {fn_count} FNs -> {output_report}")


def main():
    scenarios = [
        ("Logging", "test_noisy_logging_synced.jsonl"),
        ("Defensive", "test_noisy_defensive_synced.jsonl"),
        ("Error", "test_noisy_error_synced.jsonl"),
        ("Combined", "test_noisy_combined_synced.jsonl"),
    ]

    for sc, json_file in scenarios:
        generate_report(sc, json_file)


if __name__ == "__main__":
    main()
