# analyze_real_world_complexity.py
"""
analyze the proportion of auxiliary logic (noise) in real code
goal: demonstrate that the D2A test set itself contains substantial logging, defensive checks, and error handling
"""

import json
import re
import numpy as np
from collections import Counter
import os
import argparse

# ================= configuration section =================
DEFAULT_INPUT_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/test_cdata_merged.jsonl"


# ===========================================

def analyze_real_world_complexity(jsonl_file, output_file=None):
    """ analyze the proportion of "noise" in real code Args: jsonl_file: input JSONL file path output_file: optional output-file path for saving detailed statistics Returns: dict: dictionary containing all statistics """
    # define noise patterns (regular expressions)
    noise_patterns = {
        'logging': re.compile(
            r'\b(printf|fprintf|sprintf|snprintf|syslog|log_|LOG_|debug_|DEBUG_|trace_|TRACE_|info_|INFO_|warn_|WARN_|error_|ERROR_)\s*\('),
        'defensive': re.compile(
            r'if\s*\(\s*[!]?\s*[\w>.-]+\s*\)\s*\{?\s*(return|continue|break|goto)\s*[;\w]*\s*\}?'),
        'error_handling': re.compile(r'\b(goto\s+\w+|cleanup:|error:|fail:|err_\w+:|catch\s*\(|finally\s*\{)'),
        'assertions': re.compile(r'\b(assert|ASSERT|BUG_ON|WARN_ON|CHECK|DCHECK)\s*\('),
        'null_checks': re.compile(r'if\s*\(\s*[\w>.-]+\s*(==|!=)\s*(NULL|nullptr|0)\s*\)'),
    }

    results = {
        'total_functions': 0,
        'total_lines': 0,
        'functions_with_logging': 0,
        'functions_with_defensive': 0,
        'functions_with_error_handling': 0,
        'functions_with_assertions': 0,
        'functions_with_null_checks': 0,
        'avg_noise_lines_per_function': [],
        'noise_line_ratio': [],  # ratio of noise lines to total lines
        'function_length_distribution': [],  # function-length distribution
        'noise_intensity_by_length': {},  # noise intensity grouped by function length
    }

    # for detailed analysis
    detailed_stats = []

    print(f"📂 Reading file: {jsonl_file}")
    if not os.path.exists(jsonl_file):
        print(f"❌ File not found: {jsonl_file}")
        return None

    with open(jsonl_file, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            try:
                item = json.loads(line)
                code = item.get('func', '')
                if not code:
                    continue

                lines = code.split('\n')
                total_lines = len(lines)
                results['total_functions'] += 1
                results['total_lines'] += total_lines
                results['function_length_distribution'].append(total_lines)

                # count occurrences of each noise type
                noise_counts = {
                    'logging': 0,
                    'defensive': 0,
                    'error_handling': 0,
                    'assertions': 0,
                    'null_checks': 0,
                }

                for pattern_name, pattern in noise_patterns.items():
                    matches = pattern.findall(code)
                    if matches:
                        noise_counts[pattern_name] = len(matches)
                        results[f'functions_with_{pattern_name}'] += 1

                # compute the total number of noise lines
                total_noise_lines = sum(noise_counts.values())
                results['avg_noise_lines_per_function'].append(total_noise_lines)
                noise_ratio = total_noise_lines / total_lines if total_lines > 0 else 0
                results['noise_line_ratio'].append(noise_ratio)

                # group statistics by function length
                length_bucket = (total_lines // 20) * 20  # one bucket per 20 lines
                if length_bucket not in results['noise_intensity_by_length']:
                    results['noise_intensity_by_length'][length_bucket] = []
                results['noise_intensity_by_length'][length_bucket].append(noise_ratio)

                # save detailed information for later analysis
                detailed_stats.append({
                    'idx': item.get('idx', f'line_{line_num}'),
                    'length': total_lines,
                    'noise_lines': total_noise_lines,
                    'noise_ratio': noise_ratio,
                    **noise_counts
                })

            except json.JSONDecodeError:
                print(f"⚠️  Skipping invalid JSON at line {line_num}")
                continue
            except Exception as e:
                print(f"⚠️  Error processing line {line_num}: {e}")
                continue

    # compute statistics
    total = results['total_functions']
    if total == 0:
        print("❌ No valid functions found in the file.")
        return None

    print("\n" + "=" * 80)
    print("📊 Real-World Code Complexity Analysis (D2A Test Set)")
    print("=" * 80)
    print(f"Total Functions Analyzed: {total}")
    print(f"Total Lines of Code:      {results['total_lines']}")
    print(f"Avg Lines per Function:   {results['total_lines'] / total:.1f}")

    print(f"\n🔍 Auxiliary Logic Prevalence:")
    print(
        f"  - Functions with Logging:        {results['functions_with_logging']:>5} ({results['functions_with_logging'] / total * 100:>5.1f}%)")
    print(
        f"  - Functions with Defensive:      {results['functions_with_defensive']:>5} ({results['functions_with_defensive'] / total * 100:>5.1f}%)")
    print(
        f"  - Functions with Error Handling: {results['functions_with_error_handling']:>5} ({results['functions_with_error_handling'] / total * 100:>5.1f}%)")
    print(
        f"  - Functions with Assertions:     {results['functions_with_assertions']:>5} ({results['functions_with_assertions'] / total * 100:>5.1f}%)")
    print(
        f"  - Functions with Null Checks:    {results['functions_with_null_checks']:>5} ({results['functions_with_null_checks'] / total * 100:>5.1f}%)")

    print(f"\n📈 Noise Intensity:")
    avg_noise_lines = np.mean(results['avg_noise_lines_per_function'])
    avg_noise_ratio = np.mean(results['noise_line_ratio'])
    median_noise_ratio = np.median(results['noise_line_ratio'])
    print(f"  - Avg Auxiliary Lines per Function: {avg_noise_lines:.2f}")
    print(f"  - Avg Noise Ratio per Function:     {avg_noise_ratio * 100:.1f}%")
    print(f"  - Median Noise Ratio:                {median_noise_ratio * 100:.1f}%")

    print(f"\n📊 Noise Intensity by Function Length:")
    for length_bucket in sorted(results['noise_intensity_by_length'].keys()):
        ratios = results['noise_intensity_by_length'][length_bucket]
        avg_ratio = np.mean(ratios)
        print(f"  - {length_bucket:>3}-{length_bucket + 19:>3} lines: {avg_ratio * 100:>5.1f}% noise")

    print("=" * 80)

    # save detailed statistics to a file
    if output_file:
        print(f"\n💾 Saving detailed statistics to: {output_file}")
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("idx,length,noise_lines,noise_ratio,logging,defensive,error_handling,assertions,null_checks\n")
            for stat in detailed_stats:
                f.write(
                    f"{stat['idx']},{stat['length']},{stat['noise_lines']},{stat['noise_ratio']:.4f},"
                    f"{stat['logging']},{stat['defensive']},{stat['error_handling']},"
                    f"{stat['assertions']},{stat['null_checks']}\n"
                )

    # generate a LaTeX table for the paper
    print("\n" + "=" * 80)
    print("📄 LaTeX Table (Copy to Paper)")
    print("=" * 80)
    print(r"\begin{table}[h]")
    print(r"\centering")
    print(r"\caption{Real-World Code Complexity in D2A Test Set.}")
    print(r"\label{tab:real_world_noise}")
    print(r"\begin{tabular}{lcc}")
    print(r"\toprule")
    print(r"\textbf{Auxiliary Logic Type} & \textbf{Functions (\%)} & \textbf{Avg Lines per Function} \\")
    print(r"\midrule")
    print(
        f"Logging Statements & {results['functions_with_logging'] / total * 100:.1f}\\% & {avg_noise_lines:.2f} \\\\")
    print(
        f"Defensive Checks & {results['functions_with_defensive'] / total * 100:.1f}\\% & {avg_noise_lines:.2f} \\\\")
    print(
        f"Error Handling & {results['functions_with_error_handling'] / total * 100:.1f}\\% & {avg_noise_lines:.2f} \\\\")
    print(
        f"Assertions & {results['functions_with_assertions'] / total * 100:.1f}\\% & {avg_noise_lines:.2f} \\\\")
    print(r"\midrule")
    print(f"\\textbf{{Overall Noise Ratio}} & \\multicolumn{{2}}{{c}}{{{avg_noise_ratio * 100:.1f}\\%}} \\\\")
    print(r"\bottomrule")
    print(r"\end{tabular}")
    print(r"\end{table}")
    print("=" * 80)

    return results


def main():
    parser = argparse.ArgumentParser(description="Analyze real-world code complexity")
    parser.add_argument("--input", type=str, default=DEFAULT_INPUT_FILE,
                        help="Input JSONL file path")
    parser.add_argument("--output", type=str, default=None,
                        help="Output CSV file for detailed statistics (optional)")
    args = parser.parse_args()

    analyze_real_world_complexity(args.input, args.output)


if __name__ == "__main__":
    main()
