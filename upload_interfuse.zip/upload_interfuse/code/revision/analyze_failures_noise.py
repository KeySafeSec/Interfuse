import json
import re
import os
from collections import Counter


def classify_failure(code):
    """ classify errors based on code features (heuristic rules) """
    # 1. Domain-Specific APIs (custom memory management)
    if re.search(r'(?i)(ngx_|apr_|xml|custom|pool|my|internal_)\w*(malloc|free|alloc)', code):
        return "Domain APIs"

    # 2. Deep Aliasing (deep pointer/structure references)
    if re.search(r'\w+->\w+->\w+', code) or code.count('*') > 5:
        return "Deep Aliasing"

    # 3. Symbolic/Complex Conditions (complex numeric conditions)
    if re.search(r'0x[0-9A-Fa-f]+', code) or re.search(r'\b(if|while)\s*\(.*(&&|\|\|).*\)', code):
        return "Symbolic Cond"

    # 4. Implicit Data Flow (implicit data flow)
    if "extern" in code or "static" in code:
        return "Implicit Flow"

    # 5. Noise/Defensive (if the error comes from the noise experiment)
    if "printf" in code or "log_" in code or "assert" in code:
        return "Noise Interference"

    return "Complex Logic"


def main():
    # keep the path unchanged
    input_file = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/output/run_unixcoder_test_noisy/offline_error_analysis_fn.jsonl"

    if not os.path.exists(input_file):
        print(f"❌ 文件未找到: {input_file}")
        return

    categories = Counter()
    total = 0

    print(f"正在分析错误样本: {os.path.basename(input_file)} ...")

    with open(input_file, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                data = json.loads(line)

                # ★★★ fix: read 'code' first; if unavailable, then try 'original_func' ★★★
                code = data.get('code', data.get('original_func', ''))

                if not code:
                    # debug: if a row exists but no code is present, print the keys for inspection
                    # print(f"Warning: No code found in keys: {data.keys()}")
                    continue

                cat = classify_failure(code)
                categories[cat] += 1
                total += 1
            except Exception as e:
                continue

    if total == 0:
        print("未找到有效样本。")
        return

    print("\n" + "=" * 40)
    print("Failure Taxonomy (For Table 11)")
    print("=" * 40)
    print(f"Total False Negatives Analyzed: {total}")
    print("-" * 40)

    for cat, count in categories.most_common():
        percentage = (count / total) * 100
        print(f"{cat:<20} : {count:4d} ({percentage:5.1f}%)")
    print("=" * 40)


if __name__ == "__main__":
    main()
