# analyze_weak_contrast_comprehensive_debug.py
"""综合分析：对比强度 + 单路径累积（调试版）"""

import json
import re
from collections import defaultdict
from difflib import SequenceMatcher


def calculate_path_contrast_strength(vuln_code, patch_code):
    """改进的路径对比强度计算"""

    def extract_operations(code):
        ops = {
            'malloc_vars': set(re.findall(r'(\w+)\s*=\s*(?:malloc|calloc|realloc)\s*\(', code)),
            'free_vars': set(re.findall(r'free\s*\(\s*(\w+)\s*\)', code)),
            'return_count': len(re.findall(r'\breturn\b', code)),
            'goto_labels': set(re.findall(r'goto\s+(\w+)', code)),
            'if_count': len(re.findall(r'\bif\s*\(', code)),
        }
        return ops

    vuln_ops = extract_operations(vuln_code)
    patch_ops = extract_operations(patch_code)

    similarity = SequenceMatcher(None, vuln_code, patch_code).ratio()

    contrast_score = 0.0

    malloc_diff = vuln_ops['malloc_vars'].symmetric_difference(patch_ops['malloc_vars'])
    free_diff = vuln_ops['free_vars'].symmetric_difference(patch_ops['free_vars'])

    if malloc_diff:
        contrast_score += 0.3 * min(len(malloc_diff) / 2, 1.0)
    if free_diff:
        contrast_score += 0.3 * min(len(free_diff) / 2, 1.0)

    if vuln_ops['return_count'] != patch_ops['return_count']:
        contrast_score += 0.15
    if vuln_ops['goto_labels'] != patch_ops['goto_labels']:
        contrast_score += 0.10

    if vuln_ops['if_count'] != patch_ops['if_count']:
        contrast_score += 0.05

    contrast_score += (1 - similarity) * 0.25

    if contrast_score > 0.55:
        return contrast_score, "strong"
    elif contrast_score > 0.25:
        return contrast_score, "medium"
    else:
        return contrast_score, "weak"


def detect_single_trajectory_pattern_debug(vuln_code, patch_code, idx):
    """
    调试版：打印详细的检测过程
    """

    patterns = {
        'single_trajectory': False,
        'ref_count': False,
        'delayed_release': False,
        'gradual_leak': False,
    }

    debug_info = {
        'idx': idx,
        'vuln_mallocs': set(),
        'vuln_frees': set(),
        'patch_mallocs': set(),
        'patch_frees': set(),
        'new_frees': set(),
        'missing_frees': set(),
        'vuln_free_count': 0,
        'patch_free_count': 0,
        'vuln_branches': 0,
        'patch_branches': 0,
        'branch_increase': 0,
        'reason': ''
    }

    # 1. 提取资源操作
    vuln_mallocs = set(re.findall(r'(\w+)\s*=\s*(?:malloc|calloc|realloc)\s*\(', vuln_code))
    vuln_frees = set(re.findall(r'free\s*\(\s*(\w+)\s*\)', vuln_code))

    patch_mallocs = set(re.findall(r'(\w+)\s*=\s*(?:malloc|calloc|realloc)\s*\(', patch_code))
    patch_frees = set(re.findall(r'free\s*\(\s*(\w+)\s*\)', patch_code))

    debug_info['vuln_mallocs'] = vuln_mallocs
    debug_info['vuln_frees'] = vuln_frees
    debug_info['patch_mallocs'] = patch_mallocs
    debug_info['patch_frees'] = patch_frees

    # 2. 计算差异
    new_frees = patch_frees - vuln_frees
    missing_frees = vuln_mallocs - vuln_frees

    debug_info['new_frees'] = new_frees
    debug_info['missing_frees'] = missing_frees

    vuln_free_count = len(re.findall(r'\bfree\s*\(', vuln_code))
    patch_free_count = len(re.findall(r'\bfree\s*\(', patch_code))

    debug_info['vuln_free_count'] = vuln_free_count
    debug_info['patch_free_count'] = patch_free_count

    # 3. 检测分支变化
    vuln_branches = len(re.findall(r'\b(if|else|switch|case)\b', vuln_code))
    patch_branches = len(re.findall(r'\b(if|else|switch|case)\b', patch_code))
    branch_increase = patch_branches - vuln_branches

    debug_info['vuln_branches'] = vuln_branches
    debug_info['patch_branches'] = patch_branches
    debug_info['branch_increase'] = branch_increase

    # 4. 判断是否为单路径
    is_single_trajectory = False

    # 情况1：patch新增了free操作
    if new_frees and vuln_mallocs:
        is_single_trajectory = True
        debug_info['reason'] = f"New frees: {new_frees}"

    # 情况2：patch中free数量增加
    elif patch_free_count > vuln_free_count and vuln_mallocs:
        is_single_trajectory = True
        debug_info['reason'] = f"Free count increased: {vuln_free_count} -> {patch_free_count}"

    # 情况3：vuln中缺失的free在patch中补上了
    elif missing_frees and (missing_frees & patch_frees):
        is_single_trajectory = True
        debug_info['reason'] = f"Missing frees fixed: {missing_frees & patch_frees}"

    # 情况4：极端放宽 - 只要有malloc且patch有任何free变化
    elif vuln_mallocs and patch_frees and (vuln_frees != patch_frees or vuln_free_count != patch_free_count):
        is_single_trajectory = True
        debug_info['reason'] = f"Free operations changed"

    else:
        debug_info['reason'] = "No single-trajectory pattern detected"

    # 5. 排除多路径修复
    if branch_increase > 3:
        is_single_trajectory = False
        debug_info['reason'] += f" (but excluded: branch_increase={branch_increase})"

    # 6. 如果确定是单路径，进行细分
    if is_single_trajectory:
        patterns['single_trajectory'] = True

        # 引用计数错误
        if re.search(r'\b(ref|count|retain|release)\b', vuln_code, re.IGNORECASE):
            patterns['ref_count'] = True

        # 延迟释放bug
        if not vuln_frees and patch_frees:
            patterns['delayed_release'] = True

        # 渐进式泄漏
        if re.search(r'\b(for|while)\b.*\{[^}]*\b(malloc|calloc)\b', vuln_code, re.DOTALL):
            if not re.search(r'\b(for|while)\b.*\{[^}]*\bfree\b', vuln_code, re.DOTALL):
                patterns['gradual_leak'] = True

    return patterns, debug_info


def comprehensive_analysis_debug():
    """调试版综合分析"""

    print("=" * 100)
    print("🔬 DEBUG VERSION: Analyzing Single-Trajectory Detection")
    print("=" * 100)
    print("\n📂 Loading data...")

    with open(
            '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/test_cdata_merged.jsonl',
            'r') as f:
        data = [json.loads(line) for line in f]

    predictions = {}
    with open(
            '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/output/run_unixcoder_v5.0_mem_op/predictions_overall.txt',
            'r') as f:
        next(f)
        for line in f:
            parts = line.strip().split('\t')
            if len(parts) >= 3:
                predictions[len(predictions)] = {
                    'pred': int(parts[0]),
                    'true': int(parts[1]),
                    'prob': float(parts[2])
                }

    print(f"✅ Loaded {len(data)} samples and {len(predictions)} predictions\n")

    # 统计各种情况
    stats = {
        'has_malloc': 0,
        'has_free': 0,
        'new_frees': 0,
        'free_count_increase': 0,
        'missing_frees_fixed': 0,
        'any_free_change': 0,
        'excluded_by_branches': 0,
        'single_trajectory': 0
    }

    debug_samples = []

    for idx, sample in enumerate(data[:100]):  # 先分析前100个样本
        if idx not in predictions:
            continue

        vuln_code = sample.get('func', '')
        patch_code = sample.get('func_after', '')

        patterns, debug_info = detect_single_trajectory_pattern_debug(vuln_code, patch_code, idx)

        # 统计
        if debug_info['vuln_mallocs']:
            stats['has_malloc'] += 1
        if debug_info['vuln_frees']:
            stats['has_free'] += 1
        if debug_info['new_frees']:
            stats['new_frees'] += 1
        if debug_info['patch_free_count'] > debug_info['vuln_free_count']:
            stats['free_count_increase'] += 1
        if debug_info['missing_frees'] and (debug_info['missing_frees'] & debug_info['patch_frees']):
            stats['missing_frees_fixed'] += 1
        if debug_info['vuln_frees'] != debug_info['patch_frees'] or debug_info['vuln_free_count'] != debug_info[
            'patch_free_count']:
            stats['any_free_change'] += 1
        if debug_info['branch_increase'] > 3:
            stats['excluded_by_branches'] += 1
        if patterns['single_trajectory']:
            stats['single_trajectory'] += 1

        # 收集有潜力的样本
        if debug_info['vuln_mallocs'] and (
                debug_info['new_frees'] or debug_info['patch_free_count'] > debug_info['vuln_free_count']):
            debug_samples.append(debug_info)

    # 打印统计结果
    print("=" * 100)
    print("📊 DETECTION STATISTICS (First 100 samples)")
    print("=" * 100)
    print(f"  - Samples with malloc:              {stats['has_malloc']}")
    print(f"  - Samples with free in vuln:        {stats['has_free']}")
    print(f"  - Samples with new frees in patch:  {stats['new_frees']}")
    print(f"  - Samples with free count increase: {stats['free_count_increase']}")
    print(f"  - Samples with missing frees fixed: {stats['missing_frees_fixed']}")
    print(f"  - Samples with any free change:     {stats['any_free_change']}")
    print(f"  - Excluded by branch increase:      {stats['excluded_by_branches']}")
    print(f"  - Final single-trajectory count:    {stats['single_trajectory']}")
    print("=" * 100)

    # 展示有潜力的样本
    if debug_samples:
        print(f"\n🔬 POTENTIAL SINGLE-TRAJECTORY SAMPLES:")
        print("-" * 100)

        for i, info in enumerate(debug_samples[:5], 1):
            print(f"\nSample {i} (IDX: {info['idx']}):")
            print(f"  Vuln mallocs: {info['vuln_mallocs']}")
            print(f"  Vuln frees:   {info['vuln_frees']}")
            print(f"  Patch frees:  {info['patch_frees']}")
            print(f"  New frees:    {info['new_frees']}")
            print(f"  Missing frees: {info['missing_frees']}")
            print(f"  Free count:   {info['vuln_free_count']} -> {info['patch_free_count']}")
            print(
                f"  Branches:     {info['vuln_branches']} -> {info['patch_branches']} (increase: {info['branch_increase']})")
            print(f"  Reason:       {info['reason']}")
            print("-" * 100)
    else:
        print(f"\n⚠️  No potential single-trajectory samples found in first 100 samples!")

    # 手动检查几个样本
    print(f"\n🔍 MANUAL INSPECTION OF FIRST 3 SAMPLES:")
    print("=" * 100)

    for idx in range(min(3, len(data))):
        sample = data[idx]
        vuln_code = sample.get('func', '')
        patch_code = sample.get('func_after', '')

        print(f"\n--- Sample {idx} ---")
        print(f"Vulnerable code (first 300 chars):")
        print(vuln_code[:300])
        print(f"\nPatched code (first 300 chars):")
        print(patch_code[:300])
        print("-" * 100)

    return stats, debug_samples


if __name__ == "__main__":
    stats, samples = comprehensive_analysis_debug()
