import json
import re
import os
import numpy as np

# ================= 配置区域 =================
# 1. 原始 Clean 数据
CLEAN_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/pkl_dir/test_cdata_noisy_synced.jsonl"
# 注意：这里应该用最原始的 Clean 数据，如果你找不到 clean 的 jsonl，
# 可以用 test_cdata_noisy_synced.jsonl (假设这是没加噪声之前的基准，或者你可以指定你最早的那个 jsonl)

# 2. Combined 噪声数据
COMBINED_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/pkl_dir/test_noisy_combined_synced.jsonl"


# ===========================================

def extract_variables(code):
    """
    粗略提取代码中的变量名/标识符数量。
    排除关键字、数字、字符串字面量。
    """
    # C 语言常见关键字 (排除掉)
    keywords = {
        'if', 'else', 'while', 'for', 'return', 'int', 'char', 'void', 'long', 'struct',
        'break', 'continue', 'switch', 'case', 'default', 'goto', 'static', 'extern',
        'const', 'unsigned', 'signed', 'sizeof', 'typedef', 'union', 'volatile', 'auto',
        'register', 'enum', 'float', 'double', 'include', 'define', 'ifdef', 'endif'
    }

    # 移除字符串内容 "..."
    code = re.sub(r'".*?"', '', code)
    # 移除注释
    code = re.sub(r'//.*', '', code)
    code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)

    # 提取所有单词
    words = re.findall(r'\b[a-zA-Z_]\w*\b', code)

    # 过滤关键字
    vars = [w for w in words if w not in keywords]

    # 返回去重后的变量数量 (代表涉及了多少个不同的对象)
    return len(set(vars))


def analyze_file(filepath, label):
    if not os.path.exists(filepath):
        print(f"❌ File not found: {filepath}")
        return []

    var_counts = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                item = json.loads(line)
                code = item.get('func', '')
                count = extract_variables(code)
                var_counts.append(count)
            except:
                continue

    avg = np.mean(var_counts)
    print(f"[{label}] Processed {len(var_counts)} samples.")
    print(f"    Avg Unique Variables per Function: {avg:.2f}")
    return var_counts


def main():
    print("Analyzing Multi-Variable Complexity...")
    print("=" * 50)

    # 如果您不确定 CLEAN_FILE 是哪个，可以用 Combined 里的代码去掉噪声行来模拟，
    # 或者直接对比 Logging 和 Combined 也可以。
    # 这里假设您有 Clean 的文件，如果没有，请把 CLEAN_FILE 换成 Logging 的文件作为对比基准也可以。

    # 尝试读取
    clean_counts = analyze_file(CLEAN_FILE, "Baseline (Standard)")
    combined_counts = analyze_file(COMBINED_FILE, "Combined (Multi-Variable)")

    if clean_counts and combined_counts:
        avg_clean = np.mean(clean_counts)
        avg_comb = np.mean(combined_counts)
        increase = ((avg_comb - avg_clean) / avg_clean) * 100

        print("-" * 50)
        print(f"📈 Complexity Increase: +{increase:.1f}% more unique variables/objects involved.")
        print("=" * 50)


if __name__ == "__main__":
    main()
