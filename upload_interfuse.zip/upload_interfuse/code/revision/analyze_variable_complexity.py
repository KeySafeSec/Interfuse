import json
import re
import os
import numpy as np

# ================= configuration section =================
# 1. original clean data
CLEAN_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/pkl_dir/test_cdata_noisy_synced.jsonl"
# note: use the original clean data here; if the clean JSONL cannot be found, 
# test_cdata_noisy_synced.jsonl can be used as a baseline before noise injection, or specify the earliest available JSONL

# 2. Combined noisy data
COMBINED_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/pkl_dir/test_noisy_combined_synced.jsonl"


# ===========================================

def extract_variables(code):
    """ roughly extract the number of variable names/identifiers in the code. exclude keywords, numbers, and string literals. """
    # common C keywords (excluded)
    keywords = {
        'if', 'else', 'while', 'for', 'return', 'int', 'char', 'void', 'long', 'struct',
        'break', 'continue', 'switch', 'case', 'default', 'goto', 'static', 'extern',
        'const', 'unsigned', 'signed', 'sizeof', 'typedef', 'union', 'volatile', 'auto',
        'register', 'enum', 'float', 'double', 'include', 'define', 'ifdef', 'endif'
    }

    # remove string contents "..."
    code = re.sub(r'".*?"', '', code)
    # remove comments
    code = re.sub(r'//.*', '', code)
    code = re.sub(r'/\*.*?\*/', '', code, flags=re.DOTALL)

    # extract all words
    words = re.findall(r'\b[a-zA-Z_]\w*\b', code)

    # filter keywords
    vars = [w for w in words if w not in keywords]

    # return the number of unique variables, representing how many distinct objects are involved
    return len(set(vars))


def analyze_file(filepath, label):
    if not os.path.exists(filepath):
        print(f"❌ File not found: {filepath}")
        return []

    var_counts = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                item = json.loads(line)
                code = item.get('func', '')
                count = extract_variables(code)
                var_counts.append(count)
            except:
                continue

    avg = np.mean(var_counts)
    print(f"[{label}] Processed {len(var_counts)} samples.")
    print(f"    Avg Unique Variables per Function: {avg:.2f}")
    return var_counts


def main():
    print("Analyzing Multi-Variable Complexity...")
    print("=" * 50)

    # if CLEAN_FILE is uncertain, simulate clean data by removing noise lines from Combined, 
    # or compare Logging and Combined directly.
    # this assumes a Clean file is available; otherwise use the Logging file as the comparison baseline.

    # try reading
    clean_counts = analyze_file(CLEAN_FILE, "Baseline (Standard)")
    combined_counts = analyze_file(COMBINED_FILE, "Combined (Multi-Variable)")

    if clean_counts and combined_counts:
        avg_clean = np.mean(clean_counts)
        avg_comb = np.mean(combined_counts)
        increase = ((avg_comb - avg_clean) / avg_clean) * 100

        print("-" * 50)
        print(f"📈 Complexity Increase: +{increase:.1f}% more unique variables/objects involved.")
        print("=" * 50)


if __name__ == "__main__":
    main()
