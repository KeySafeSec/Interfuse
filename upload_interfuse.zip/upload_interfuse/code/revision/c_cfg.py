# c_cfg.py (FINAL FIXED VERSION)

import networkx as nx
import random
from typing import List, Tuple, Optional
import logging
import sys
import tree_sitter
import os
import re
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.animation import FuncAnimation
from matplotlib.patches import FancyArrowPatch
import matplotlib.animation as animation
from graphviz import Digraph

# logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('genetic_path_finder.log', mode='w'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# --- global feature definitions ---
DEEPFA_PATTERNS = {
    'pointers': re.compile(r'\*|->|&'),
    'arrays': re.compile(r'\[\s*\w*\s*\]'),
    'arithmetic': re.compile(r'\+\+|--|\+=|-=|\*=|/=|%='),
    'sensitive_calls': {
        'strcpy', 'strcat', 'sprintf', 'vsprintf', 'gets', 'scanf',
        'sscanf', 'fscanf', 'vscanf', 'vsscanf', 'vfscanf', 'memcpy',
        'memmove', 'malloc', 'calloc', 'realloc', 'free', 'system',
        'exec', 'popen', 'access'
    }
}
# precompile the sensitive-function regex for later use
sensitive_calls_regex = re.compile(r'\b(' + '|'.join(DEEPFA_PATTERNS['sensitive_calls']) + r')\b')
NUM_HEURISTIC_FEATURES = 4


def analyze_path_for_features(path_as_code_strings: List[str]) -> List[int]:
    """analyze features contained in path code fragments"""
    if not path_as_code_strings:
        return [0] * NUM_HEURISTIC_FEATURES
    full_path_code = "\n".join(path_as_code_strings)
    has_pointer = 1 if DEEPFA_PATTERNS['pointers'].search(full_path_code) else 0
    has_array = 1 if DEEPFA_PATTERNS['arrays'].search(full_path_code) else 0
    has_arithmetic = 1 if DEEPFA_PATTERNS['arithmetic'].search(full_path_code) else 0
    has_sensitive_call = 1 if sensitive_calls_regex.search(full_path_code) else 0
    return [has_pointer, has_array, has_arithmetic, has_sensitive_call]


class GeneticPathFinder:
    def __init__(self, graph: nx.DiGraph, start_node: int, end_nodes: list,
                 cross_call_edges: set, source_lines: list, weights: dict = None):
        self.graph = graph
        self.start_node = start_node
        self.end_nodes = end_nodes if end_nodes else []
        self.cross_call_edges = cross_call_edges
        self.source_lines = source_lines

        # --- weight handling ---
        self.default_weights = {'w_c': 0.3, 'w_x': 0.2, 'w_d': 0.4, 'w_l': 0.1}
        self.weights = weights if weights else self.default_weights
        # ---------------

        self.all_nodes = set(self.graph.nodes())
        self.covered_global = set()
        self.population = []
        self.population_tuples = set()
        self.current_mutation_rate = 0.25
        self.logger = logging.getLogger("GeneticPathFinder")
        self.logger.setLevel(logging.INFO)

        self.fitness_cache = {}

    def _calculate_heuristic_risk_score(self, path: list) -> float:
        """compute the path risk heuristic score"""
        if not path: return 0.0
        path_as_code_strings = [self.source_lines[node_id - 1] for node_id in path if
                                1 <= node_id <= len(self.source_lines)]
        features = analyze_path_for_features(path_as_code_strings)
        pointer_score = features[0] * 20.0
        array_score = features[1] * 15.0
        arithmetic_score = features[2] * 10.0
        sensitive_call_score = features[3] * 30.0
        return pointer_score + array_score + arithmetic_score + sensitive_call_score

    def calculate_fitness(self, individual: list, risk_weight=0.6) -> float:
        """fitness computation with dynamic weights"""
        path_tuple = tuple(individual)
        if path_tuple in self.fitness_cache:
            return self.fitness_cache[path_tuple]

        if not individual: return -1000.0

        # get weights
        w_c = self.weights.get('w_c', 0.3)
        w_d = self.weights.get('w_d', 0.4)
        w_x = self.weights.get('w_x', 0.2)
        w_l = self.weights.get('w_l', 0.1)

        # 1. Coverage
        new_nodes = set(individual) - self.covered_global
        norm_coverage = len(new_nodes) * 2.0
        score_coverage = norm_coverage * w_c * 10.0

        # 2. Cross-Call
        path_edges = set(zip(individual[:-1], individual[1:]))
        cross_call_count = len(self.cross_call_edges.intersection(path_edges))
        score_xcall = cross_call_count * w_x * 20.0

        # 3. Diversity (Penalty)
        redundancy_count = sum(1 for node in individual if node in self.covered_global)
        score_redundancy = redundancy_count * w_d * 5.0

        # 4. Length (Penalty)
        length_penalty = 0.0
        if len(individual) > 30:
            length_penalty = (len(individual) - 30) * 1.0
        else:
            length_penalty = len(individual) * 0.1
        score_length = length_penalty * w_l * 10.0

        # 5. Risk Heuristic
        heuristic_score = self._calculate_heuristic_risk_score(individual)

        # combined score
        structural_fitness = score_coverage + score_xcall - score_redundancy - score_length
        final_fitness = structural_fitness + (heuristic_score * 0.5)

        self.fitness_cache[path_tuple] = final_fitness
        return final_fitness

    def initialize_population(self, population_size=50):
        """[Fixed version]initialize the population while avoiding the set.search error"""
        self.population = []
        self.population_tuples = set()

        # find all nodes containing risk-related keywords
        risk_nodes = []

        # define the list of regex patterns to check, including the global sensitive_calls_regex
        check_patterns = [
            DEEPFA_PATTERNS['pointers'],
            DEEPFA_PATTERNS['arrays'],
            DEEPFA_PATTERNS['arithmetic'],
            sensitive_calls_regex  # use the precompiled regex object rather than a set
        ]

        for i, line_content in enumerate(self.source_lines):
            line_num = i + 1
            if line_num in self.graph.nodes():
                # iterate through the list for regex matching
                if any(pattern.search(line_content) for pattern in check_patterns):
                    risk_nodes.append(line_num)

        # strategy A: target risk-related nodes
        targets = random.sample(risk_nodes, min(len(risk_nodes), population_size // 3)) if risk_nodes else []
        for target in targets:
            try:
                path = nx.shortest_path(self.graph, self.start_node, target)
                if self.end_nodes:
                    path_to_end = self.random_dfs_optimized(target, max_depth=20)
                    if path_to_end:
                        full_path = path[:-1] + path_to_end
                        if self.validate_path(full_path):
                            self._add_to_population(full_path)
            except nx.NetworkXNoPath:
                pass

        # strategy B: cross-function calls
        cross_call_paths_to_try = list(self.cross_call_edges)
        random.shuffle(cross_call_paths_to_try)
        for u_call, v_entry in cross_call_paths_to_try[:population_size // 3]:
            try:
                path_to_call = nx.shortest_path(self.graph, self.start_node, u_call)
                path_to_end = self.random_dfs_optimized(u_call, max_depth=20)
                if path_to_end:
                    full_path = path_to_call[:-1] + path_to_end
                    if self.validate_path(full_path):
                        self._add_to_population(full_path)
            except:
                pass

        # strategy C: supplement with random DFS
        attempts = 0
        while len(self.population) < population_size and attempts < population_size * 5:
            candidate = self.random_dfs_optimized(self.start_node, max_depth=40)
            if candidate:
                self._add_to_population(candidate)
            attempts += 1

    def _add_to_population(self, path):
        if tuple(path) not in self.population_tuples:
            self.population.append(path)
            self.population_tuples.add(tuple(path))

    def evolve(self, generations=10, elite_size=2):
        if not self.population: return
        self.fitness_cache.clear()

        pop_with_fitness = sorted(
            [(p, self.calculate_fitness(p)) for p in self.population],
            key=lambda x: x[1], reverse=True
        )

        for gen in range(generations):
            elites = [p for p, f in pop_with_fitness[:elite_size]]
            children = []
            while len(children) < len(self.population) - len(elites):
                parents = self.roulette_wheel_selection(pop_with_fitness, 2)
                if not parents: continue
                child = self.crossover(parents[0], parents[1])
                if not child: continue
                child = self.mutate(child)
                child = self.local_search(child)
                if child and self.validate_path(child):
                    children.append(child)

            next_pop = elites + children
            pop_with_fitness = []
            for ind in next_pop:
                fitness = self.calculate_fitness(ind)
                pop_with_fitness.append((ind, fitness))

            pop_with_fitness.sort(key=lambda x: x[1], reverse=True)
            self.population = [p for p, f in pop_with_fitness]

    def roulette_wheel_selection(self, pop_with_fitness, num_to_select):
        total_fitness = sum(f for p, f in pop_with_fitness if f > 0)
        if total_fitness <= 0:
            return [p for p, f in random.sample(pop_with_fitness, min(num_to_select, len(pop_with_fitness)))]
        selected = []
        for _ in range(num_to_select):
            pick = random.uniform(0, total_fitness)
            current = 0
            for p, f in pop_with_fitness:
                if f > 0:
                    current += f
                    if current > pick:
                        selected.append(p)
                        break
        return selected if selected else [pop_with_fitness[0][0]] * num_to_select

    def random_dfs_optimized(self, start_node: int, max_depth: int = 50) -> Optional[List[int]]:
        path = [start_node]
        visited_on_path = {start_node}
        for _ in range(max_depth):
            current_node = path[-1]
            if self.end_nodes and current_node in self.end_nodes: break
            successors = list(self.graph.successors(current_node))
            if not successors: break
            unvisited_successors = [n for n in successors if n not in visited_on_path]
            if unvisited_successors:
                next_node = random.choice(unvisited_successors)
            else:
                if random.random() < 0.1 and len(path) > 1:
                    path.pop()
                    if current_node in visited_on_path: visited_on_path.remove(current_node)
                    continue
                else:
                    next_node = random.choice(successors)
            path.append(next_node)
            visited_on_path.add(next_node)
        if self.validate_path(path):
            return path
        return None

    def validate_path(self, path: List[int]) -> bool:
        if not path or not isinstance(path, list): return False
        for i in range(len(path) - 1):
            if not self.graph.has_edge(path[i], path[i + 1]):
                return False
        return True

    def crossover(self, parent1: List[int], parent2: List[int]) -> Optional[List[int]]:
        common_nodes = list(set(parent1) & set(parent2))
        if len(common_nodes) < 2: return random.choice([parent1, parent2])
        crossover_point = random.choice(common_nodes)
        try:
            idx1 = parent1.index(crossover_point)
            idx2 = parent2.index(crossover_point)
            child = parent1[:idx1] + parent2[idx2:]
            return child if self.validate_path(child) else None
        except ValueError:
            return None

    def mutate(self, path: List[int]) -> List[int]:
        if not path or random.random() > self.current_mutation_rate:
            return path
        uncovered = list(self.all_nodes - self.covered_global - set(path))
        if uncovered and random.random() < 0.5:
            try:
                mutation_point_idx = random.randint(0, len(path) - 1)
                start_node = path[mutation_point_idx]
                target_node = random.choice(uncovered)
                bridge = nx.shortest_path(self.graph, start_node, target_node)
                new_path = path[:mutation_point_idx] + bridge
                for _ in range(10):
                    successors = list(self.graph.successors(new_path[-1]))
                    if not successors: break
                    new_path.append(random.choice(successors))
                if self.validate_path(new_path):
                    return new_path
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                pass
        if len(path) > 2:
            idx = random.randint(1, len(path) - 1)
            u, v = path[idx - 1], path[idx]
            successors_of_u = list(self.graph.successors(u))
            if len(successors_of_u) > 1:
                options = [n for n in successors_of_u if n != v]
                if options:
                    inserted_node = random.choice(options)
                    try:
                        bridge_to_v = nx.shortest_path(self.graph, inserted_node, v)
                        mutated_path = path[:idx] + bridge_to_v
                        if self.validate_path(mutated_path):
                            return mutated_path
                    except (nx.NetworkXNoPath, nx.NodeNotFound):
                        pass
        return path

    def local_search(self, path: List[int]) -> List[int]:
        if not path: return []
        optimized_path = path.copy()
        for _ in range(15):
            current_tip = optimized_path[-1]
            try:
                bfs_tree = nx.bfs_tree(self.graph, current_tip, depth_limit=5)
                found_target = False
                for node in bfs_tree:
                    if node not in self.covered_global and node not in optimized_path:
                        bridge = nx.shortest_path(self.graph, current_tip, node)
                        optimized_path.extend(bridge[1:])
                        found_target = True
                        break
                if found_target:
                    continue
                else:
                    break
            except (nx.NodeNotFound):
                break
        return optimized_path


class C_CFG:
    def __init__(self, source_code=None):
        self.finlineno = []
        self.firstlineno = 1
        self.G = nx.DiGraph()
        self.coverage_threshold = 0.98
        self.edge_penalty = 1.5
        self.all_paths = []
        self.finder = None
        self.dece_node = []
        self.circle = []
        self.line_number = []
        self.current_scope = []
        self.logger = logging.getLogger(self.__class__.__name__)
        self.source_lines = source_code.splitlines() if source_code else []
        self.max_line = 0
        self.current_loop = None
        self.loop_stack = []
        self.loop_optimization = {
            'min_self_loops': True,
            'allow_types': {'while', 'do'},
            'infinite_loop_marks': {'conditions': ["1", "true", "!0"], 'update_clause': None}
        }
        self.func_entry_map: dict[str, int] = {}
        self.cross_call_edges: set[Tuple[int, int]] = set()

    def get_allpath(self,
                    max_paths=10,
                    generations=10,
                    population_size=25,
                    coverage_threshold=0.98,
                    weights=None
                    ) -> Tuple[int, List[List[int]], int, float]:
        """find paths with the genetic algorithm and support supplied weights"""
        all_paths = []
        unique_paths_set = set()
        covered_nodes = {self.firstlineno} if self.G.has_node(self.firstlineno) else set()
        all_nodes_in_graph = {n for n in self.G.nodes() if n != 0}
        total_nodes = len(all_nodes_in_graph)

        if not total_nodes or not self.G.has_node(self.firstlineno):
            self.logger.warning("CFG为空或缺少起始节点，无法生成路径。")
            return 0, [], total_nodes, 0.0

        if weights:
            self.logger.info(f"Using Custom Weights for GA: {weights}")
        else:
            self.logger.info("Using Default Weights for GA.")

        finder = GeneticPathFinder(
            self.G,
            self.firstlineno,
            self.finlineno,
            self.cross_call_edges,
            self.source_lines,
            weights=weights
        )

        finder.initialize_population(population_size=population_size)

        if not finder.population:
            self.logger.error("Failed to initialize a diverse population.")
            return 0, [], total_nodes, 0.0

        no_progress_count = 0
        max_no_progress = 5

        while len(all_paths) < max_paths:
            coverage_ratio = len(covered_nodes) / total_nodes if total_nodes > 0 else 0

            if coverage_ratio >= coverage_threshold or no_progress_count >= max_no_progress:
                self.logger.info(
                    f"Terminating search. Reason: {'Coverage threshold met' if coverage_ratio >= coverage_threshold else 'Progress stalled'}.")
                break

            finder.covered_global = covered_nodes.copy()
            finder.evolve(generations=generations, elite_size=max(2, int(population_size * 0.1)))

            if not finder.population:
                self.logger.error("Population collapsed during evolution.")
                break

            best_path = max(finder.population, key=lambda p: finder.calculate_fitness(p))
            newly_covered = set(best_path) - covered_nodes

            if not newly_covered:
                no_progress_count += 1
                finder.current_mutation_rate = min(0.5, finder.current_mutation_rate * 1.2)
            else:
                no_progress_count = 0
                finder.current_mutation_rate = 0.25

            if tuple(best_path) not in unique_paths_set:
                all_paths.append(best_path)
                unique_paths_set.add(tuple(best_path))
                covered_nodes.update(newly_covered)
            else:
                for i in range(len(finder.population)):
                    if random.random() < 0.8:
                        finder.population[i] = finder.mutate(finder.population[i])

        final_coverage = len(covered_nodes) / total_nodes if total_nodes > 0 else 0.0
        self.all_paths = all_paths
        return len(all_paths), all_paths, total_nodes - len(covered_nodes), final_coverage

    def run(self, root):
        code_text = root.text.decode('utf8')
        self.max_line = len(code_text.split('\n'))
        self.clean_code = root
        self.finlineno.append(root.end_point[0] + 1)
        self.ast_visit(root)

    def parse_ast_file(self, ast_code):
        self.run(ast_code)
        return ast_code

    def parse_ast(self, source_ast):
        self.run(source_ast)
        return source_ast

    def get_source(self, fn):
        try:
            f = open(fn, 'r')
            s = f.read()
            f.close()
            return s
        except IOError:
            return ''

    def ast_visit(self, node):
        method = getattr(self, "visit_" + node.type, None)
        if method:
            return method(node)
        else:
            return self.visit_piece(node)

    def visit_program(self, node):
        self.finlineno.append(node.children[-1].end_point[0] + 1)
        for index, z in enumerate(node.children):
            start = z.start_point[0] + 1
            end = min(z.end_point[0] + 2, self.max_line)
            for i in range(start, end):
                self.G.add_node(i)
            if self.firstlineno > z.start_point[0] + 1:
                self.firstlineno = z.start_point[0] + 1

            if z.type == "compound_statement":
                if index == len(node.children) - 1:
                    self.finlineno.append(z.end_point[0] + 1)
                self.ast_visit(z)
            elif z.type == "local_variable_declaration":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_translation_unit(self, node):
        self.finlineno.append(node.children[-1].end_point[0] + 1)
        last_child = node.children[-1]
        termination_line = min(last_child.end_point[0] + 1, self.max_line)
        self.finlineno.append(termination_line)
        self.G.add_node(termination_line)
        for index, z in enumerate(node.children):
            for i in range(z.start_point[0] + 1, z.end_point[0] + 2):
                self.G.add_node(i)
            if self.firstlineno > z.start_point[0] + 1:
                self.firstlineno = z.start_point[0] + 1
            if z.type == "function_definition":
                if index == len(node.children) - 1:
                    self.finlineno.append(z.end_point[0] + 1)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_function_definition(self, node):
        try:
            declarator = next((c for c in node.children if c.type == "function_declarator"), None)
            if declarator:
                ident = next((c2 for c2 in declarator.children if c2.type == "identifier"), None)
                if ident:
                    func_name = "".join(
                        self.source_lines[ident.start_point[0]: ident.end_point[0] + 1]
                    ).strip()
                else:
                    func_name = f"<anon@L{node.start_point[0] + 1}>"
            else:
                func_name = f"<anon@L{node.start_point[0] + 1}>"
            entry_line = node.start_point[0] + 1
            self.func_entry_map[func_name] = entry_line
            self.logger.debug(f"记录函数定义: {func_name} @ 行 {entry_line}")
        except Exception as e:
            self.logger.warning(f"提取函数名失败: {e}")

        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_compound_statement(self, node):
        for index, z in enumerate(node.children):
            if z.type == "for_statement":
                self.ast_visit(z)
            elif z.type == "enhanced_for_statement":
                self.ast_visit(z)
            elif z.type == "while_statement":
                self.ast_visit(z)
            elif z.type == "do_statement":
                self.ast_visit(z)
            elif z.type == "try_with_resources_statement":
                self.ast_visit(z)
            elif z.type == "assert_statement":
                self.ast_visit(z)
            elif z.type == "switch_statement":
                self.ast_visit(z)
            elif z.type == "case_statement":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.ast_visit(z)
            elif z.type == "switch_block":
                self.ast_visit(z)
            elif z.type == "switch_block_statement_group":
                self.ast_visit(z)
            elif z.type == "labeled_statement":
                self.ast_visit(z)
            elif z.type == "continue_statement":
                self.ast_visit(z)
            elif z.type == "try_statement":
                self.ast_visit(z)
            elif z.type == "throw_statement":
                self.ast_visit(z)
            elif z.type == "if_statement":
                self.ast_visit(z)
            elif z.type == "synchronized_statement":
                self.ast_visit(z)
            elif z.type == "expression_statement":
                self.ast_visit(z)
            elif z.type == "local_variable_declaration":
                self.ast_visit(z)
            elif z.type == "return_statement":
                self.ast_visit(z)
            elif z.type == "compound_statement":
                self.ast_visit(z)
            elif z.type == "parenthesized_expression":
                self.ast_visit(z)
            elif z.type == "ERROR":
                self.ast_visit(z)
            elif z.type == "break_statement":
                self.ast_visit(z)
            elif z.type == "class_declaration":
                self.ast_visit(z)
            elif z.type == "declaration":
                self.ast_visit(z)
            elif z.type == "function_declarator":
                self.ast_visit(z)
            elif z.type == "}":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "{":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == ";":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            else:
                self.visit_piece(z)

        if len(node.children) > 0 and node.children[0].type == "{":
            self.G.add_edge(node.children[0].start_point[0] + 1, node.children[0].start_point[0] + 2, weight=1)
        if len(node.children) > 0 and node.children[-1].type == "}":
            self.G.add_edge(node.children[-1].start_point[0], node.children[-1].start_point[0] + 1, weight=1)

    def visit_piece(self, node):
        if node.type == "call_expression":
            try:
                caller_line = node.start_point[0] + 1
                ident = next((c for c in node.children if c.type == "identifier"), None)
                if ident:
                    call_name = "".join(self.source_lines[ident.start_point[0]:ident.end_point[0] + 1]).strip()
                else:
                    call_name = None

                if call_name and call_name in self.func_entry_map:
                    callee_entry = self.func_entry_map[call_name]
                    self.cross_call_edges.add((caller_line, callee_entry))
                    self.logger.debug(f"探测到跨函数调用: {call_name} @ 调用行 {caller_line} → 入口行 {callee_entry}")
                for c in node.children:
                    self.visit_piece(c)
            except Exception as e:
                self.logger.warning(f"探测函数调用失败: {e}")
            return

        if node.type == "for_statement":
            self.ast_visit(node)
        elif node.type == "enhanced_for_statement":
            self.ast_visit(node)
        elif node.type == "while_statement":
            self.ast_visit(node)
        elif node.type == "do_statement":
            self.ast_visit(node)
        elif node.type == "try_with_resources_statement":
            self.ast_visit(node)
        elif node.type == "assert_statement":
            self.ast_visit(node)
        elif node.type == "switch_statement":
            self.ast_visit(node)
        elif node.type == "switch_block":
            self.ast_visit(node)
        elif node.type == "switch_block_statement_group":
            self.ast_visit(node)
        elif node.type == "labeled_statement":
            self.ast_visit(node)
        elif node.type == "continue_statement":
            self.ast_visit(node)
        elif node.type == "try_statement":
            self.ast_visit(node)
        elif node.type == "throw_statement":
            self.ast_visit(node)
        elif node.type == "if_statement":
            self.ast_visit(node)
        elif node.type == "synchronized_statement":
            self.ast_visit(node)
        elif node.type == "expression_statement":
            self.ast_visit(node)
        elif node.type == "local_variable_declaration":
            self.ast_visit(node)
        elif node.type == "parenthesized_expression":
            self.ast_visit(node)
        elif node.type == "return_statement":
            self.ast_visit(node)
        elif node.type == "ERROR":
            self.ast_visit(node)
        elif node.type == "break_statement":
            self.ast_visit(node)
        elif node.type == "class_declaration":
            self.ast_visit(node)
        elif node.type == "declaration":
            self.ast_visit(node)
        elif node.type == "function_declarator":
            self.ast_visit(node)
        elif node.type == "compound_statement":
            self.ast_visit(node)
        elif node.type == "goto_statement":
            self.ast_visit(node)
        elif node.type == "preproc_if":
            self.ast_visit(node)
        elif node.type == "preproc_params":
            self.ast_visit(node)
        elif node.type == "pointer_declarator":
            self.ast_visit(node)
        elif node.type == "preproc_ifdef":
            self.ast_visit(node)
        elif node.type == "preproc_elif":
            self.ast_visit(node)
        elif node.type == "preproc_function_def":
            self.ast_visit(node)
        elif node.type == "preproc_call":
            self.ast_visit(node)
        elif node.type == "preproc_else":
            self.ast_visit(node)
        elif node.type == "preproc_def":
            self.ast_visit(node)
        elif node.type == "proproc_include":
            self.ast_visit(node)
        elif node.type == "preproc_defined":
            self.ast_visit(node)
        elif node.type == "function_definition":
            self.ast_visit(node)
        elif node.type == "}":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == "{":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == ";":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == "\n":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        else:
            pass

    def visit_function_declarator(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_class_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_pointer_declarator(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_enhanced_for_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.next_sibling is not None:
            self.G.add_edge(node.start_point[0] + 1, node.next_sibling.start_point[0] + 1, weight=1)
        else:
            self.G.add_edge(node.start_point[0] + 1, node.end_point[0] + 1, weight=1)
        self.circle.append((node.start_point[0] + 1, node.end_point[0] + 1))
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            elif z.type == "if_statement":
                for j in z.children:
                    if j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            elif z.type == "try_statement":
                for j in z.children:
                    if j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            elif z.type == "switch_statement":
                for j in z.children:
                    if j.type == "switch_block":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
                    elif j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            else:
                self.visit_piece(z)
                self.G.add_edge(z.end_point[0] + 1, node.start_point[0] + 1, weight=1)
        self.loopflag = node.end_point[0] + 1

    def visit_try_with_resources_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        body_node = {}
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
                body_node['bs'] = z.start_point[0] + 1
                body_node['be'] = z.end_point[0] + 1
            elif z.type == "finally_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['fs'] = z.start_point[0] + 1
                body_node['fe'] = z.end_point[0] + 1
                self.ast_visit(z)
            elif z.type == "catch_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['cs'] = z.start_point[0] + 1
                body_node['ce'] = z.end_point[0] + 1
                self.ast_visit(z)
            else:
                self.visit_piece(z)
        if 'be' in body_node and 'cs' in body_node:
            self.G.add_edge(body_node['be'], body_node['cs'], weight=1)
        if 'ce' in body_node and 'fs' in body_node:
            self.G.add_edge(body_node['ce'], body_node['fs'], weight=1)

    def visit_assert_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)
        if node.end_point[0] + 1 not in self.finlineno:
            self.finlineno.append(node.end_point[0] + 1)

    def visit_switch_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.circle.append((node.start_point[0] + 1, node.end_point[0] + 1))
        if node.next_sibling is not None:
            self.G.add_edge(node.start_point[0] + 1, node.next_sibling.start_point[0] + 1, weight=1)
        else:
            self.G.add_edge(node.start_point[0] + 1, node.end_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        if node.end_point[0] + 1 != self.finlineno[0]:
            self.G.add_edge(node.children[-1].end_point[0] + 1, node.end_point[0] + 2, weight=1)
        for z in node.children:
            if z.type == "switch_block":
                self.dece_node.append(z.start_point[0] + 1)
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                for i in range(len(z.children)):
                    if node.start_point[0] != z.children[i].start_point[0]:
                        self.G.add_edge(node.start_point[0] + 1, z.children[i].start_point[0] + 1, weight=1)
                self.ast_visit(z)
            elif z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_case_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_switch_block(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "switch_block_statement_group":
                self.ast_visit(z)

    def visit_switch_block_statement_group(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.ast_visit(z)

    def visit_labeled_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_goto_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_try_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        body_node = {}
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
                body_node['bs'] = z.start_point[0] + 1
                body_node['be'] = z.end_point[0] + 1
            elif z.type == "finally_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['fs'] = z.start_point[0] + 1
                body_node['fe'] = z.end_point[0] + 1
                self.ast_visit(z)
            elif z.type == "catch_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['cs'] = z.start_point[0] + 1
                body_node['ce'] = z.end_point[0] + 1
                self.ast_visit(z)
            else:
                self.visit_piece(z)
        if 'bs' in body_node and 'cs' in body_node:
            self.G.add_edge(body_node['be'], body_node['cs'], weight=1)
        if 'cs' in body_node and 'fs' in body_node:
            self.G.add_edge(body_node['ce'], body_node['fs'], weight=1)

    def visit_catch_clause(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_finally_clause(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_throw_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "object_creation_expression":
                self.ast_visit(z)
        if node.end_point[0] + 1 not in self.finlineno:
            self.finlineno.append(node.end_point[0] + 1)

    def visit_object_creation_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_argument_list(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_params(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#define":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "preproc_arg":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                if node.start_point[0] != node.end_point[0]:
                    for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                        self.G.add_edge(j, j + 1, weight=1)
            else:
                self.visit_piece(z)

    def visit_preproc_function_def(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_call(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_def(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_defined(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_include(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_ternary_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_synchronized_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for index, z in enumerate(node.children):
            if z.type == "compound_statement":
                self.ast_visit(z)

    def visit_expression_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_local_variable_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_ERROR(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0], node.end_point[0] + 1):
                self.G.add_edge(j, j + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_parenthesized_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0], node.end_point[0] + 1):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_if(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#if":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "preproc_else":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.visit_piece(z)
            elif z.type == "#endif":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                next_line = z.start_point[0] + 2
                if next_line <= self.max_line:
                    self.G.add_edge(z.start_point[0] + 1, next_line, weight=1)
            elif z.type == "preproc_elif":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_preproc_else(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_preproc_elif(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_preproc_ifdef(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#ifdef":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "#endif":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                next_line = z.start_point[0] + 2
                if next_line <= self.max_line:
                    self.G.add_edge(z.start_point[0] + 1, next_line, weight=1)
            else:
                self.visit_piece(z)

    def visit_if_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        self.G.add_node(cond_line, shape='diamond', label=f"IF@L{cond_line}")

        then_node = None
        for c in node.children:
            if c.type == "compound_statement":
                then_node = c
                break

        if self.G.has_edge(cond_line, cond_line + 1):
            self.G.remove_edge(cond_line, cond_line + 1)

        if then_node:
            then_start = then_node.start_point[0] + 1
            self.G.add_edge(cond_line, then_start, weight=1, label='then')
            self.ast_visit(then_node)
            then_end = self.get_last_child_line(then_node) + 1
            self.G.add_edge(then_end, end_line, weight=1, label='then_end')
        else:
            then_stmts = [c for c in node.children if c.type not in ("else_clause", "condition", "compound_statement")]
            if then_stmts:
                first_then = then_stmts[0]
                then_start = first_then.start_point[0] + 1
                self.G.add_edge(cond_line, then_start, weight=1, label='then')
                for idx, stmt in enumerate(then_stmts):
                    self.ast_visit(stmt)
                    if idx + 1 < len(then_stmts):
                        next_stmt = then_stmts[idx + 1]
                        self.G.add_edge(stmt.end_point[0] + 1, next_stmt.start_point[0] + 1, weight=1)
                then_end = then_stmts[-1].end_point[0] + 1
                self.G.add_edge(then_end, end_line + 1, weight=1, label='then_end')
            else:
                self.G.add_edge(cond_line, end_line + 1, weight=1, style='dashed')

        else_node = next((c for c in node.children if c.type == "else_clause"), None)
        if else_node:
            else_line = else_node.start_point[0] + 1
            self.G.add_node(else_line, shape='box', label=f"ELSE@L{else_line}")
            self.G.add_edge(cond_line, else_line, weight=1, label='else')

            compound_node = next((c for c in else_node.children if c.type == "compound_statement"), None)
            if compound_node:
                else_start = compound_node.start_point[0] + 1
                self.G.add_edge(else_line, else_start, weight=1)
                self.ast_visit(compound_node)
                else_end = self.get_last_child_line(compound_node) + 1
                self.G.add_edge(else_end, end_line, weight=1)
            else:
                last_stmt_end = else_line
                for child in else_node.children:
                    if child.type != "else":
                        self.ast_visit(child)
                        child_end = child.end_point[0] + 1
                        self.G.add_edge(last_stmt_end, child.start_point[0] + 1, weight=1)
                        last_stmt_end = child_end
                self.G.add_edge(last_stmt_end, end_line, weight=1)
        else:
            self.G.add_edge(cond_line, end_line, weight=1, style='dashed')

    def visit_while_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        self.G.add_edge(cond_line, cond_line + 1, weight=1, label='while_cond')
        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        body_node = None
        for c in node.children:
            if c.type == "compound_statement":
                body_node = c
                break
        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='while_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='while_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='while_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='while_exit')
        self.loop_stack.pop()

    def visit_for_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        self.G.add_edge(cond_line, cond_line + 1, weight=1, label='for_cond')
        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        body_node = None
        for c in node.children:
            if c.type == "compound_statement":
                body_node = c
                break
        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='for_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='for_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='for_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='for_exit')
        self.loop_stack.pop()

    def visit_do_statement(self, node):
        cond_line = node.children[-1].start_point[0] + 1
        end_line = node.end_point[0] + 1

        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        body_node = None
        for c in node.children:
            if c.type == "compound_statement":
                body_node = c
                break

        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='do_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='do_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='do_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='do_exit')
        self.loop_stack.pop()

    def visit_break_statement(self, node):
        start = node.start_point[0] + 1
        self.G.add_edge(start - 1, start, weight=1, label='break_entry')
        if self.loop_stack:
            exit_line = self.loop_stack[-1]['exit']
            self.G.add_edge(start, exit_line, weight=1, label='break')
        else:
            next_line = start + 1
            if next_line <= self.max_line:
                self.G.add_edge(start, next_line, weight=1, label='break_weak')
            else:
                for fin in self.finlineno:
                    self.G.add_edge(start, fin, weight=1, label='break_exit')

    def visit_continue_statement(self, node):
        start = node.start_point[0] + 1
        self.G.add_edge(start - 1, start, weight=1, label='continue_entry')
        if self.loop_stack:
            head_line = self.loop_stack[-1]['head']
            self.G.add_edge(start, head_line, weight=1, label='continue')
        else:
            next_line = start + 1
            if next_line <= self.max_line:
                self.G.add_edge(start, next_line, weight=1, label='continue_weak')
            else:
                for fin in self.finlineno:
                    self.G.add_edge(start, fin, weight=1, label='continue_exit')

    def visit_return_statement(self, node):
        start = node.start_point[0] + 1
        end = node.end_point[0] + 1
        for i in range(start, end):
            self.G.add_edge(i, i + 1, weight=1, label='return_seq')
        for fin in self.finlineno:
            self.G.add_edge(end, fin, weight=1, label='return_exit')

    def get_last_child_line(self, node):
        valid_children = [c for c in node.children if c.type not in ['{', '}', ';', 'comment', 'whitespace']]
        if not valid_children:
            return node.end_point[0]
        last_child = valid_children[-1]
        return self.get_last_child_line(last_child)

    def visit_generic_type(self, node):
        pass

    def visit_identifier(self, node):
        pass

    def visit_if(self, node):
        pass

    def visit_for(self, node):
        pass

    def visit_binary_expression(self, node):
        pass

    def print_isolated_nodes(self):
        isolated = list(nx.isolates(self.G))
        if isolated:
            print(f"孤立节点: {sorted(isolated)}")
        else:
            print("无孤立节点")

    def validate_graph(self):
        if 0 in self.G.nodes:
            self.G.remove_node(0)
            self.logger.warning("删除非法节点0")

        isolated = list(nx.isolates(self.G))
        if isolated:
            self.logger.warning(f"发现孤立节点: {isolated}")
            for line in sorted(isolated):
                prev_line = line - 1
                next_line = line + 1
                if prev_line in self.G.nodes:
                    self.G.add_edge(prev_line, line, weight=1)
                if next_line in self.G.nodes:
                    self.G.add_edge(line, next_line, weight=1)

        to_remove = []
        loop_heads = [loop[0] for loop in self.circle] if hasattr(self, "circle") else []
        for u, v in self.G.edges():
            if u == v and u not in loop_heads:
                to_remove.append((u, v))
        for edge in to_remove:
            self.G.remove_edge(*edge)
            self.logger.info(f"移除非循环节点自环边: {edge}")

        def is_control_flow_keyword(line):
            if line > len(self.source_lines): return False
            text = self.source_lines[line - 1].strip()
            return bool(re.match(r'^(else|case|default:|catch|finally|elif|#else)\b', text))

        def _has_non_sequential_exit(line):
            for _, v in self.G.out_edges(line):
                if v != line + 1: return True
            return False

        all_nodes = sorted(self.G.nodes)
        for i in range(len(all_nodes) - 1):
            curr = all_nodes[i]
            next_ = all_nodes[i + 1]
            if next_ != curr + 1 or self.G.has_edge(curr, next_): continue

            should_skip = False
            if _has_non_sequential_exit(curr): should_skip = True
            if is_control_flow_keyword(next_): should_skip = True

            if not should_skip:
                self.G.add_edge(curr, next_, weight=1)

    def is_non_statement_line(self, line_text):
        stripped = line_text.strip()
        if re.match(r'^else(\s+if)?$', stripped): return True
        return stripped in ["{", "}", ";", ""]
