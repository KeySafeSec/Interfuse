import json
import os
import glob
import re
from collections import Counter

# ================= 配置区域 =================
# 指向你最新的日志输出目录
LOG_DIR = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/output/run_unixcoder_v5.27_major_revision_mvd_op（复件）"

# 类别映射：确保覆盖你日志中出现的所有任务
TARGET_CATEGORIES = ["Overall", "d2a-BO", "d2a-IO", "d2a-NPD", "d2a-UAF"]


# ===========================================

def analyze_code_features(code):
    """
    深层代码特征提取：识别导致静态工具或模型误判的模式
    """
    features = []
    code_lower = code.lower()

    # --- 1. 指针与别名复杂度 ---
    if "**" in code:
        features.append("Multi-level Pointers (**)")
    if "->" in code:
        features.append("Struct Member Access (->)")
    ptr_count = code.count('*') - code.count('/*')  # 粗略排除注释
    if ptr_count > 4:
        features.append("High Pointer Density")

    # --- 2. 算术与循环累积 (针对 Integer Overflow) ---
    if any(op in code for op in ["+=", "*=", "<<=", ">>="]):
        features.append("Arithmetic Accumulation")
    if "for(" in code.replace(" ", "") or "while(" in code.replace(" ", ""):
        features.append("Loop Structure")

    # --- 3. 内存与数组操作 (针对 Buffer Overflow / UAF) ---
    if "malloc" in code_lower or "calloc" in code_lower:
        features.append("Dynamic Memory Allocation")
    if "free(" in code_lower:
        features.append("Memory Deallocation (free)")
    if re.search(r'\[.*\]', code):
        features.append("Array Indexing")
    if any(api in code_lower for api in ["memcpy", "memmove", "memset", "strncpy"]):
        features.append("Memory API Calls")

    # --- 4. 边界检查 (判断是否有防御逻辑) ---
    if "if" in code_lower and any(kw in code_lower for kw in ["size", "len", "limit", "max"]):
        features.append("Existing Boundary Check")

    # --- 5. 复杂控制流 ---
    if "goto" in code_lower:
        features.append("Control Flow: Goto")
    if "switch" in code_lower:
        features.append("Control Flow: Switch")

    return features


def process_file(filepath, error_type="FN"):
    """
    解析单个 JSONL 错误文件
    """
    total_samples = 0
    feature_counter = Counter()

    if not os.path.exists(filepath):
        return None

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    item = json.loads(line)
                    # 兼容不同版本的字段名
                    code = item.get('original_func') or item.get('func') or item.get('code', "")
                    if not code: continue

                    features = analyze_code_features(code)
                    feature_counter.update(features)
                    total_samples += 1
                except:
                    continue
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return None

    return {
        "count": total_samples,
        "features": feature_counter
    }


def main():
    print("=" * 60)
    print(f"🚀 MCCOVC Error Analysis System v2.0")
    print(f"Directory: {LOG_DIR}")
    print("=" * 60)

    for cat in TARGET_CATEGORIES:
        print(f"\n📊 [TASK: {cat.upper()}]")

        # 分别处理漏报 (FN) 和 误报 (FP)
        for error_kind in ["fn", "fp"]:
            file_name = f"error_analysis_{error_kind}_{cat}.jsonl"
            path = os.path.join(LOG_DIR, file_name)

            result = process_file(path, error_kind.upper())

            if not result or result["count"] == 0:
                continue

            kind_label = "Lacked Detection (漏报)" if error_kind == "fn" else "Over-sensitive (误报)"
            print(f"\n  --- {kind_label} | Total: {result['count']} ---")

            # 打印前 6 个最显著的特征
            for feat, count in result["features"].most_common(7):
                percentage = (count / result["count"]) * 100
                print(f"   [{percentage:5.1f}%] {feat}")

    print("\n" + "=" * 60)
    print("💡 Analysis Complete. Use these percentages in your Rebuttal/Paper.")


if __name__ == "__main__":
    main()
