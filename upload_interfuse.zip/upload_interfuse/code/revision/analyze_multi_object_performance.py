# analyze_multi_object_performance.py
"""
分析模型在多对象交互场景下的性能
目标：证明模型能够处理涉及多个变量/资源的复杂漏洞
"""

import json
import re
from collections import defaultdict
import numpy as np
import os

# ================= 配置区域 =================
DEFAULT_DATA_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/dataset/cdata/nobalance/test_cdata_merged.jsonl"
DEFAULT_PRED_FILE = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/20241127/MCCOVC/output/run_unixcoder_v5.0_mem_op/predictions_overall.txt"


class MultiObjectDetector:
    """检测代码中的多对象交互模式"""

    def __init__(self):
        # 资源分配模式
        self.alloc_patterns = [
            (re.compile(r'(\w+)\s*=\s*malloc\s*\('), 'malloc'),
            (re.compile(r'(\w+)\s*=\s*calloc\s*\('), 'calloc'),
            (re.compile(r'(\w+)\s*=\s*realloc\s*\('), 'realloc'),
            (re.compile(r'(\w+)\s*=\s*fopen\s*\('), 'fopen'),
            (re.compile(r'(\w+)\s*=\s*open\s*\('), 'open'),
            (re.compile(r'(\w+)\s*=\s*strdup\s*\('), 'strdup'),
        ]

        # 资源释放模式
        self.free_patterns = [
            (re.compile(r'free\s*\(\s*(\w+)\s*\)'), 'free'),
            (re.compile(r'fclose\s*\(\s*(\w+)\s*\)'), 'fclose'),
            (re.compile(r'close\s*\(\s*(\w+)\s*\)'), 'close'),
        ]

        # 指针赋值模式（可能导致别名）
        self.alias_patterns = [
            re.compile(r'(\w+)\s*=\s*(\w+)\s*;'),
            re.compile(r'(\w+)\s*=\s*(\w+)\s*->\s*\w+'),
            re.compile(r'(\w+)\s*=\s*&\s*(\w+)'),
        ]

    def extract_resource_operations(self, code):
        """提取代码中的资源分配和释放操作"""
        allocations = defaultdict(list)
        frees = defaultdict(list)

        for pattern, op_type in self.alloc_patterns:
            for match in pattern.finditer(code):
                var_name = match.group(1)
                allocations[var_name].append(op_type)

        for pattern, op_type in self.free_patterns:
            for match in pattern.finditer(code):
                var_name = match.group(1)
                frees[var_name].append(op_type)

        return allocations, frees

    def detect_aliases(self, code):
        """检测指针别名关系"""
        aliases = []

        for pattern in self.alias_patterns:
            for match in pattern.finditer(code):
                if len(match.groups()) >= 2:
                    var1, var2 = match.group(1), match.group(2)
                    if var1 not in ['int', 'char', 'void', 'return', 'if', 'for', 'while']:
                        aliases.append((var1, var2))

        return aliases

    def classify_complexity(self, code):
        """分类代码的复杂度"""
        allocations, frees = self.extract_resource_operations(code)
        aliases = self.detect_aliases(code)

        alloc_vars = set(allocations.keys())
        free_vars = set(frees.keys())

        unfreed = alloc_vars - free_vars
        freed_without_alloc = free_vars - alloc_vars

        alloc_count = len(alloc_vars)
        free_count = len(free_vars)
        has_mismatch = len(unfreed) > 0 or len(freed_without_alloc) > 0
        has_alias = len(aliases) > 0

        if alloc_count == 0 and free_count == 0:
            complexity_type = 'no_resource'
        elif alloc_count <= 1 and free_count <= 1 and not has_alias:
            complexity_type = 'single'
        elif alloc_count >= 2 or free_count >= 2:
            if has_mismatch or has_alias:
                complexity_type = 'multi_complex'
            else:
                complexity_type = 'multi_simple'
        else:
            complexity_type = 'single'

        return {
            'type': complexity_type,
            'alloc_count': alloc_count,
            'free_count': free_count,
            'mismatch': has_mismatch,
            'has_alias': has_alias,
            'unfreed_vars': list(unfreed),
            'freed_without_alloc': list(freed_without_alloc),
            'aliases': aliases[:5],
            'details': {
                'allocations': dict(allocations),
                'frees': dict(frees)
            }
        }


def load_predictions(pred_file):
    """加载预测结果（按行号索引）"""
    predictions = []

    if not os.path.exists(pred_file):
        print(f"⚠️  Prediction file not found: {pred_file}")
        return predictions

    print(f"📂 Loading predictions from: {os.path.basename(pred_file)}")

    with open(pred_file, 'r') as f:
        header = next(f).strip()
        print(f"   Header: {header}")

        for line in f:
            parts = line.strip().split('\t')
            if len(parts) >= 3:
                try:
                    pred = int(parts[0])
                    true = int(parts[1])
                    prob = float(parts[2])
                    predictions.append({
                        'pred': pred,
                        'true': true,
                        'prob': prob,
                        'correct': (pred == true)
                    })
                except ValueError:
                    continue

    print(f"✅ Loaded {len(predictions)} predictions")
    return predictions


def analyze_performance_by_complexity(data_file, pred_file):
    """按复杂度分析模型性能（使用行号匹配）"""

    detector = MultiObjectDetector()
    predictions = load_predictions(pred_file)

    if not predictions:
        print("❌ No predictions loaded. Please check the prediction file.")
        return None

    # 统计结果
    stats = {
        'single': {'total': 0, 'correct': 0, 'tp': 0, 'fp': 0, 'tn': 0, 'fn': 0, 'samples': []},
        'multi_simple': {'total': 0, 'correct': 0, 'tp': 0, 'fp': 0, 'tn': 0, 'fn': 0, 'samples': []},
        'multi_complex': {'total': 0, 'correct': 0, 'tp': 0, 'fp': 0, 'tn': 0, 'fn': 0, 'samples': []},
        'no_resource': {'total': 0, 'correct': 0, 'tp': 0, 'fp': 0, 'tn': 0, 'fn': 0, 'samples': []},
    }

    print(f"\n📂 Reading data file: {os.path.basename(data_file)}")

    data_samples = []
    with open(data_file, 'r', encoding='utf-8') as f:
        for line in f:
            try:
                item = json.loads(line)
                code = item.get('func', '')
                true_label = int(item.get('target', -1))
                idx = item.get('idx', '')

                if code and true_label != -1:
                    data_samples.append({
                        'idx': idx,
                        'code': code,
                        'true_label': true_label
                    })
            except:
                continue

    print(f"✅ Loaded {len(data_samples)} data samples")

    # 确保数据和预测数量一致
    min_len = min(len(data_samples), len(predictions))
    if len(data_samples) != len(predictions):
        print(f"⚠️  Warning: Data samples ({len(data_samples)}) != Predictions ({len(predictions)})")
        print(f"   Using first {min_len} samples")

    # 按行号匹配
    for i in range(min_len):
        sample = data_samples[i]
        pred_info = predictions[i]

        code = sample['code']
        true_label = sample['true_label']
        pred_label = pred_info['pred']
        is_correct = pred_info['correct']

        # 分类复杂度
        complexity = detector.classify_complexity(code)
        comp_type = complexity['type']

        # 更新统计
        stats[comp_type]['total'] += 1
        if is_correct:
            stats[comp_type]['correct'] += 1

        # 更新混淆矩阵
        if true_label == 1 and pred_label == 1:
            stats[comp_type]['tp'] += 1
        elif true_label == 0 and pred_label == 1:
            stats[comp_type]['fp'] += 1
        elif true_label == 0 and pred_label == 0:
            stats[comp_type]['tn'] += 1
        elif true_label == 1 and pred_label == 0:
            stats[comp_type]['fn'] += 1

        # 保存样本（每类保存3个）
        if len(stats[comp_type]['samples']) < 3:
            stats[comp_type]['samples'].append({
                'idx': sample['idx'],
                'true': true_label,
                'pred': pred_label,
                'correct': is_correct,
                'complexity': complexity,
                'code_snippet': code[:300] + '...' if len(code) > 300 else code
            })

    # 打印结果
    print("\n" + "=" * 100)
    print("📊 Performance Analysis by Multi-Object Complexity")
    print("=" * 100)

    print(
        f"\n{'Complexity Type':<20} | {'Samples':<10} | {'Accuracy':<10} | {'Precision':<10} | {'Recall':<10} | {'F1':<10}")
    print("-" * 100)

    for comp_type in ['single', 'multi_simple', 'multi_complex', 'no_resource']:
        s = stats[comp_type]
        total = s['total']

        if total == 0:
            continue

        accuracy = s['correct'] / total * 100

        # 计算 Precision, Recall, F1
        tp, fp, fn = s['tp'], s['fp'], s['fn']
        precision = tp / (tp + fp) * 100 if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) * 100 if (tp + fn) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        print(f"{comp_type:<20} | {total:<10} | {accuracy:<10.1f} | {precision:<10.1f} | {recall:<10.1f} | {f1:<10.1f}")

    print("=" * 100)

    # 计算性能差距（修复除零错误）
    all_total = sum(s['total'] for s in stats.values())

    if all_total == 0:
        print("\n⚠️  No samples processed. Please check data and prediction files.")
        return None

    single_acc = stats['single']['correct'] / stats['single']['total'] * 100 if stats['single']['total'] > 0 else 0
    multi_complex_acc = stats['multi_complex']['correct'] / stats['multi_complex']['total'] * 100 if \
    stats['multi_complex']['total'] > 0 else 0
    gap = single_acc - multi_complex_acc

    multi_total = stats['multi_simple']['total'] + stats['multi_complex']['total']

    print(f"\n💡 Key Insights:")
    print(f"  - Single-Object Accuracy:      {single_acc:.1f}%")
    print(f"  - Multi-Complex Accuracy:      {multi_complex_acc:.1f}%")
    print(f"  - Performance Gap:             {gap:+.1f}%")
    print(f"  - Multi-Object Prevalence:     {multi_total}/{all_total} ({multi_total / all_total * 100:.1f}%)")

    print("=" * 100)

    # 打印失败案例
    print("\n🔬 Sample Multi-Complex Cases:")
    print("-" * 100)

    for i, sample in enumerate(stats['multi_complex']['samples'][:3], 1):
        status = '✅ CORRECT' if sample['correct'] else '❌ FAILED'
        print(f"\nExample {i}: {status}")
        print(f"  IDX: {sample['idx']}")
        print(f"  True Label: {sample['true']}, Predicted: {sample['pred']}")
        print(f"  Complexity Details:")
        print(f"    - Allocations: {sample['complexity']['alloc_count']}")
        print(f"    - Frees: {sample['complexity']['free_count']}")
        print(f"    - Mismatch: {sample['complexity']['mismatch']}")
        print(f"    - Has Alias: {sample['complexity']['has_alias']}")
        if sample['complexity']['unfreed_vars']:
            print(f"    - Unfreed Variables: {', '.join(sample['complexity']['unfreed_vars'])}")
        print(f"  Code Snippet:\n{sample['code_snippet']}")
        print("-" * 100)

    # 生成 LaTeX 表格
    print("\n" + "=" * 100)
    print("📄 LaTeX Table (Copy to Paper)")
    print("=" * 100)
    print(r"\begin{table}[h]")
    print(r"\centering")
    print(r"\caption{Performance on Multi-Object Interaction Scenarios.}")
    print(r"\label{tab:multi_object_performance}")
    print(r"\begin{tabular}{lcccc}")
    print(r"\toprule")
    print(r"\textbf{Complexity Type} & \textbf{Samples} & \textbf{Accuracy} & \textbf{Recall} & \textbf{F1} \\")
    print(r"\midrule")

    for comp_type in ['single', 'multi_simple', 'multi_complex']:
        s = stats[comp_type]
        total = s['total']
        if total == 0:
            continue

        accuracy = s['correct'] / total * 100
        tp, fp, fn = s['tp'], s['fp'], s['fn']
        recall = tp / (tp + fn) * 100 if (tp + fn) > 0 else 0
        precision = tp / (tp + fp) * 100 if (tp + fp) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        type_name = comp_type.replace('_', ' ').title()
        pct = total / all_total * 100
        print(f"{type_name} & {total} ({pct:.1f}\\%) & {accuracy:.1f}\\% & {recall:.1f}\\% & {f1:.1f}\\% \\\\")

    print(r"\midrule")
    print(f"\\textbf{{Performance Gap}} & -- & \\textbf{{{gap:+.1f}\\%}} & -- & -- \\\\")
    print(r"\bottomrule")
    print(r"\end{tabular}")
    print(r"\end{table}")
    print("=" * 100)

    return stats


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=str, default=DEFAULT_DATA_FILE,
                        help="Path to test data JSONL file")
    parser.add_argument("--pred", type=str, default=DEFAULT_PRED_FILE,
                        help="Path to prediction results file")
    args = parser.parse_args()

    if not os.path.exists(args.data):
        print(f"❌ Data file not found: {args.data}")
        return

    if not os.path.exists(args.pred):
        print(f"❌ Prediction file not found: {args.pred}")
        return

    analyze_performance_by_complexity(args.data, args.pred)


if __name__ == "__main__":
    main()
