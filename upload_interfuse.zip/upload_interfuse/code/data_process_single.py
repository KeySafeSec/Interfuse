# build_combined_cfg_with_global_and_local_statements.py (final version - discard on failure)

import sys
import json
import pickle
import logging
import time
import random
import os
import networkx as nx
import numpy as np
from concurrent.futures import ProcessPoolExecutor, as_completed
import multiprocessing as mp
from tqdm import tqdm

# --- import custom modules (keep your version unchanged) ---
try:
    import parserTool.parse as ps
    from c_cfg import C_CFG, analyze_path_for_features, NUM_HEURISTIC_FEATURES
    from parserTool.utils import remove_comments_and_docstrings
    from parserTool.parse import Lang
except ImportError as e:
    print(f"错误：无法导入必要的自定义模块。请确保 'parserTool' 和 'c_cfg.py' 在您的PYTHONPATH中。错误信息: {e}")
    sys.exit(1)

# --- global logging configuration (keep your version unchanged) ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
if not logger.handlers:
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    ch.setFormatter(formatter)
    if not os.path.exists("logs"): os.makedirs("logs")
    fh = logging.FileHandler("logs/data_processing.log", mode='w', encoding='utf-8')
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger.addHandler(ch)
    logger.addHandler(fh)
    logger.propagate = False


# ==============================================================================
# --- multiprocessing initializer (recommended for maximum stability) ---
# ==============================================================================
def worker_init():
    worker_pid = os.getpid()
    logger.debug(f"Initializing worker process PID: {worker_pid}")


# ==============================================================================
# --- all helper functions (kept identical to your version; omitted here for brevity) ---
# ==============================================================================
def extract_pathtoken(gcode_map, path_sequence):
    seqtoken_out = []
    if not isinstance(gcode_map, dict): return []
    for path in path_sequence[:15]:
        path_lines = [gcode_map.get(node_id, '') for node_id in path]
        seq_code = '\n'.join(line for line in path_lines if line)
        if seq_code: seqtoken_out.append(seq_code)
    if not seqtoken_out and gcode_map:
        full_code = '\n'.join(gcode_map[k] for k in sorted(gcode_map.keys()))
        seqtoken_out.append(full_code)
    return sorted(seqtoken_out, key=len)


def get_function_definitions(clean_code: str):
    func_list = []
    try:
        ast = ps.tree_sitter_ast(clean_code, Lang.C)
        root = ast.root_node;
        lines = clean_code.splitlines()

        def recurse(node):
            if node.type == "function_definition":
                name = _find_function_name(node)
                if name:
                    start, end = node.start_point[0], node.end_point[0]
                    snippet = "\n".join(lines[start: end + 1])
                    func_list.append((name, snippet, start, end))
                return
            for c in node.children: recurse(c)

        recurse(root)
    except Exception:
        pass
    return func_list


def _find_function_name(func_node):
    if func_node.type == "identifier": return func_node.text.decode('utf8', errors='ignore')
    for c in func_node.children:
        name = _find_function_name(c)
        if name: return name
    return None


def find_call_sites_and_callees(func_code: str):
    result = []
    try:
        ast = ps.tree_sitter_ast(func_code, Lang.C)
        root = ast.root_node

        def recurse(node):
            if node.type == "call_expression":
                id_node = next((c for c in node.children if c.type == "identifier"), None)
                if id_node: result.append((id_node.start_point[0] + 1, id_node.text.decode("utf8", errors='ignore')))
                return
            for c in node.children: recurse(c)

        recurse(root)
    except Exception:
        pass
    return result


def select_allowed_functions(func_defs, all_call_sites, max_depth=3):
    if not func_defs: return set(), None
    func_names = {d[0] for d in func_defs}
    call_graph = {name: {callee for _, callee in sites if callee in func_names} for name, sites in
                  all_call_sites.items()}
    entry = "main" if "main" in call_graph else func_defs[0][0]
    allowed, queue, visited = set(), [(entry, 0)], set()
    while queue:
        fname, d = queue.pop(0)
        if fname in visited or d > max_depth: continue
        visited.add(fname);
        allowed.add(fname)
        for callee in call_graph.get(fname, []): queue.append((callee, d + 1))
    return allowed, entry


def process_content_to_combined_cfg(clean_code: str, max_call_depth: int = 3):
    func_defs = get_function_definitions(clean_code)
    if not func_defs: raise ValueError("No function definitions found.")
    all_call_sites = {name: find_call_sites_and_callees(code) for name, code, _, _ in func_defs}
    allowed_funcs, entry_func = select_allowed_functions(func_defs, all_call_sites, max_call_depth)
    if not entry_func: raise ValueError("No valid entry function within depth limit.")
    cfgs, entry_local, local_fin = {}, {}, {}
    for name, code_snippet, _, _ in func_defs:
        if name in allowed_funcs:
            # this try-except block builds a single CFG; skipping the function on failure is intentional
            try:
                cfg = C_CFG(source_code=code_snippet)
                cfg.parse_ast_file(ps.tree_sitter_ast(code_snippet, Lang.C).root_node)
                cfg.validate_graph()
                cfgs[name], entry_local[name], local_fin[name] = cfg, cfg.firstlineno, set(cfg.finlineno)
            except Exception as e:
                logger.warning(f"Failed to build local CFG for function '{name}': {e}")

    if not cfgs or entry_func not in cfgs: raise ValueError(
        f"Failed to build required CFGs. Entry func '{entry_func}' missing.")

    combined_graph, mapping, counter = nx.DiGraph(), {}, 1
    final_order = sorted(list(cfgs.keys()), key=lambda x: (x != entry_func, x))
    for fname in final_order:
        if fname in cfgs:
            local_nodes = sorted(list(cfgs[fname].G.nodes()))
            mapping[fname] = {local_ln: i + counter for i, local_ln in enumerate(local_nodes)}
            counter += len(local_nodes)
    for gid in range(1, counter): combined_graph.add_node(gid)
    for fname in final_order:
        if fname in cfgs:
            for u, v in cfgs[fname].G.edges():
                gu, gv = mapping[fname].get(u), mapping[fname].get(v)
                if gu and gv: combined_graph.add_edge(gu, gv)
    cross_call_edges = set()
    return_edges = set()

    for caller, sites in all_call_sites.items():
        if caller not in cfgs:
            continue

        caller_cfg = cfgs[caller]

        for line, callee in sites:
            if callee not in cfgs or callee not in entry_local:
                continue

            gu = mapping[caller].get(line)
            gv = mapping[callee].get(entry_local[callee])

            if gu and gv:
                # Existing legacy CALL transition: remains active for sampling.
                combined_graph.add_edge(gu, gv)
                cross_call_edges.add((gu, gv))

            # --------------------------------------------------------------
            # Structural RETURN-edge construction (non-invasive)
            # --------------------------------------------------------------
            # The caller's post-call site(s) are taken from the original local
            # CFG BEFORE the interprocedural CALL edge is considered.
            #
            # If the call is terminal and has no normal successor, use the
            # caller's local exit node(s) as the continuation target.
            if line in caller_cfg.G:
                caller_return_sites = list(caller_cfg.G.successors(line))
            else:
                caller_return_sites = []

            if not caller_return_sites:
                caller_return_sites = [
                    ln for ln in local_fin.get(caller, set())
                    if ln in caller_cfg.G
                ]

            callee_exit_sites = [
                ln for ln in local_fin.get(callee, set())
                if ln in cfgs[callee].G
            ]

            for callee_exit_local in callee_exit_sites:
                g_exit = mapping[callee].get(callee_exit_local)
                if not g_exit:
                    continue

                for caller_return_local in caller_return_sites:
                    g_return = mapping[caller].get(caller_return_local)
                    if g_return and g_exit != g_return:
                        return_edges.add((g_exit, g_return))

    merged_cfg = C_CFG(source_code="")
    merged_cfg.G = combined_graph
    merged_cfg.firstlineno = mapping[entry_func][entry_local[entry_func]]
    merged_cfg.finlineno = sorted(
        [mapping[fn].get(ln) for fn, fins in local_fin.items() if fn in mapping for ln in fins if
         mapping[fn].get(ln) is not None])
    merged_cfg.cross_call_edges = cross_call_edges

    # Register RETURN edges in the ICFG but keep them inactive for the legacy
    # GA/path sampler. This makes the call/return structure explicit without
    # changing the path_token search space used by the released experiments.
    num_return_edges = merged_cfg.register_return_edges(
        sorted(return_edges),
        active_for_sampling=False
    )
    logger.debug(
        "Interprocedural edges: %d CALL, %d RETURN (RETURN inactive for sampling).",
        len(cross_call_edges), num_return_edges
    )
    gcode_map_for_pkl = {gid: cfgs[fname].source_lines[ln - 1].strip() for fname, m in mapping.items() for ln, gid in
                         m.items() if 1 <= ln <= len(cfgs[fname].source_lines)}

    # ✨✨✨ key point: this call to get_allpath is a potential failure source
    _, all_paths, _, ratio = merged_cfg.get_allpath(max_paths=15, generations=10, population_size=25)

    # treat path generation as successful if at least one path is produced or coverage is greater than zero
    # with the current c_cfg.py implementation, ratio may be greater than zero even when no path is generated, so paths are the primary success criterion
    if not all_paths and ratio == 0.0:
        raise ValueError("Path generation failed: get_allpath returned no paths and zero coverage.")

    path_results = {'paths': all_paths, 'coverage_ratio': ratio}
    return path_results, gcode_map_for_pkl


# ==============================================================================
# --- main processing logic (✨✨✨ key change: return None on failure ✨✨✨) ---
# ==============================================================================
def process_single_line(line_content: str):
    idx_val = "N/A"
    try:
        j = json.loads(line_content)
        idx, target, content = j.get('idx', 'N/A'), j.get('target'), j.get('func')
        idx_val = idx

        clean_code, _ = remove_comments_and_docstrings(content, 'c')

        # call the core processing function; failures inside it, especially in get_allpath, raise an exception
        mpaths, gcode_map = process_content_to_combined_cfg(clean_code, max_call_depth=3)

        cfg_allpath = mpaths.get('paths', [])
        path_tokens_as_codestrings = extract_pathtoken(gcode_map, cfg_allpath)
        coverage_ratio = mpaths.get('coverage_ratio', 0.0)

        # on success, return the complete dictionary
        return {
            'idx': idx, 'target': target, 'vul_type': j.get('vul_type', 'unknown'),
            'vul_content': j.get('vul_content', 'unknown'), 'code': clean_code,
            'path_token': path_tokens_as_codestrings,
            'coverage_ratio': coverage_ratio,
        }
    except Exception as e:
        # on failure, including get_allpath failure, log the error and return None so the sample is discarded
        logger.debug(f"[IDX: {idx_val}] Discarding sample due to error: {e}", exc_info=False)
        return None


# ==============================================================================
# --- multiprocessing processing (unchanged) ---
# ==============================================================================
def process_lines_multiprocess(lines_to_process, output_file, max_workers):
    total_path_dict = {}
    with ProcessPoolExecutor(max_workers=max_workers, initializer=worker_init) as executor:
        futures = {executor.submit(process_single_line, line): line for line in lines_to_process}
        progress_bar = tqdm(as_completed(futures), total=len(lines_to_process),
                            desc=f"Processing {os.path.basename(output_file)}")
        for future in progress_bar:
            try:
                # if process_single_line returns None, result is None here
                result = future.result()
                if result:
                    total_path_dict[result['idx']] = result
            except Exception as exc:
                logger.error(f"A task in the pool generated an unhandled exception: {exc}", exc_info=True)

    with open(output_file, 'wb') as outf:
        pickle.dump(total_path_dict, outf)

    logger.info(f"✅ Successfully processed and saved {len(total_path_dict)} items to {output_file}")

    # return successfully processed dictionaries for later coverage calculation and file synchronization
    return total_path_dict


# ==============================================================================
# --- main entry point (unchanged) ---
# ==============================================================================
def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    dataset_base_dir = os.path.join(base_dir, "../dataset", "cdata", "nobalance")
    output_base_dir = os.path.join(base_dir, "processed_data_final")

    datasets_config = [
        {"input": "d2a_multi_train_cdata.jsonl", "output_pkl": "cdata_nobalance_train.pkl"},
        {"input": "d2a_multi_valid_cdata.jsonl", "output_pkl": "cdata_nobalance_valid.pkl"},
        {"input": "d2a_multi_test_cdata.jsonl", "output_pkl": "cdata_nobalance_test.pkl"},
    ]
    SAMPLE_RATIO = 1.0
    max_workers = 12

    if not os.path.exists(output_base_dir):
        os.makedirs(output_base_dir)
        logger.info(f"Created output directory: {output_base_dir}")
    if SAMPLE_RATIO and 0 < SAMPLE_RATIO < 1.0:
        random.seed(42)
        logger.info(f"Sampling enabled ({SAMPLE_RATIO:.0%}). Random seed set to 42.")

    overall_start_time = time.time()

    for config in datasets_config:
        input_file = os.path.join(dataset_base_dir, config["input"])
        output_pkl_base = config["output_pkl"]
        logger.info(f"\n{'=' * 25} Processing: {config['input']} {'=' * 25}")
        if not os.path.exists(input_file):
            logger.warning(f"Input file not found, skipping: {input_file}")
            continue

        with open(input_file, 'r', encoding='utf-8') as f:
            all_lines = f.readlines()
        lines_to_process, is_sampled = all_lines, False
        if SAMPLE_RATIO and 0 < SAMPLE_RATIO < 1.0:
            num_to_sample = int(len(all_lines) * SAMPLE_RATIO)
            if num_to_sample > 0:
                lines_to_process = random.sample(all_lines, num_to_sample)
                is_sampled = True
                logger.info(f"Sampling {len(lines_to_process)} lines from {len(all_lines)}.")

        output_pkl_filename = output_pkl_base
        if is_sampled:
            name, ext = os.path.splitext(output_pkl_base)
            output_pkl_filename = f"{name}_sample{int(SAMPLE_RATIO * 100)}pct{ext}"
        output_pkl_filepath = os.path.join(output_base_dir, output_pkl_filename)
        logger.info(f"Processing {len(lines_to_process)} items -> PKL: {output_pkl_filepath}")

        # `process_lines_multiprocess` now returns data that were successfully processed and saved to PKL
        processed_results = process_lines_multiprocess(
            lines_to_process=lines_to_process,
            output_file=output_pkl_filepath,
            max_workers=max_workers
        )

        successful_indices = set(processed_results.keys())

        if successful_indices:
            # compute average coverage
            all_coverage_ratios = [item.get('coverage_ratio', 0.0) for item in processed_results.values()]
            if all_coverage_ratios:
                average_coverage = sum(all_coverage_ratios) / len(all_coverage_ratios)
                logger.info(
                    f"📊 Average Path Coverage for this dataset (on {len(all_coverage_ratios)} successful items): {average_coverage:.2%}")

            # synchronize the JSONL file
            synced_lines = []
            for line_str in lines_to_process:
                try:
                    line_json = json.loads(line_str)
                    if line_json.get('idx') in successful_indices:
                        synced_lines.append(line_str)
                except (json.JSONDecodeError, AttributeError):
                    continue

            jsonl_basename, _ = os.path.splitext(config["input"])
            synced_jsonl_filename = f"{jsonl_basename}_synced.jsonl"
            if is_sampled:
                synced_jsonl_filename = f"{jsonl_basename}_sample{int(SAMPLE_RATIO * 100)}pct_synced.jsonl"
            synced_jsonl_filepath = os.path.join(output_base_dir, synced_jsonl_filename)
            with open(synced_jsonl_filepath, 'w', encoding='utf-8') as f_synced:
                f_synced.writelines(synced_lines)

            logger.info(f"✅ Created synced JSONL with {len(synced_lines)} entries: {synced_jsonl_filepath}")

            # compute the success rate
            success_rate = len(successful_indices) / len(lines_to_process) if lines_to_process else 0.0
            logger.info(f"   (Total items attempted: {len(lines_to_process)}, Success rate: {success_rate:.2%})")
        else:
            logger.warning(
                "No items were successfully processed, so no 'synced' JSONL file or coverage report was generated.")

    overall_elapsed = time.time() - overall_start_time
    logger.info(f"\n🚀 All datasets processed. Total time: {overall_elapsed:.2f}s")
    logger.info(f"Check for all output files in: {output_base_dir}")

    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)


if __name__ == "__main__":
    if sys.platform.startswith('linux'):
        try:
            mp.set_start_method('spawn', force=True)
        except RuntimeError:
            pass
    main()
