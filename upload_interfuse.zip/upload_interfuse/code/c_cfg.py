# c_cfg.py (FINAL VERSION - Speed Optimized)

import networkx as nx
import random
from typing import List, Tuple, Optional
import logging
import sys
import tree_sitter
import os
import re
# Matplotlib and other imports from your original file are kept
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.animation import FuncAnimation
from matplotlib.patches import FancyArrowPatch
import matplotlib.animation as animation
from graphviz import Digraph

# Keeping your original logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('genetic_path_finder.log', mode='w'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# --- definitions of the four heuristic features (unchanged) ---
DEEPFA_PATTERNS = {
    'pointers': re.compile(r'\*|->|&'),
    'arrays': re.compile(r'\[\s*\w*\s*\]'),
    'arithmetic': re.compile(r'\+\+|--|\+=|-=|\*=|/=|%='),
    'sensitive_calls': {
        'strcpy', 'strcat', 'sprintf', 'vsprintf', 'gets', 'scanf',
        'sscanf', 'fscanf', 'vscanf', 'vsscanf', 'vfscanf', 'memcpy',
        'memmove', 'malloc', 'calloc', 'realloc', 'free', 'system',
        'exec', 'popen', 'access'
    }
}
sensitive_calls_regex = re.compile(r'\b(' + '|'.join(DEEPFA_PATTERNS['sensitive_calls']) + r')\b')
NUM_HEURISTIC_FEATURES = 4


def analyze_path_for_features(path_as_code_strings: List[str]) -> List[int]:
    """analysis function (unchanged)"""
    if not path_as_code_strings:
        return [0] * NUM_HEURISTIC_FEATURES
    full_path_code = "\n".join(path_as_code_strings)
    has_pointer = 1 if DEEPFA_PATTERNS['pointers'].search(full_path_code) else 0
    has_array = 1 if DEEPFA_PATTERNS['arrays'].search(full_path_code) else 0
    has_arithmetic = 1 if DEEPFA_PATTERNS['arithmetic'].search(full_path_code) else 0
    has_sensitive_call = 1 if sensitive_calls_regex.search(full_path_code) else 0
    return [has_pointer, has_array, has_arithmetic, has_sensitive_call]


class GeneticPathFinder:
    # ✨✨✨ START OF SPEED OPTIMIZATIONS ✨✨✨
    def __init__(self, graph: nx.DiGraph, start_node: int, end_nodes: list, cross_call_edges: set, source_lines: list):
        self.graph = graph
        self.start_node = start_node
        self.end_nodes = end_nodes if end_nodes else []
        self.cross_call_edges = cross_call_edges
        self.source_lines = source_lines

        self.all_nodes = set(self.graph.nodes())
        self.covered_global = set()
        self.population = []
        self.population_tuples = set()
        self.current_mutation_rate = 0.25
        self.logger = logging.getLogger("GeneticPathFinder")
        self.logger.setLevel(logging.INFO)

        # 1. fitness cache to avoid repeated computation
        self.fitness_cache = {}

    def _calculate_heuristic_risk_score(self, path: list) -> float:
        """internal heuristic scoring function (unchanged)"""
        if not path: return 0.0
        path_as_code_strings = [self.source_lines[node_id - 1] for node_id in path if
                                1 <= node_id <= len(self.source_lines)]
        features = analyze_path_for_features(path_as_code_strings)
        pointer_score = features[0] * 20.0
        array_score = features[1] * 15.0
        arithmetic_score = features[2] * 10.0
        sensitive_call_score = features[3] * 30.0
        return pointer_score + array_score + arithmetic_score + sensitive_call_score

    def calculate_fitness(self, individual: list, risk_weight=0.6) -> float:
        """hybrid fitness function with caching"""
        # use a tuple as the cache key
        path_tuple = tuple(individual)
        if path_tuple in self.fitness_cache:
            return self.fitness_cache[path_tuple]

        if not individual: return -1000.0

        # original computation logic
        new_nodes = set(individual) - self.covered_global
        coverage_score = len(new_nodes) * 50.0
        path_edges = set(zip(individual[:-1], individual[1:]))
        cross_call_bonus = 100.0 if self.cross_call_edges and self.cross_call_edges.intersection(path_edges) else 0.0
        redundancy_penalty = sum(1 for node in individual if node in self.covered_global) * 2.0
        length_penalty = len(individual) * 0.5
        structural_fitness = coverage_score + cross_call_bonus - length_penalty - redundancy_penalty
        heuristic_risk_score = self._calculate_heuristic_risk_score(individual)
        final_fitness = (1 - risk_weight) * structural_fitness + risk_weight * heuristic_risk_score

        # store in the cache
        self.fitness_cache[path_tuple] = final_fitness
        return final_fitness

    def evolve(self, generations=10, elite_size=2):
        """[Refactored] More efficient main evolution loop"""
        if not self.population: return

        # clear the fitness cache at the start of each evolution round because covered_global has changed
        self.fitness_cache.clear()

        # compute the fitness of the current population
        pop_with_fitness = sorted(
            [(p, self.calculate_fitness(p)) for p in self.population],
            key=lambda x: x[1], reverse=True
        )

        for gen in range(generations):
            # 1. select elites
            elites = [p for p, f in pop_with_fitness[:elite_size]]

            # 2. generate offspring
            children = []
            while len(children) < len(self.population) - len(elites):
                # use roulette-wheel selection to increase diversity
                parents = self.roulette_wheel_selection(pop_with_fitness, 2)
                if not parents: continue
                p1, p2 = parents[0], parents[1]

                child = self.crossover(p1, p2)
                if not child: continue

                child = self.mutate(child)
                child = self.local_search(child)  # local search

                if child and self.validate_path(child):
                    children.append(child)

            # 3. form the new population and compute the fitness of new individuals
            next_pop = elites + children
            pop_with_fitness = []
            for ind in next_pop:
                # only new individuals need fitness evaluation; elite fitness values are served from the cache
                fitness = self.calculate_fitness(ind)
                pop_with_fitness.append((ind, fitness))

            pop_with_fitness.sort(key=lambda x: x[1], reverse=True)
            self.population = [p for p, f in pop_with_fitness]

    def roulette_wheel_selection(self, pop_with_fitness, num_to_select):
        """roulette-wheel selection to increase population diversity"""
        total_fitness = sum(f for p, f in pop_with_fitness if f > 0)
        if total_fitness <= 0:  # if all fitness values are non-positive, select randomly
            return [p for p, f in random.sample(pop_with_fitness, min(num_to_select, len(pop_with_fitness)))]

        selected = []
        for _ in range(num_to_select):
            pick = random.uniform(0, total_fitness)
            current = 0
            for p, f in pop_with_fitness:
                if f > 0:
                    current += f
                    if current > pick:
                        selected.append(p)
                        break
        return selected if selected else [pop_with_fitness[0][0]] * num_to_select

    # ✨✨✨ END OF SPEED OPTIMIZATIONS ✨✨✨

    # --- the following is the original code and remains unchanged ---
    def initialize_population(self, population_size=50):
        #... (this function remains unchanged)...
        size = population_size
        self.population = []
        self.population_tuples = set()
        self.logger.debug(f"开始初始化多样化种群，目标大小 = {size}")
        cross_call_paths_to_try = list(self.cross_call_edges)[:2]
        for u_call, v_entry in cross_call_paths_to_try:
            if len(self.population) >= size: break
            try:
                path_to_call = nx.shortest_path(self.graph, self.start_node, u_call)
                if self.end_nodes:
                    paths_to_ends = [nx.shortest_path(self.graph, v_entry, end) for end in self.end_nodes if
                                     nx.has_path(self.graph, v_entry, end)]
                    if paths_to_ends:
                        path_from_callee = min(paths_to_ends, key=len)
                        candidate = path_to_call[:-1] + path_from_callee
                        if self.validate_path(candidate) and tuple(candidate) not in self.population_tuples:
                            self.population.append(candidate)
                            self.population_tuples.add(tuple(candidate))
            except nx.NetworkXNoPath:
                continue
        endpoints_to_try = random.sample(self.end_nodes, min(len(self.end_nodes), 2)) if self.end_nodes else []
        for end_node in endpoints_to_try:
            if len(self.population) >= size: break
            try:
                candidate = nx.shortest_path(self.graph, self.start_node, end_node)
                if self.validate_path(candidate) and tuple(candidate) not in self.population_tuples:
                    self.population.append(candidate)
                    self.population_tuples.add(tuple(candidate))
            except nx.NetworkXNoPath:
                continue
        attempts = 0
        max_attempts = size * 5
        while len(self.population) < size and attempts < max_attempts:
            candidate = self.random_dfs_optimized(self.start_node, max_depth=50)
            if candidate and tuple(candidate) not in self.population_tuples:
                self.population.append(candidate)
                self.population_tuples.add(tuple(candidate))
            attempts += 1
        self.logger.debug(f"多样化种群初始化完成，共 {len(self.population)} 条独特路径。")

    def random_dfs_optimized(self, start_node: int, max_depth: int = 50) -> Optional[List[int]]:
        #... (this function remains unchanged)...
        path = [start_node]
        visited_on_path = {start_node}
        for _ in range(max_depth):
            current_node = path[-1]
            if self.end_nodes and current_node in self.end_nodes: break
            successors = list(self.graph.successors(current_node))
            if not successors: break
            unvisited_successors = [n for n in successors if n not in visited_on_path]
            if unvisited_successors:
                next_node = random.choice(unvisited_successors)
            else:
                if random.random() < 0.1 and len(path) > 1:
                    path.pop()
                    if current_node in visited_on_path: visited_on_path.remove(current_node)
                    continue
                else:
                    next_node = random.choice(successors)
            path.append(next_node)
            visited_on_path.add(next_node)
        if self.validate_path(path):
            return path
        return None

    def validate_path(self, path: List[int]) -> bool:
        #... (this function remains unchanged)...
        if not path or not isinstance(path, list): return False
        for i in range(len(path) - 1):
            if not self.graph.has_edge(path[i], path[i + 1]):
                self.logger.warning(f"路径验证失败：边 ({path[i]}, {path[i + 1]}) 不存在。")
                return False
        return True

    def crossover(self, parent1: List[int], parent2: List[int]) -> Optional[List[int]]:
        #... (this function remains unchanged)...
        common_nodes = list(set(parent1) & set(parent2))
        if len(common_nodes) < 2: return random.choice([parent1, parent2])
        crossover_point = random.choice(common_nodes)
        try:
            idx1 = parent1.index(crossover_point)
            idx2 = parent2.index(crossover_point)
            child = parent1[:idx1] + parent2[idx2:]
            return child if self.validate_path(child) else None
        except ValueError:
            return None

    def mutate(self, path: List[int]) -> List[int]:
        #... (this function remains unchanged)...
        if not path or random.random() > self.current_mutation_rate:
            return path
        uncovered = list(self.all_nodes - self.covered_global - set(path))
        if uncovered and random.random() < 0.5:
            try:
                mutation_point_idx = random.randint(0, len(path) - 1)
                start_node = path[mutation_point_idx]
                target_node = random.choice(uncovered)
                bridge = nx.shortest_path(self.graph, start_node, target_node)
                new_path = path[:mutation_point_idx] + bridge
                for _ in range(10):
                    successors = list(self.graph.successors(new_path[-1]))
                    if not successors: break
                    new_path.append(random.choice(successors))
                if self.validate_path(new_path):
                    return new_path
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                pass
        if len(path) > 2:
            idx = random.randint(1, len(path) - 1)
            u, v = path[idx - 1], path[idx]
            successors_of_u = list(self.graph.successors(u))
            if len(successors_of_u) > 1:
                options = [n for n in successors_of_u if n != v]
                if options:
                    inserted_node = random.choice(options)
                    try:
                        bridge_to_v = nx.shortest_path(self.graph, inserted_node, v)
                        mutated_path = path[:idx] + bridge_to_v
                        if self.validate_path(mutated_path):
                            return mutated_path
                    except (nx.NetworkXNoPath, nx.NodeNotFound):
                        pass
        return path

    def local_search(self, path: List[int]) -> List[int]:
        #... (this function remains unchanged)...
        if not path: return []
        optimized_path = path.copy()
        for _ in range(15):
            current_tip = optimized_path[-1]
            try:
                bfs_tree = nx.bfs_tree(self.graph, current_tip, depth_limit=5)
                found_target = False
                for node in bfs_tree:
                    if node not in self.covered_global and node not in optimized_path:
                        bridge = nx.shortest_path(self.graph, current_tip, node)
                        optimized_path.extend(bridge[1:])
                        found_target = True
                        break
                if found_target:
                    continue
                else:
                    break
            except (nx.NodeNotFound):
                break
        return optimized_path


# ==============================================================================
# ---  C_CFG CLASS: Your original code, with get_allpath tuned for speed ---
# ==============================================================================
class C_CFG:
    def __init__(self, source_code=None):
        #... (your __init__ function remains unchanged)...
        self.finlineno = []
        self.firstlineno = 1
        self.G = nx.DiGraph()
        self.coverage_threshold = 0.98
        self.edge_penalty = 1.5
        self.all_paths = []
        self.finder = None
        self.dece_node = []
        self.circle = []
        self.line_number = []
        self.current_scope = []
        self.logger = logging.getLogger(self.__class__.__name__)
        self.source_lines = source_code.splitlines() if source_code else []
        self.max_line = 0
        self.current_loop = None
        self.loop_stack = []
        self.loop_optimization = {
            'min_self_loops': True,
            'allow_types': {'while', 'do'},
            'infinite_loop_marks': {'conditions': ["1", "true", "!0"], 'update_clause': None}
        }
        self.func_entry_map: dict[str, int] = {}
        self.cross_call_edges: set[Tuple[int, int]] = set()

        # Interprocedural RETURN-edge metadata.
        #
        # IMPORTANT:
        # The released path_token/checkpoint results were produced by the legacy
        # sampler whose traversable interprocedural transitions are CALL edges.
        # To make the structural ICFG representation explicit without changing
        # the legacy sampling behavior, RETURN edges can be registered in self.G
        # with active_for_sampling=False. They remain visible for inspection /
        # visualization, but GeneticPathFinder receives a filtered graph view.
        self.return_edges: set[Tuple[int, int]] = set()

    def register_return_edge(self,
                             callee_exit: int,
                             caller_return_site: int,
                             active_for_sampling: bool = False,
                             weight: float = 1.0) -> bool:
        """
        Register one interprocedural RETURN edge.

        By default the edge is structural metadata only
        (active_for_sampling=False), so adding it does not change the legacy
        GA/DFS/shortest-path search space used to generate path_token.

        If the same (u, v) edge already exists for another reason, its existing
        sampling behavior is preserved and RETURN is recorded as an additional
        edge type instead of disabling the pre-existing edge.
        """
        if callee_exit not in self.G or caller_return_site not in self.G:
            self.logger.debug(
                "Skip RETURN edge %s -> %s because one endpoint is missing.",
                callee_exit, caller_return_site
            )
            return False

        edge = (callee_exit, caller_return_site)
        self.return_edges.add(edge)

        if self.G.has_edge(callee_exit, caller_return_site):
            data = self.G[callee_exit][caller_return_site]

            existing_types = list(data.get("edge_types", ()))
            existing_type = data.get("edge_type")
            if existing_type and existing_type not in existing_types:
                existing_types.append(existing_type)
            if "RETURN" not in existing_types:
                existing_types.append("RETURN")

            data["edge_types"] = tuple(existing_types)
            # Never disable an already-existing traversable edge.
            data.setdefault("active_for_sampling", True)
            return True

        self.G.add_edge(
            callee_exit,
            caller_return_site,
            weight=weight,
            label="RETURN",
            edge_type="RETURN",
            edge_types=("RETURN",),
            active_for_sampling=bool(active_for_sampling),
        )
        return True

    def register_return_edges(self,
                              edges,
                              active_for_sampling: bool = False) -> int:
        """Register a collection of RETURN edges and return the added count."""
        added = 0
        for callee_exit, caller_return_site in edges:
            if self.register_return_edge(
                callee_exit,
                caller_return_site,
                active_for_sampling=active_for_sampling
            ):
                added += 1
        return added

    def get_sampling_graph(self):
        """
        Return a read-only graph view containing only traversable edges.

        Edges without the active_for_sampling attribute are treated as active,
        preserving the behavior of the original graph. Shadow RETURN edges are
        stored in self.G but excluded from this view.
        """
        def edge_filter(u, v):
            data = self.G.get_edge_data(u, v, default={})
            return data.get("active_for_sampling", True)

        return nx.subgraph_view(self.G, filter_edge=edge_filter)

    # ✨✨✨ START OF SPEED OPTIMIZATIONS ✨✨✨
    def get_allpath(self,
                    max_paths=10,  # [tuning]slightly reduce the maximum number of paths
                    generations=10,  # [tuning]reduce the number of generations per evolution round
                    population_size=25,  # [tuning]reduce the population size
                    coverage_threshold=0.98
                    ) -> Tuple[int, List[List[int]], int, float]:
        """ [Refactored and optimized] Iterative path search using a single genetic-algorithm instance. """
        all_paths = []
        unique_paths_set = set()
        covered_nodes = {self.firstlineno} if self.G.has_node(self.firstlineno) else set()
        all_nodes_in_graph = {n for n in self.G.nodes() if n != 0}
        total_nodes = len(all_nodes_in_graph)

        if not total_nodes or not self.G.has_node(self.firstlineno):
            self.logger.warning("CFG为空或缺少起始节点，无法生成路径。")
            return 0, [], total_nodes, 0.0

        self.logger.info("Initializing GeneticPathFinder for iterative search...")

        # Use only traversable edges for path generation. This keeps the legacy
        # path search unchanged even when structural RETURN edges are present in
        # self.G with active_for_sampling=False.
        sampling_graph = self.get_sampling_graph()

        finder = GeneticPathFinder(
            sampling_graph, self.firstlineno, self.finlineno,
            self.cross_call_edges, self.source_lines
        )
        finder.initialize_population(population_size=population_size)
        if not finder.population:
            self.logger.error("Failed to initialize a diverse population.")
            return 0, [], total_nodes, 0.0

        no_progress_count = 0
        max_no_progress = 5

        while len(all_paths) < max_paths:
            coverage_ratio = len(covered_nodes) / total_nodes if total_nodes > 0 else 0
            self.logger.info(
                f"--- Path Search Iteration {len(all_paths) + 1}/{max_paths} | Coverage: {coverage_ratio:.2%} ---"
            )

            if coverage_ratio >= coverage_threshold or no_progress_count >= max_no_progress:
                self.logger.info(
                    f"Terminating search. Reason: {'Coverage threshold met' if coverage_ratio >= coverage_threshold else 'Progress stalled'}.")
                break

            finder.covered_global = covered_nodes.copy()

            # ✨ call the optimized evolve function
            finder.evolve(generations=generations, elite_size=max(2, int(population_size * 0.1)))

            if not finder.population:
                self.logger.error("Population collapsed during evolution.")
                break

            # always select the highest-fitness individual in the current population as the result for this round
            best_path = max(finder.population, key=lambda p: finder.calculate_fitness(p))

            newly_covered = set(best_path) - covered_nodes
            if not newly_covered:
                no_progress_count += 1
                self.logger.warning(f"No new nodes covered. Stall count: {no_progress_count}/{max_no_progress}.")
                finder.current_mutation_rate = min(0.5, finder.current_mutation_rate * 1.2)
            else:
                no_progress_count = 0
                finder.current_mutation_rate = 0.25

            if tuple(best_path) not in unique_paths_set:
                self.logger.info(f"Found new unique path. Length: {len(best_path)}, New Nodes: {len(newly_covered)}.")
                all_paths.append(best_path)
                unique_paths_set.add(tuple(best_path))
                covered_nodes.update(newly_covered)
            else:
                self.logger.info("Path is a duplicate, forcing mutation to diversify population.")
                for i in range(len(finder.population)):
                    if random.random() < 0.8:
                        finder.population[i] = finder.mutate(finder.population[i])

        final_coverage = len(covered_nodes) / total_nodes if total_nodes > 0 else 0.0
        self.all_paths = all_paths
        self.logger.info(
            f"Path generation complete. Found {len(all_paths)} paths with final coverage {final_coverage:.2%}")
        return len(all_paths), all_paths, total_nodes - len(covered_nodes), final_coverage

    # ✨✨✨ END OF SPEED OPTIMIZATIONS ✨✨✨

    # --- the following is the original code and remains unchanged ---
    def run(self, root):
        # entry: AST root node
        code_text = root.text.decode('utf8')
        self.max_line = len(code_text.split('\n'))
        self.clean_code = root
        # assume the function-return AST end_point is the last line of the file
        self.finlineno.append(root.end_point[0] + 1)
        self.ast_visit(root)

    def parse_ast_file(self, ast_code):
        self.run(ast_code)
        return ast_code

    def parse_ast(self, source_ast):
        self.run(source_ast)
        return source_ast

    def get_source(self, fn):
        ''' Return the entire contents of the file whose name isgiven. '''
        try:
            f = open(fn, 'r')
            s = f.read()
            f.close()
            return s
        except IOError:
            return ''

    def ast_visit(self, node):
        method = getattr(self, "visit_" + node.type, None)
        if method:
            return method(node)
        else:
            # if no dedicated visit_* method exists, continue traversing child nodes
            return self.visit_piece(node)

    def visit_program(self, node):
        self.finlineno.append(node.children[-1].end_point[0] + 1)
        for index, z in enumerate(node.children):
            start = z.start_point[0] + 1
            end = min(z.end_point[0] + 2, self.max_line)  # ensure the index does not exceed the actual number of lines
            for i in range(start, end):
                self.G.add_node(i)
            if self.firstlineno > z.start_point[0] + 1:
                self.firstlineno = z.start_point[0] + 1

            if z.type == "compound_statement":
                if index == len(node.children) - 1:
                    self.finlineno.append(z.end_point[0] + 1)
                self.ast_visit(z)
            elif z.type == "local_variable_declaration":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_translation_unit(self, node):
        self.finlineno.append(node.children[-1].end_point[0] + 1)
        last_child = node.children[-1]
        termination_line = min(last_child.end_point[0] + 1, self.max_line)
        self.finlineno.append(termination_line)
        self.G.add_node(termination_line)
        for index, z in enumerate(node.children):
            for i in range(z.start_point[0] + 1, z.end_point[0] + 2):
                self.G.add_node(i)
            if self.firstlineno > z.start_point[0] + 1:
                self.firstlineno = z.start_point[0] + 1
            if z.type == "function_definition":
                if index == len(node.children) - 1:
                    self.finlineno.append(z.end_point[0] + 1)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_function_definition(self, node):
        # --- 1. record the entry line number and function name for each function definition ---
        try:
            declarator = next((c for c in node.children if c.type == "function_declarator"), None)
            if declarator:
                ident = next((c2 for c2 in declarator.children if c2.type == "identifier"), None)
                if ident:
                    # rough function-name extraction: concatenate the corresponding source-line range; identifiers may span multiple lines, so adjust according to the actual AST if needed
                    func_name = "".join(
                        self.source_lines[ident.start_point[0]: ident.end_point[0] + 1]
                    ).strip()
                else:
                    func_name = f"<anon@L{node.start_point[0] + 1}>"
            else:
                func_name = f"<anon@L{node.start_point[0] + 1}>"
            entry_line = node.start_point[0] + 1
            self.func_entry_map[func_name] = entry_line
            self.logger.debug(f"记录函数定义: {func_name} @ 行 {entry_line}")
        except Exception as e:
            self.logger.warning(f"提取函数名失败: {e}")

        # --- 2. continue building the intra-function CFG using the original logic ---
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_compound_statement(self, node):
        for index, z in enumerate(node.children):
            if z.type == "for_statement":
                self.ast_visit(z)
            elif z.type == "enhanced_for_statement":
                self.ast_visit(z)
            elif z.type == "while_statement":
                self.ast_visit(z)
            elif z.type == "do_statement":
                self.ast_visit(z)
            elif z.type == "try_with_resources_statement":
                self.ast_visit(z)
            elif z.type == "assert_statement":
                self.ast_visit(z)
            elif z.type == "switch_statement":
                self.ast_visit(z)
            elif z.type == "case_statement":
                # case is handled specially inside switch
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.ast_visit(z)
            elif z.type == "switch_block":
                self.ast_visit(z)
            elif z.type == "switch_block_statement_group":
                self.ast_visit(z)
            elif z.type == "labeled_statement":
                self.ast_visit(z)
            elif z.type == "continue_statement":
                self.ast_visit(z)
            elif z.type == "try_statement":
                self.ast_visit(z)
            elif z.type == "throw_statement":
                self.ast_visit(z)
            elif z.type == "if_statement":
                self.ast_visit(z)
            elif z.type == "synchronized_statement":
                self.ast_visit(z)
            elif z.type == "expression_statement":
                self.ast_visit(z)
            elif z.type == "local_variable_declaration":
                self.ast_visit(z)
            elif z.type == "return_statement":
                self.ast_visit(z)
            elif z.type == "compound_statement":
                self.ast_visit(z)
            elif z.type == "parenthesized_expression":
                self.ast_visit(z)
            elif z.type == "ERROR":
                self.ast_visit(z)
            elif z.type == "break_statement":
                self.ast_visit(z)
            elif z.type == "class_declaration":
                self.ast_visit(z)
            elif z.type == "declaration":
                self.ast_visit(z)
            elif z.type == "function_declarator":
                self.ast_visit(z)
            elif z.type == "}":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "{":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == ";":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            else:
                self.visit_piece(z)

        if len(node.children) > 0 and node.children[0].type == "{":
            self.G.add_edge(node.children[0].start_point[0] + 1, node.children[0].start_point[0] + 2, weight=1)
        if len(node.children) > 0 and node.children[-1].type == "}":
            self.G.add_edge(node.children[-1].start_point[0], node.children[-1].start_point[0] + 1, weight=1)

    def visit_piece(self, node):
        # --------------- added: detect function calls ---------------
        if node.type == "call_expression":
            try:
                caller_line = node.start_point[0] + 1
                ident = next((c for c in node.children if c.type == "identifier"), None)
                if ident:
                    call_name = "".join(self.source_lines[ident.start_point[0]:ident.end_point[0] + 1]).strip()
                else:
                    call_name = None

                if call_name and call_name in self.func_entry_map:
                    callee_entry = self.func_entry_map[call_name]
                    self.cross_call_edges.add((caller_line, callee_entry))
                    self.logger.debug(f"探测到跨函数调用: {call_name} @ 调用行 {caller_line} → 入口行 {callee_entry}")
                for c in node.children:
                    self.visit_piece(c)
            except Exception as e:
                self.logger.warning(f"探测函数调用失败: {e}")
            return

        # --------------- the remaining logic is unchanged ---------------
        if node.type == "for_statement":
            self.ast_visit(node)
        elif node.type == "enhanced_for_statement":
            self.ast_visit(node)
        elif node.type == "while_statement":
            self.ast_visit(node)
        elif node.type == "do_statement":
            self.ast_visit(node)
        elif node.type == "try_with_resources_statement":
            self.ast_visit(node)
        elif node.type == "assert_statement":
            self.ast_visit(node)
        elif node.type == "switch_statement":
            self.ast_visit(node)
        elif node.type == "switch_block":
            self.ast_visit(node)
        elif node.type == "switch_block_statement_group":
            self.ast_visit(node)
        elif node.type == "labeled_statement":
            self.ast_visit(node)
        elif node.type == "continue_statement":
            self.ast_visit(node)
        elif node.type == "try_statement":
            self.ast_visit(node)
        elif node.type == "throw_statement":
            self.ast_visit(node)
        elif node.type == "if_statement":
            self.ast_visit(node)
        elif node.type == "synchronized_statement":
            self.ast_visit(node)
        elif node.type == "expression_statement":
            self.ast_visit(node)
        elif node.type == "local_variable_declaration":
            self.ast_visit(node)
        elif node.type == "parenthesized_expression":
            self.ast_visit(node)
        elif node.type == "return_statement":
            self.ast_visit(node)
        elif node.type == "ERROR":
            self.ast_visit(node)
        elif node.type == "break_statement":
            self.ast_visit(node)
        elif node.type == "class_declaration":
            self.ast_visit(node)
        elif node.type == "declaration":
            self.ast_visit(node)
        elif node.type == "function_declarator":
            self.ast_visit(node)
        elif node.type == "compound_statement":
            self.ast_visit(node)
        elif node.type == "goto_statement":
            self.ast_visit(node)
        elif node.type == "preproc_if":
            self.ast_visit(node)
        elif node.type == "preproc_params":
            self.ast_visit(node)
        elif node.type == "pointer_declarator":
            self.ast_visit(node)
        elif node.type == "preproc_ifdef":
            self.ast_visit(node)
        elif node.type == "preproc_elif":
            self.ast_visit(node)
        elif node.type == "preproc_function_def":
            self.ast_visit(node)
        elif node.type == "preproc_call":
            self.ast_visit(node)
        elif node.type == "preproc_else":
            self.ast_visit(node)
        elif node.type == "preproc_def":
            self.ast_visit(node)
        elif node.type == "proproc_include":
            self.ast_visit(node)
        elif node.type == "preproc_defined":
            self.ast_visit(node)
        elif node.type == "function_definition":
            self.ast_visit(node)
        elif node.type == "}":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == "{":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == ";":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        elif node.type == "\n":
            self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        else:
            pass

    def visit_function_declarator(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_class_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_pointer_declarator(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)

    def visit_enhanced_for_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.next_sibling is not None:
            self.G.add_edge(node.start_point[0] + 1, node.next_sibling.start_point[0] + 1, weight=1)
        else:
            self.G.add_edge(node.start_point[0] + 1, node.end_point[0] + 1, weight=1)
        self.circle.append((node.start_point[0] + 1, node.end_point[0] + 1))
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            elif z.type == "if_statement":
                for j in z.children:
                    if j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            elif z.type == "try_statement":
                for j in z.children:
                    if j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            elif z.type == "switch_statement":
                for j in z.children:
                    if j.type == "switch_block":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
                    elif j.type == "compound_statement":
                        self.G.add_edge(j.end_point[0] + 1, node.start_point[0] + 1, weight=1)
            else:
                self.visit_piece(z)
                self.G.add_edge(z.end_point[0] + 1, node.start_point[0] + 1, weight=1)
        self.loopflag = node.end_point[0] + 1

    def visit_try_with_resources_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        body_node = {}
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
                body_node['bs'] = z.start_point[0] + 1
                body_node['be'] = z.end_point[0] + 1
            elif z.type == "finally_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['fs'] = z.start_point[0] + 1
                body_node['fe'] = z.end_point[0] + 1
                self.ast_visit(z)
            elif z.type == "catch_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['cs'] = z.start_point[0] + 1
                body_node['ce'] = z.end_point[0] + 1
                self.ast_visit(z)
            else:
                self.visit_piece(z)
        if 'be' in body_node and 'cs' in body_node:
            self.G.add_edge(body_node['be'], body_node['cs'], weight=1)
        if 'ce' in body_node and 'fs' in body_node:
            self.G.add_edge(body_node['ce'], body_node['fs'], weight=1)

    def visit_assert_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] + 1 > node.start_point[0] + 1:
            for i in range(node.start_point[0] + 1, node.end_point[0] + 1):
                self.G.add_edge(i, i + 1, weight=1)
        if node.end_point[0] + 1 not in self.finlineno:
            self.finlineno.append(node.end_point[0] + 1)

    def visit_switch_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.circle.append((node.start_point[0] + 1, node.end_point[0] + 1))
        if node.next_sibling is not None:  # named_child_count
            self.G.add_edge(node.start_point[0] + 1, node.next_sibling.start_point[0] + 1, weight=1)
        else:
            self.G.add_edge(node.start_point[0] + 1, node.end_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        if node.end_point[0] + 1 != self.finlineno[0]:
            self.G.add_edge(node.children[-1].end_point[0] + 1, node.end_point[0] + 2, weight=1)
        for z in node.children:
            if z.type == "switch_block":
                self.dece_node.append(z.start_point[0] + 1)
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                for i in range(len(z.children)):
                    if node.start_point[0] != z.children[i].start_point[0]:
                        self.G.add_edge(node.start_point[0] + 1, z.children[i].start_point[0] + 1, weight=1)
                self.ast_visit(z)
            elif z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_case_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_switch_block(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "switch_block_statement_group":
                self.ast_visit(z)

    def visit_switch_block_statement_group(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.ast_visit(z)

    def visit_labeled_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_goto_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_try_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        body_node = {}
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
                body_node['bs'] = z.start_point[0] + 1
                body_node['be'] = z.end_point[0] + 1
            elif z.type == "finally_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['fs'] = z.start_point[0] + 1
                body_node['fe'] = z.end_point[0] + 1
                self.ast_visit(z)
            elif z.type == "catch_clause":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.dece_node.append(z.start_point[0] + 1)
                body_node['cs'] = z.start_point[0] + 1
                body_node['ce'] = z.end_point[0] + 1
                self.ast_visit(z)
            else:
                self.visit_piece(z)
        if 'bs' in body_node and 'cs' in body_node:
            self.G.add_edge(body_node['be'], body_node['cs'], weight=1)
        if 'cs' in body_node and 'fs' in body_node:
            self.G.add_edge(body_node['ce'], body_node['fs'], weight=1)

    def visit_catch_clause(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_finally_clause(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "compound_statement":
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_throw_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        self.dece_node.append(node.start_point[0] + 1)
        for z in node.children:
            if z.type == "object_creation_expression":
                self.ast_visit(z)
        if node.end_point[0] + 1 not in self.finlineno:
            self.finlineno.append(node.end_point[0] + 1)

    def visit_object_creation_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_argument_list(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_params(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#define":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "preproc_arg":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                if node.start_point[0] != node.end_point[0]:
                    for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                        self.G.add_edge(j, j + 1, weight=1)
            else:
                self.visit_piece(z)

    def visit_preproc_function_def(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_call(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_def(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_defined(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_preproc_include(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_ternary_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_synchronized_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for index, z in enumerate(node.children):
            if z.type == "compound_statement":
                self.ast_visit(z)

    def visit_expression_statement(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_local_variable_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_declaration(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.end_point[0] > node.start_point[0]:
            for j in range(node.start_point[0] + 1, node.end_point[0] + 2):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_ERROR(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0], node.end_point[0] + 1):
                self.G.add_edge(j, j + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_parenthesized_expression(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        if node.start_point[0] != node.end_point[0]:
            for j in range(node.start_point[0], node.end_point[0] + 1):
                self.G.add_edge(j, j + 1, weight=1)

    def visit_generic_type(self, node):
        pass

    def visit_identifier(self, node):
        pass

    def visit_if(self, node):
        pass

    def visit_for(self, node):
        pass

    def visit_binary_expression(self, node):
        pass

    def print_isolated_nodes(self):
        isolated = list(nx.isolates(self.G))
        if isolated:
            print(f"孤立节点: {sorted(isolated)}")
            for node in isolated:
                if hasattr(self, 'source_lines') and 1 <= node <= len(self.source_lines):
                    context = self.source_lines[node - 1].strip()
                    print(f"行号 {node} 的AST上下文: {context}")
                    self.logger.debug(f"行号 {node} 的AST上下文: {context}")
                else:
                    print(f"行号 {node} 的AST上下文: [无法获取]")
                    self.logger.debug(f"行号 {node} 的AST上下文: [无法获取]")
        else:
            print("无孤立节点")

    def ast_visit_children(self, node):
        """recursively process all child nodes"""
        for child in node.children:
            self.ast_visit(child)

    def get_node_code(self, node):
        """extract the source code corresponding to the specified AST node with line-number validation"""
        start_line = node.start_point[0]
        end_line = node.end_point[0]

        # line-number boundary protection
        if start_line < 0 or end_line >= len(self.source_lines):
            return ""

        # extract a multi-line code fragment
        code_snippet = []
        for line_num in range(start_line, end_line + 1):
            if line_num < len(self.source_lines):
                code_snippet.append(f"Line {line_num + 1}: {self.source_lines[line_num]}")
        return '\n'.join(code_snippet)

    def _is_infinite_for_loop(self, node):
        """detect infinite-loop patterns such as for(;;)"""
        condition = next((c for c in node.children if c.type == "condition"), None)
        if not condition:
            return True
        condition_code = self.get_node_code(condition).strip()
        return condition_code in self.loop_optimization['infinite_loop_marks']['conditions']

    def validate_graph(self):
        # 1. remove invalid node 0 (a common initialization artifact)
        if 0 in self.G.nodes:
            self.G.remove_node(0)
            self.logger.warning("删除非法节点0")

        # 2. repair isolated nodes (nodes with neither incoming nor outgoing edges)
        isolated = list(nx.isolates(self.G))
        if isolated:
            self.logger.warning(f"发现孤立节点: {isolated}")
            for line in sorted(isolated):
                prev_line = line - 1
                next_line = line + 1

                if prev_line in self.G.nodes:
                    self.G.add_edge(prev_line, line, weight=1)
                    self.logger.debug(f"修复连接: {prev_line} -> {line}")
                if next_line in self.G.nodes:
                    self.G.add_edge(line, next_line, weight=1)
                    self.logger.debug(f"修复连接: {line} -> {next_line}")

        # 3. verify that terminal nodes exist (ensure every terminal node is present in the graph)
        for end in self.finlineno:
            if not self.G.has_node(end):
                self.logger.error(f"终止节点 {end} 不存在")
                raise ValueError(f"终止节点 {end} 缺失")

        # 4. remove self-loops from non-loop nodes
        to_remove = []
        loop_heads = [loop[0] for loop in self.circle] if hasattr(self, "circle") else []
        for u, v in self.G.edges():
            if u == v and u not in loop_heads:
                to_remove.append((u, v))
        for edge in to_remove:
            self.G.remove_edge(*edge)
            self.logger.info(f"移除非循环节点自环边: {edge}")

        # --- helper functions ---

        def is_control_flow_keyword(line):
            """determine whether the line starts with a control-flow keyword such as else or case"""
            if line > len(self.source_lines):
                return False
            text = self.source_lines[line - 1].strip()
            return bool(re.match(r'^(else|case|default:|catch|finally|elif|#else)\b', text))

        def is_same_or_ancestor_ast_block(u, v):
            def get_ancestors(node):
                ancestors = set()
                while node:
                    ancestors.add(node)
                    node = node.parent
                return ancestors

            u_node = self._find_ast_node(u)
            v_node = self._find_ast_node(v)

            if u_node and v_node:
                u_ancestors = get_ancestors(u_node)
                v_ancestors = get_ancestors(v_node)
                return bool(u_ancestors & v_ancestors)
            return False

        # --- main validation and edge-completion logic ---

        all_nodes = sorted(self.G.nodes)
        for i in range(len(all_nodes) - 1):
            curr = all_nodes[i]
            next_ = all_nodes[i + 1]

            # only handle consecutive line numbers when the edge does not already exist
            if next_ != curr + 1 or self.G.has_edge(curr, next_):
                continue

            should_skip = False

            # condition 1: whether the current node has a non-sequential outgoing edge (an edge not pointing to curr+1)
            if self._has_non_sequential_exit(curr):
                should_skip = True

            # condition 2: if the next line starts with a control-flow keyword (e.g., else or case), skip adding the edge
            if is_control_flow_keyword(next_):
                should_skip = True

            if not should_skip:
                self.G.add_edge(curr, next_, weight=1)
                self.logger.debug(f"Added safe sequential edge {curr} -> {next_}")

        # ------------- dependent helper functions -------------

    def _find_ast_node(self, line):
        def traverse(node):
            start = node.start_point[0] + 1
            end = node.end_point[0] + 1
            if line < start or line > end:
                return None
            for child in node.children:
                result = traverse(child)
                if result is not None:
                    return result
            return node

        return traverse(self.ast)

    def _has_non_sequential_exit(self, line):
        """determine whether the current line has a non-sequential outgoing edge (not line+1)"""
        for _, v in self.G.out_edges(line):
            if v != line + 1:
                return True
        return False

    def is_non_statement_line(self, line_text):
        stripped = line_text.strip()
        # simple matching for else and else if
        if re.match(r'^else(\s+if)?$', stripped):
            return True
        return stripped in ["{", "}", ";", ""]

    def visit_preproc_if(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)  # connect the preprocessing line
        for z in node.children:
            if z.type == "#if":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "preproc_else":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.visit_piece(z)
            elif z.type == "#endif":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
                # connect to the line after #endif
                next_line = z.start_point[0] + 2  # assume the line after #endif
                if next_line <= self.max_line:
                    self.G.add_edge(z.start_point[0] + 1, next_line, weight=1)
            elif z.type == "preproc_elif":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.ast_visit(z)
            else:
                self.visit_piece(z)

    def visit_preproc_else(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_preproc_elif(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            self.visit_piece(z)

    def visit_preproc_ifdef(self, node):
        self.G.add_edge(node.start_point[0], node.start_point[0] + 1, weight=1)
        for z in node.children:
            if z.type == "#ifdef":
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)
            elif z.type == "#endif":
                self.G.add_edge(node.start_point[0] + 1, z.start_point[0] + 1, weight=1)
                self.G.add_edge(z.start_point[0], z.start_point[0] + 1, weight=1)

                # connect to the line after #endif
                next_line = z.start_point[0] + 2  # assume the line after #endif
                if next_line <= self.max_line:
                    self.G.add_edge(z.start_point[0] + 1, next_line, weight=1)
            else:
                self.visit_piece(z)

    def get_if_else_exit_line(self, node):
        parent = getattr(node, 'parent', None)
        if not parent:
            return node.end_point[0] + 2

        siblings = parent.children
        idx = siblings.index(node)
        if idx + 1 < len(siblings):
            next_stmt = siblings[idx + 1]
            return next_stmt.start_point[0] + 1
        return parent.end_point[0] + 2

    def visit_if_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # add the current if node
        self.G.add_node(cond_line, shape='diamond', label=f"IF@L{cond_line}")

        # find the then branch
        then_node = None
        for c in node.children:
            if c.type == "compound_statement":
                then_node = c
                break

        # remove the default sequential edge from the if-condition line to the next line to avoid duplication
        if self.G.has_edge(cond_line, cond_line + 1):
            self.G.remove_edge(cond_line, cond_line + 1)

        # connect the then branch
        if then_node:
            then_start = then_node.start_point[0] + 1
            self.G.add_edge(cond_line, then_start, weight=1, label='then')
            self.ast_visit(then_node)
            then_end = self.get_last_child_line(then_node) + 1
            self.G.add_edge(then_end, end_line, weight=1, label='then_end')
        else:
            # handle a non-compound then branch (single statement)
            then_stmts = [c for c in node.children if
                          c.type not in ("else_clause", "condition", "compound_statement")]
            if then_stmts:
                first_then = then_stmts[0]
                then_start = first_then.start_point[0] + 1
                self.G.add_edge(cond_line, then_start, weight=1, label='then')
                for idx, stmt in enumerate(then_stmts):
                    self.ast_visit(stmt)
                    if idx + 1 < len(then_stmts):
                        next_stmt = then_stmts[idx + 1]
                        self.G.add_edge(stmt.end_point[0] + 1, next_stmt.start_point[0] + 1, weight=1)
                then_end = then_stmts[-1].end_point[0] + 1
                self.G.add_edge(then_end, end_line + 1, weight=1, label='then_end')
            else:
                self.G.add_edge(cond_line, end_line + 1, weight=1, style='dashed')

        # connect the else branch
        else_node = next((c for c in node.children if c.type == "else_clause"), None)
        if else_node:
            else_line = else_node.start_point[0] + 1
            self.G.add_node(else_line, shape='box', label=f"ELSE@L{else_line}")
            self.G.add_edge(cond_line, else_line, weight=1, label='else')

            compound_node = next((c for c in else_node.children if c.type == "compound_statement"), None)
            if compound_node:
                else_start = compound_node.start_point[0] + 1
                self.G.add_edge(else_line, else_start, weight=1)
                self.ast_visit(compound_node)
                else_end = self.get_last_child_line(compound_node) + 1
                self.G.add_edge(else_end, end_line, weight=1)
            else:
                last_stmt_end = else_line
                for child in else_node.children:
                    if child.type != "else":
                        self.ast_visit(child)
                        child_end = child.end_point[0] + 1
                        self.G.add_edge(last_stmt_end, child.start_point[0] + 1, weight=1)
                        last_stmt_end = child_end
                self.G.add_edge(last_stmt_end, end_line, weight=1)
        else:
            self.G.add_edge(cond_line, end_line, weight=1, style='dashed')

    def visit_while_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        self.G.add_edge(cond_line, cond_line + 1, weight=1, label='while_cond')
        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        # visit the loop body
        body_node = None
        for c in node.children:
            if c.type == "compound_statement":
                body_node = c
                break
        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='while_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='while_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='while_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='while_exit')

        self.loop_stack.pop()

    def visit_for_statement(self, node):
        cond_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        self.G.add_edge(cond_line, cond_line + 1, weight=1, label='for_cond')
        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        # visit the loop body
        body_node = None
        for c in node.children:
            if c.type == "compound_statement":
                body_node = c
                break
        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='for_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='for_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='for_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='for_exit')

        self.loop_stack.pop()

    def visit_do_statement(self, node):
        cond_line = node.children[-1].start_point[0] + 1  # condition line
        end_line = node.end_point[0] + 1

        self.loop_stack.append({'head': cond_line, 'exit': end_line})
        self.circle.append((cond_line, end_line))
        self.dece_node.append(cond_line)

        # the loop body is usually the compound statement other than the condition
        body_node = None
        for c in node.children:
            if c.type == "compound_statement":
                body_node = c
                break

        if body_node:
            body_start = body_node.start_point[0] + 1
            self.G.add_edge(cond_line, body_start, weight=1, label='do_body')
            self.ast_visit(body_node)
            body_end = self.get_last_child_line(body_node) + 1
            self.G.add_edge(body_end, cond_line, weight=1, label='do_back')
        else:
            self.G.add_edge(cond_line, end_line, weight=1, label='do_empty')

        self.G.add_edge(cond_line, end_line, weight=1, label='do_exit')

        self.loop_stack.pop()

    def visit_break_statement(self, node):
        start = node.start_point[0] + 1
        self.G.add_edge(start - 1, start, weight=1, label='break_entry')  # ensure the previous line connects to the break line
        if self.loop_stack:
            exit_line = self.loop_stack[-1]['exit']
            self.G.add_edge(start, exit_line, weight=1, label='break')
        else:
            # without loop context, jump to the function exit or the next line
            next_line = start + 1
            if next_line <= self.max_line:
                self.G.add_edge(start, next_line, weight=1, label='break_weak')
            else:
                for fin in self.finlineno:
                    self.G.add_edge(start, fin, weight=1, label='break_exit')

    def visit_continue_statement(self, node):
        start = node.start_point[0] + 1
        self.G.add_edge(start - 1, start, weight=1, label='continue_entry')
        if self.loop_stack:
            head_line = self.loop_stack[-1]['head']
            self.G.add_edge(start, head_line, weight=1, label='continue')
        else:
            # without loop context, jump to the next line or the end of the function
            next_line = start + 1
            if next_line <= self.max_line:
                self.G.add_edge(start, next_line, weight=1, label='continue_weak')
            else:
                for fin in self.finlineno:
                    self.G.add_edge(start, fin, weight=1, label='continue_exit')

    def visit_return_statement(self, node):
        start = node.start_point[0] + 1
        end = node.end_point[0] + 1
        # connect all lines spanned by the return statement sequentially
        for i in range(start, end):
            self.G.add_edge(i, i + 1, weight=1, label='return_seq')
        # return jumps to the function terminal node
        for fin in self.finlineno:
            self.G.add_edge(end, fin, weight=1, label='return_exit')

        # get the last line among child nodes recursively

    def get_last_child_line(self, node):
        # filter out meaningless nodes
        valid_children = [c for c in node.children if c.type not in ['{', '}', ';', 'comment', 'whitespace']]
        if not valid_children:
            return node.end_point[0]
        last_child = valid_children[-1]
        return self.get_last_child_line(last_child)