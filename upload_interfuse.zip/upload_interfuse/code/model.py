# model.py (V5.0 Final - Hierarchical Context Fusion)

import torch
import torch.nn as nn
import logging
from transformers.modeling_utils import PreTrainedModel
from transformers import RobertaConfig

logger = logging.getLogger(__name__)


class Model(PreTrainedModel):
    config_class = RobertaConfig
    base_model_prefix = "encoder"

    def __init__(self, encoder, config, tokenizer, args):
        super().__init__(config)
        self.encoder = encoder
        self.config = config
        self.args = args
        self.hidden_size = config.hidden_size

        # ✨ V5.0 核心升级: 为三种语义特征创建可学习的嵌入向量
        self.danger_embedding = nn.Parameter(torch.randn(self.hidden_size))
        self.pointer_embedding = nn.Parameter(torch.randn(self.hidden_size))
        self.defense_embedding = nn.Parameter(torch.randn(self.hidden_size))

        # 路径间的注意力机制 (用于处理路径流内部关系)
        self.path_attention = nn.MultiheadAttention(
            embed_dim=self.hidden_size,
            num_heads=config.num_attention_heads,
            dropout=config.attention_probs_dropout_prob,
            batch_first=True
        )
        self.path_attention_norm = nn.LayerNorm(self.hidden_size)

        # ✨ V5.0 核心升级: 全局上下文与路径摘要的融合层
        # 这里使用拼接(concatenation)和线性层，是一种高效且稳定的融合方式
        self.fusion_layer = nn.Sequential(
            nn.Linear(self.hidden_size * 2, self.hidden_size),
            nn.GELU(),
            nn.Dropout(config.hidden_dropout_prob)
        )

        # 最终的分类器
        self.ffn = nn.Sequential(
            nn.Linear(self.hidden_size, self.hidden_size * 4),
            nn.GELU(),
            nn.Linear(self.hidden_size * 4, self.hidden_size),
        )
        self.ffn_norm = nn.LayerNorm(self.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.classifier = nn.Linear(self.hidden_size, 2)

        # 初始化权重
        self.init_weights()

    def _init_weights(self, module):
        """ 重写 Hugging Face 的默认初始化方法 """
        super()._init_weights(module)
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=self.config.initializer_range)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)

        # 初始化自定义的嵌入
        if hasattr(self, 'danger_embedding'):
            self.danger_embedding.data.normal_(mean=0.0, std=self.config.initializer_range)
        if hasattr(self, 'pointer_embedding'):
            self.pointer_embedding.data.normal_(mean=0.0, std=self.config.initializer_range)
        if hasattr(self, 'defense_embedding'):
            self.defense_embedding.data.normal_(mean=0.0, std=self.config.initializer_range)

    # ✨ V5.0 核心升级: forward函数签名与run.py完全匹配
    def forward(self, path_ids, path_attention_mask, path_mask,
                danger_mask, pointer_mask, defense_mask,
                global_ids, global_attention_mask,
                vuln_labels=None, **kwargs):

        B, T_path, L_path = path_ids.shape

        # --- 1. 处理路径流 (Path Stream) ---
        # 1.1 获取基础词嵌入
        flat_path_ids = path_ids.view(B * T_path, L_path)
        word_embeddings = self.encoder.embeddings.word_embeddings(flat_path_ids)

        # 1.2 注入三种语义特征的嵌入
        flat_danger_mask = danger_mask.view(B * T_path, L_path).unsqueeze(-1)
        flat_pointer_mask = pointer_mask.view(B * T_path, L_path).unsqueeze(-1)
        flat_defense_mask = defense_mask.view(B * T_path, L_path).unsqueeze(-1)
        word_embeddings += flat_danger_mask * self.danger_embedding
        word_embeddings += flat_pointer_mask * self.pointer_embedding
        word_embeddings += flat_defense_mask * self.defense_embedding

        # 1.3 通过 Transformer Encoder
        flat_path_attn_mask = path_attention_mask.view(B * T_path, L_path)
        path_encoder_outputs = self.encoder(
            inputs_embeds=word_embeddings,
            attention_mask=flat_path_attn_mask
        )
        path_embeddings = path_encoder_outputs.last_hidden_state[:, 0, :].view(B, T_path, -1)

        # 1.4 路径间的交互与池化
        key_padding_mask = (path_mask == 0)
        path_attn_output, _ = self.path_attention(
            path_embeddings, path_embeddings, path_embeddings,
            key_padding_mask=key_padding_mask
        )
        path_rep_norm = self.path_attention_norm(path_embeddings + self.dropout(path_attn_output))

        masked_path_rep = path_rep_norm * path_mask.unsqueeze(-1)
        summed_path_rep = masked_path_rep.sum(dim=1)
        num_actual_paths = path_mask.sum(dim=1, keepdim=True).clamp(min=1e-9)
        path_representation = summed_path_rep / num_actual_paths  # (B, H)

        # --- 2. 处理全局流 (Global Stream) ---
        global_encoder_outputs = self.encoder(
            input_ids=global_ids,
            attention_mask=global_attention_mask
        )
        global_representation = global_encoder_outputs.last_hidden_state[:, 0, :]  # (B, H)

        # --- 3. 融合双流信息 (Fusion) ---
        combined_representation = torch.cat((path_representation, global_representation), dim=-1)  # (B, 2*H)
        fused_representation = self.fusion_layer(combined_representation)  # (B, H)

        # --- 4. 最终分类 ---
        ffn_input = fused_representation
        ffn_output = self.ffn(ffn_input)
        final_representation = self.ffn_norm(ffn_input + self.dropout(ffn_output))
        logits = self.classifier(final_representation)

        return logits
