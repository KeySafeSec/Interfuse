# InterFuse: Scalable Detection of Memory Safety Violations via Differential Reasoning

## Task Definition

Given a C/C++ function as input, the task is to perform binary classification (0/1), where 1 represents a code fragment containing memory safety vulnerabilities (e.g., UAF, Double-Free, Buffer Overflow) and 0 represents non-vulnerable code. Models are evaluated primarily by **F1-score**, along with Accuracy and MCC.

## Directory Structure

- **src**: Core source code of InterFuse, including the hierarchical context fusion model and GA-based path sampling scripts.

- **dataset**: Placeholder for the D2A 、Julietand MVD datasets.

- **output**: Results of all experiments, including model checkpoints, prediction files, and the `snapvuln_comparison_summary.txt`.

- **parserTool**: The static analysis tool based on Tree-sitter for ICFG construction and feature extraction.

  


## Prepare Requirements

- Python: 3.9
- Pytorch: 1.12.1+cu113
- transformers: 4.21.0
- networkx: 2.8.5
- scikit-learn: 1.1.1
- tree-sitter: 0.20.0


### Tree-sitter (Building Parser)

If the pre-built library in `parserTool/my-languages.so` is incompatible with your OS, please rebuild it using the following commands:

```shell
cd parserTool
bash build.sh
cd ..
```


## Dataset

Our study utilizes the **D2A (Differential Analysis to Attention)** dataset and the **MVD (Multi-Vulnerability Dataset)**. We provide processed versions where functions are annotated with execution path information and danger-op embeddings.

The processed datasets can be downloaded from [Google Drive](--

# InterFuse: Scalable Detection of Memory Safety Violations via Differential Reasoning

## Task Definition

Given a C/C++ function as input, the task is to perform binary classification (0/1), where 1 represents a code fragment containing memory safety vulnerabilities (e.g., UAF, Double-Free, Buffer Overflow) and 0 represents non-vulnerable code. Models are evaluated primarily by **F1-score**, along with Accuracy and MCC.

## Directory Structure

- **src**: Core source code of InterFuse, including the hierarchical context fusion model and GA-based path sampling scripts.
- **dataset**: Placeholder for the D2A and MVD datasets.
- **output**: Results of all experiments, including model checkpoints, prediction files, and the `snapvuln_comparison_summary.txt`.
- **parserTool**: The static analysis tool based on Tree-sitter for ICFG construction and feature extraction.
- **paper**: The PDF version of the manuscript: *"InterFuse: Scalable Detection of Memory Safety Violations via Differential Reasoning and Hierarchical Context Fusion"*.


## Prepare Requirements

- Python: 3.9
- Pytorch: 1.12.1+cu113
- transformers: 4.21.0
- networkx: 2.8.5
- scikit-learn: 1.1.1
- tree-sitter: 0.20.0


### Tree-sitter (Building Parser)

If the pre-built library in `parserTool/my-languages.so` is incompatible with your OS, please rebuild it using the following commands:

```shell
cd parserTool
bash build.sh
cd ..
```


## Dataset

Our study utilizes the **D2A (Differential Analysis to Attention)** dataset and the **MVD (Multi-Vulnerability Dataset)**. We provide processed versions where functions are annotated with execution path information and danger-op embeddings.

The processed datasets can be downloaded from [Google Drive](https://www.google.com/search?q=https://drive.google.com/drive/folders/YOUR_LINK_HERE) and should be placed in the `dataset` folder.

### Data Format

\`train.`train.jsonl`, `valid.jsonl`, and `test.jsonl` are stored in JSONLines format. Each line contains:

- **func:** The source code of the function.
- **target:** Label (0 for benign, 1 for vulnerable).
- **idx:** Unique index of the sample.
- **paths:** Sampled execution paths (generated via GA).


### Data Statistics

| Dataset | \#Examples | \#Vul | \#Non-Vul |
| :-- | :--: | :--: | :--: |
| D2A | 2,670 | 1,148 | 1,522 |
| MVD | 673 | 312 | 361 |

## Train

We use NVIDIA RTX 4090 GPUs for fine-tuning. The following command starts the training using the \*\*Uni**UniXcoder** backbone with Hierarchical Fusion.

```shell
python src/run.py \
    --output_dir=./output --model_type=unixcoder \
    --tokenizer_name=microsoft/unixcoder-base \
    --model_name_or_path=microsoft/unixcoder-base \
    --do_train --train_data_file=./dataset/train.jsonl \
    --eval_data_file=./dataset/valid.jsonl \
    --epoch 10 --block_size 512 --train_batch_size 16 --learning_rate 2e-5 \
    --evaluate_during_training --seed 123456
```


## Inference

To evaluate the model on the test set:

```shell
python src/run.py \
    --output_dir=./output --model_type=unixcoder \
    --do_eval --do_test \
    --test_data_file=./dataset/test.jsonl \
    --model_name_or_path=./output/checkpoint-best/pytorch_model.bin \
    --eval_batch_size 32
```


## Evaluation

To calculate detailed metrics (Accuracy, Precision, Recall, F1):

```shell
python ./src/run.py -a ./dataset/test.jsonl -p ./output/predictions.txt
```


## Result

Experimental results on the **D2A Test Set** (compared with the slicing-based baseline):


| Methods | Precision | Recall | F1-Score | Construction Time |
| :-- | :--: | :--: | :--: | :--: |
| SnapVuln | 78.4 | 83.2 | 80.7 | 18.7s |
| **InterFuse** | **83.1** | **86.4** | **84.7** | **1.6s** |


-----

### Additional Note for the `dataset/README.md`

Inside the `dataset` folder, you should also place a small file to guide users to the external link:

\*\*File: \`dataset/**File: `dataset/README.md`**

```markdown
# Dataset Download Link
Due to the large size of the ICFG graphs and processed path embeddings, please download the datasets from the following Google Drive link:
```

url?sa=E\&source=gmail\&q=https://drive.google.com/drive/folders/YOUR_LINK_HERE) and should be placed in the `dataset` folder.

### Data Format

`train.jsonl`, `valid.jsonl`, and `test.jsonl` are stored in JSONLines format. Each line contains:

- **func:** The source code of the function.
- **target:** Label (0 for benign, 1 for vulnerable).
- **idx:** Unique index of the sample.
- **paths:** Sampled execution paths (generated via GA).


### Data Statistics

| Dataset | \#Examples | \#Vul | \#Non-Vul |
| :-- | :--: | :--: | :--: |
| D2A | 2,670 | 1,148 | 1,522 |
| MVD | 673 | 312 | 361 |

## Train

We use NVIDIA RTX 4090 GPUs for fine-tuning. The following command starts the training using the **UniXcoder** backbone with Hierarchical Fusion.

```shell
python src/run.py \
    --output_dir=./output --model_type=unixcoder \
    --tokenizer_name=microsoft/unixcoder-base \
    --model_name_or_path=microsoft/unixcoder-base \
    --do_train --train_data_file=./dataset/train.jsonl \
    --eval_data_file=./dataset/valid.jsonl \
    --epoch 10 --block_size 512 --train_batch_size 16 --learning_rate 2e-5 \
    --evaluate_during_training --seed 123456
```


## Inference

To evaluate the model on the test set:

```shell
python src/run.py \
     --output_dir output/run_unixcoder_v5.9_major_revision_mem_op --data_dir /media/---pkl_dir /media//cdata/--model_name_or_path /models/unixcoder-base-nine --model_type unixcoder --do_train --do_eval --do_test --use_cache --fp16 --balance_test_set --block_size 860 --max_paths 15 --train_batch_size 1 --eval_batch_size 1 --gradient_accumulation_steps 12 --learning_rate 1e-5 --num_train_epochs 25 --warmup_ratio 0.06 --path_dropout_rate 0.2 --early_stopping_patience 6 --metric_for_best_model f1 --seed 42 --num_dataloader_workers 4 
```


## Evaluation

To calculate detailed metrics (Accuracy, Precision, Recall, F1):

```shell
python ./src/run.py -a ./dataset/test.jsonl -p ./output/predictions.txt
```


## Result

Experimental results on the **D2A Test Set** (compared with the slicing-based baseline):


| Methods | Precision | Recall | F1-Score | Construction Time |
| :-- | :--: | :--: | :--: | :--: |
| SnapVuln | 78.4 | 83.2 | 80.7 | 18.7s |
| **InterFuse** | **83.1** | **86.4** | **84.7** | **1.6s** |


-----

### Additional Note for the `dataset/README.md`

Inside the `dataset` folder, you should also place a small file to guide users to the external link:

**File: `dataset/README.md`**

```markdown
# Dataset Download Link
Due to the large size of the ICFG graphs and processed path embeddings, please download the datasets from the following Google Drive link:
[https://drive.google.com/drive/folders/interfuse/dataset
Once downloaded, extract the files so that `train.jsonl` and `test.jsonl` are located directly in this directory.
```


-----



