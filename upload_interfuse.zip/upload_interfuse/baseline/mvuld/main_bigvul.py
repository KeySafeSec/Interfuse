from xmlrpc.client import FastMarshaller
import torch as th
import os
import sys
import dgl
from torchmetrics import F1Score
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"
import time
import json
import random
import argparse
import datetime
import numpy as np
import torch.nn.functional as F
from tqdm import tqdm
import gc
import logging
import torch
import torch.backends.cudnn as cudnn
import torch.distributed as dist

from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy
from timm.utils import accuracy, AverageMeter

from models.new_model import Multi_DefectModel_noFunc,Multi_DefectModel_noGlobalImage

from models.GraphModel import Multi_DefectModel_100,Multi_DefectModel_110,Multi_DefectModel_011,\
    Multi_DefectModel_001,Multi_DefectModel_NOGAT3,Multi_DefectModel_NOGAT,Multi_DefectModel_NOGAT4,Multi_DefectModel_noGraph,\
    Multi_DefectModel_GATPOS,Multi_DefectModel,Multi_DefectModel_NOGAT2,Multi_DefectModel_new_GCN

from models.MotivationModel import Multi_DefectModel_Image,Multi_DefectModel_FuncText,Multi_DefectModel_Graph,\
    Multi_DefectModel_Graph1,Multi_DefectModel_Graph2

import ml
from sklearn import metrics
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)

from config import get_config
from models import build_model
from data.bigvul_dataset import bigvul_dataset,bigvul_loader_graph
from lr_scheduler import build_scheduler
from optimizer import build_optimizer
from logger import create_logger
# from utils import load_checkpoint, load_pretrained, save_checkpoint, NativeScalerWithGradNormCount, auto_resume_helper, \
#     reduce_tensor
from utils_multi import load_checkpoint, load_pretrained, save_checkpoint, NativeScalerWithGradNormCount, auto_resume_helper, \
    reduce_tensor,save_bestf1_checkpoint,resume_bestf1_helper

from IPython.core.ultratb import ColorTB
sys.excepthook = ColorTB()

import warnings
warnings.filterwarnings("ignore")


def parse_option():
    parser = argparse.ArgumentParser('Swin Transformer training and evaluation script', add_help=False)
    parser.add_argument('--seed', type=int, default=12345,
                        help="random seed for initialization")
    parser.add_argument('--cfg', type=str, default="configs/mySwin/swinv2_base_patch4_window24to28_384to448_1ktoMYDATA_ft.yaml",metavar="FILE", help='path to config file', )
    parser.add_argument(
        "--opts",
        help="Modify config options by adding 'KEY VALUE' pairs. ",
        default=None,
        nargs='+',
    )
    # early stop
    parser.add_argument("--patience", default=50, type=int) 
    parser.add_argument('--test', type=int, default=0, help='Train mode=0;Test mode=1')
    # easy config modification 
    parser.add_argument('--batch-size', type=int,default=4, help="batch size for single GPU")
    parser.add_argument('--data-path', type=str, help='path to dataset')
    parser.add_argument('--test_data_path', type=str, help='path to test dataset')
    parser.add_argument('--zip', action='store_true', help='use zipped dataset instead of folder dataset')
    parser.add_argument('--cache-mode', type=str, default='part', choices=['no', 'full', 'part'],
                        help='no: no cache, '
                             'full: cache all data, '
                             'part: sharding the dataset into nonoverlapping pieces and only cache one piece')
    parser.add_argument('--pretrained',default="configs/mySwin/swinv2_base_patch4_window12to24_192to384_22kto1k_ft.pth",
                        help='pretrained weight from checkpoint, could be imagenet22k pretrained weight')
    parser.add_argument('--resume',default=True ,help='resume from swin checkpoint')
    parser.add_argument('--myresume', help='resume from multimodel checkpoint')
    parser.add_argument('--accumulation-steps', type=int, help="gradient accumulation steps")
    # Gradient Accumulation
    parser.add_argument('--use-checkpoint', action='store_true',
                        help="whether to use gradient checkpointing to save memory")
    parser.add_argument('--disable_amp', action='store_true', help='Disable pytorch amp')
    parser.add_argument('--amp-opt-level', type=str, choices=['O0', 'O1', 'O2'],
                        help='mixed precision opt level, if O0, no amp is used (deprecated!)')
    parser.add_argument('--output', default='my_output', type=str, metavar='PATH',
                        help='root of output folder, the full path is <output>/<model_name>/<tag> (default: output)')
    parser.add_argument('--tag', help='tag of experiment')
    parser.add_argument('--eval', action='store_true', help='Perform evaluation only')
    parser.add_argument('--throughput', action='store_true', help='Test throughput only')
    parser.add_argument('--ngpu', type=int, default=1, help='0 = CPU, 1 = CUDA, 1 < DataParallel')
    # distributed training
    parser.add_argument("--local_rank", type=int,default=0, help='local rank for DistributedDataParallel')

    args, unparsed = parser.parse_known_args()

    config = get_config(args)

    return args, config


def myMain(config,args):
    # 设置随机种子以确保结果的可重复性（注释掉了，可能需要在实际运行时取消注释）
    # setup_seed()

    # 加载数据集和创建数据加载器
    # bigvul_loader_graph 函数根据配置加载训练、验证和测试数据集，并创建相应的数据加载器
    # mixup_fn 用于数据增强，如 mixup
    train_data, val_data, test_data, data_loader_train, data_loader_val, data_loader_test, mixup_fn = bigvul_loader_graph(
        config)

    # 打印训练、验证和测试数据集的长度
    print(f"train={len(train_data)} val={len(val_data)} test={len(test_data)}")

    # 根据研究问题（RQ）选择不同的模型架构
    # # Multi_DefectModel_new_GCN 是一个新的基于GCN的模型
    model = Multi_DefectModel_new_GCN(config=config)
    #
    # # 以下是其他几种模型架构，用于不同的研究问题或实验目的
    # model = Multi_DefectModel_Image(config=config)
    # model = Multi_DefectModel_FuncText(config=config)
    # model = Multi_DefectModel_Graph(config=config)
    # model = Multi_DefectModel_Graph1(config=config)
    # model = Multi_DefectModel_Graph2(config=config)
    #
    # model = Multi_DefectModel_noGlobalImage(config=config)  # 不使用全局图像特征的模型
    # model = Multi_DefectModel_noFunc(config=config)  # 不使用函数文本特征的模型
    # model = Multi_DefectModel_noGraph(config=config)  # 不使用图特征的模型
    #
    # model = Multi_DefectModel(config=config)  # 使用GAT的模型
    # # model = Multi_DefectModel_NOGAT2(config=config)  # 使用POS+GCN的模型
    # #
    # model = Multi_DefectModel_100(config=config)
    # # model = Multi_DefectModel_110(config=config)
    # # model = Multi_DefectModel_011(config=config)
    # # model = Multi_DefectModel_001(config=config)

    # 将模型移动到GPU
    model.cuda()

    # 创建模型的非DDP版本，用于后续操作
    model_without_ddp = model

    # 根据配置文件创建优化器
    optimizer = build_optimizer(config, model)  # 使用AdamW优化器

    # 将模型包装在DDP中，以便在多GPU环境中进行训练
    model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[config.LOCAL_RANK], broadcast_buffers=False,
                                                      find_unused_parameters=True)

    # 记录训练使用的CUDA设备
    cuda = next(model.parameters()).device
    logger.info(f"train cuda device :{cuda} ")

    # 创建损失缩放器
    # loss_scaler = NativeScalerWithGradNormCount()
    loss_scaler=NativeScalerWithGradNormCount.AmpScaler()

    # 打印学习率调度器的名称
    print(f"--------lr = {config.TRAIN.LR_SCHEDULER.NAME}---------")

    # 根据配置文件和数据加载器的长度创建学习率调度器
    if config.TRAIN.ACCUMULATION_STEPS > 1:
        lr_scheduler = build_scheduler(config, optimizer, len(data_loader_train) // config.TRAIN.ACCUMULATION_STEPS)
    else:
        lr_scheduler = build_scheduler(config, optimizer, len(data_loader_train))

    # 根据配置选择损失函数
    if config.AUG.MIXUP > 0.:
        criterion = SoftTargetCrossEntropy()
    elif config.MODEL.LABEL_SMOOTHING > 0.:
        criterion = LabelSmoothingCrossEntropy(smoothing=config.MODEL.LABEL_SMOOTHING)
    else:
        criterion = torch.nn.CrossEntropyLoss()

    # 初始化最佳准确率和F1分数
    max_accuracy = 0.0
    best_f1 = 0.0

    # 尝试从最佳F1模型恢复训练
    if config.TRAIN.BEST_RESUME:
        if not os.path.exists(config.MULTI_OUTPUT):
            os.makedirs(config.MULTI_OUTPUT)
        resume_file = resume_bestf1_helper(config.MULTI_OUTPUT)
        if resume_file:
            if config.MODEL.MULTI.RESUME:
                logger.warning(f"best-resume changing resume file from {config.MODEL.MULTI.RESUME} to {resume_file}")
            config.defrost()
            config.MODEL.MULTI.RESUME = resume_file
            config.freeze()
            logger.info(f'best-f1 resuming from {resume_file}')
        else:
            logger.info(f'no checkpoint found in {config.MODEL.MULTI.RESUME}, ignoring auto resume')

    # 尝试自动恢复训练
    if config.TRAIN.AUTO_RESUME:
        if not os.path.exists(config.MULTI_OUTPUT):
            os.makedirs(config.MULTI_OUTPUT)
        resume_file = auto_resume_helper(config.MULTI_OUTPUT)
        if resume_file:
            if config.MODEL.MULTI.RESUME:
                logger.warning(f"auto-resume changing resume file from {config.MODEL.MULTI.RESUME} to {resume_file}")
            config.defrost()
            config.MODEL.MULTI.RESUME = resume_file
            config.freeze()
            logger.info(f'auto resuming from {resume_file}')
        else:
            logger.info(f'no checkpoint found in {config.MODEL.MULTI.RESUME}, ignoring auto resume')

    # 如果配置中指定了预训练模型，则加载预训练权重
    if config.MODEL.MULTI.RESUME:
        print(f"======> multi-model Resuming from {config.MODEL.MULTI.RESUME}....................")
        max_accuracy, epoch = load_checkpoint(config, model_without_ddp, optimizer, lr_scheduler, loss_scaler, logger)

    # 如果命令行参数指示进行训练
    if args.test == 0:
        logger.info("----------- Start training -----------")
        print('\n*** Start training ***\n')
        start_time = time.time()
        # 添加早停机制
        global_step = 0
        not_f1_inc_cnt = 0
        is_early_stop = False

        # 训练循环
        for epoch in range(config.TRAIN.START_EPOCH, config.TRAIN.EPOCHS):
            data_loader_train.sampler.set_epoch(epoch)
            train_one_epoch(config, model, criterion, data_loader_train, optimizer, epoch, mixup_fn, lr_scheduler,
                            loss_scaler)

            acc1, loss, f1, prauc,vulnerable_function_accuracy = validate2(config, data_loader_val, model)
            # 保存最佳F1分数的模型
            if f1 > best_f1 and prauc != 0:
                not_f1_inc_cnt = 0
                logger.info("  Best f1: %s", round(f1, 4))
                logger.info("  prauc: %s", round(prauc, 4))
                logger.info("  " + "*" * 20)
                logger.info("[%d] Best f1 changed into %.4f\n" % (epoch, round(f1, 4)))
                best_f1 = f1
                output_dir = os.path.join(config.MULTI_OUTPUT, 'checkpoint-best-f1')
                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)
                if True or args.data_num == -1:
                    model_to_save = model_without_ddp
                    output_model_file = os.path.join(output_dir, "pytorch_model.bin")
                    max_accuracy = max(max_accuracy, acc1)
                    save_bestf1_checkpoint(config, epoch, model_without_ddp, max_accuracy, optimizer, lr_scheduler,
                                           loss_scaler, logger)
                    torch.save(model_to_save.state_dict(), output_model_file)
                    logger.info("Save the best f1 model into %s", output_model_file)
            else:
                not_f1_inc_cnt += 1
                logger.info("f1 does not increase for %d epochs", not_f1_inc_cnt)
                if not_f1_inc_cnt > args.patience:
                    logger.info("Early stop as f1 do not increase for %d times", not_f1_inc_cnt)
                    logger.info("[%d] Early stop as not_f1_inc_cnt=%d\n" % (epoch, not_f1_inc_cnt))
                    is_early_stop = True
                    break

            logger.info(f"Accuracy of the network on the {len(val_data)} test images: {acc1:.4f}%")
            logger.info(f"loss of the network on the {len(val_data)} test images: {loss:.4f}%")
            logger.info(f"vulnerable_function_accuracy of the network on the {len(val_data)} test images: {vulnerable_function_accuracy:.4f}")
            logger.info(f'Max accuracy: {max_accuracy:.4f}%')
            best_f1 = max(best_f1, f1)
            logger.info(f'best f1 : {best_f1:.4f}%')

            logger.info("***** CUDA.empty_cache() *****")
            gc.collect()
            torch.cuda.empty_cache()

        total_time = time.time() - start_time
        total_time_str = str(datetime.timedelta(seconds=int(total_time)))
        logger.info('Training time {}'.format(total_time_str))

    # 如果命令行参数指示进行测试
    else:
        print('\n*** Start testing ***\n')
        acc1, loss, f1, prauc,vulnerable_function_accuracy = validate2(config, data_loader_test, model)
        logger.info(f"Accuracy of the network on the {len(test_data)} test images: {acc1:.1f}%")


def train_one_epoch(config, model, criterion, data_loader, optimizer, epoch, mixup_fn, lr_scheduler, loss_scaler):
    # 将模型设置为训练模式
    model.train()
    # 清空优化器的梯度
    optimizer.zero_grad()
    # 定义损失函数，这里使用的是交叉熵损失
    criterion = torch.nn.CrossEntropyLoss()

    # 计算数据加载器中的总步数
    num_steps = len(data_loader)
    # 初始化用于记录批处理时间的平均器
    batch_time = AverageMeter()
    # 初始化用于记录损失的平均器
    loss_meter = AverageMeter()
    # 初始化用于记录梯度范数的平均器
    norm_meter = AverageMeter()
    # 初始化用于记录损失缩放值的平均器
    scaler_meter = AverageMeter()

    # 记录训练开始时间
    start = time.time()
    # 记录每个批处理开始时间
    end = time.time()

    # 遍历数据加载器中的每个批处理
    for idx, (g, img_embedding, func_text_embedding, target,func_ids) in enumerate(data_loader):
        # 将图数据移动到模型所在的设备
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # 将图像嵌入移动到GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # 将文本嵌入移动到GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # 将目标标签移动到GPU
        targets = target.cuda(non_blocking=True)

        # 计算输出
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # 计算损失
        loss = criterion(outputs, targets)
        # 根据累积步数调整损失
        loss = loss / config.TRAIN.ACCUMULATION_STEPS

        # 计算梯度范数并更新梯度
        is_second_order = hasattr(optimizer, 'is_second_order') and optimizer.is_second_order
        grad_norm = loss_scaler(loss, optimizer, clip_grad=config.TRAIN.CLIP_GRAD,
                                parameters=model.parameters(), create_graph=is_second_order,
                                update_grad=(idx + 1) % config.TRAIN.ACCUMULATION_STEPS == 0)
        lr = optimizer.param_groups[0]['lr']
        if (idx + 1) % config.TRAIN.ACCUMULATION_STEPS == 0:
            optimizer.zero_grad()
            lr_scheduler.step_update((epoch * num_steps + idx) // config.TRAIN.ACCUMULATION_STEPS)
        loss_scale_value = loss_scaler.state_dict()["scale"]

        # 同步GPU以确保时间测量准确
        torch.cuda.synchronize()

        # 更新损失、梯度范数和损失缩放值的平均器
        loss_meter.update(loss.item(), targets.size(0))
        if grad_norm is not None:
            norm_meter.update(grad_norm)
        scaler_meter.update(loss_scale_value)
        batch_time.update(time.time() - end)
        end = time.time()

        # 打印训练信息
        if idx % config.PRINT_FREQ == 0:
            lr = optimizer.param_groups[0]['lr']
            wd = optimizer.param_groups[0]['weight_decay']
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            etas = batch_time.avg * (num_steps - idx)
            logger.info(
                f'Train: [{epoch}/{config.TRAIN.EPOCHS}][{idx}/{num_steps}]\t'
                f'eta {datetime.timedelta(seconds=int(etas))} lr {lr:.6f}\t wd {wd:.4f}\t'
                f'time {batch_time.val:.4f} ({batch_time.avg:.4f})\t'
                f'loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'grad_norm {norm_meter.val:.4f} ({norm_meter.avg:.4f})\t'
                f'loss_scale {scaler_meter.val:.4f} ({scaler_meter.avg:.4f})\t'
                f'mem {memory_used:.0f}MB')

    # 记录并打印每个epoch的训练时间
    epoch_time = time.time() - start
    logger.info(f"EPOCH {epoch} training takes {datetime.timedelta(seconds=int(epoch_time))}")


@torch.no_grad()
def validate(config, data_loader, model):
    # 设置批处理大小
    batch_size = config.DATA.BATCH_SIZE

    # 定义损失函数，这里使用的是交叉熵损失
    criterion = torch.nn.CrossEntropyLoss()
    # 将模型设置为评估模式
    model.eval()

    # 初始化用于记录批处理时间的平均器
    batch_time = AverageMeter()
    # 初始化用于记录损失的平均器
    loss_meter = AverageMeter()
    # 初始化用于记录准确率的平均器
    acc1_meter = AverageMeter()

    # 初始化变量，用于标记是否开始验证
    start_validate = True
    # 记录每个批处理开始时间
    end = time.time()

    # 打印开始加载数据的信息
    print("===============data loader start")

    # 遍历数据加载器中的每个批处理
    for idx, (g, img_embedding, func_text_embedding, target) in enumerate(data_loader):
        # 将图数据移动到模型所在的设备
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # 将图像嵌入移动到GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # 将文本嵌入移动到GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # 将目标标签移动到GPU
        targets = target.cuda(non_blocking=True)

        # 计算输出
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # 合并输出和概率
        if start_validate:
            all_output = outputs.data.float()
            all_prob = probs.data.float()
            all_target = targets.data.float()
            start_validate = False
        else:
            all_output = torch.cat((all_output, outputs.data.float()), 0)
            all_prob = torch.cat((all_prob, probs.data.float()), 0)
            all_target = torch.cat((all_target, targets.data.float()), 0)

        # 计算准确率和记录损失
        loss = criterion(outputs, targets)
        acc1, _ = accuracy(outputs, targets, topk=(1, 2))

        acc1 = reduce_tensor(acc1)
        loss = reduce_tensor(loss)
        loss_meter.update(loss.item(), targets.size(0))
        acc1_meter.update(acc1.item(), targets.size(0))

        # 测量经过的时间
        batch_time.update(time.time() - end)
        end = time.time()

        # 打印验证信息
        if idx % config.PRINT_FREQ == 0:
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            logger.info(
                f'Test: [{idx}/{len(data_loader)}]\t'
                f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                f'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'Acc@1 {acc1_meter.val:.3f} ({acc1_meter.avg:.3f})\t'
                f'Mem {memory_used:.0f}MB')

    # 计算整体的准确率、精确率、召回率和F1分数
    all_predict = all_prob[:, 1] > 0.5
    all_predict_list = all_predict.cpu().numpy()
    all_target_list = all_target.cpu().numpy()
    all_prob_list = all_prob.cpu().numpy()

    # 计算TP、FP、FN和TN
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for number in range(len(all_target_list)):
        if all_predict_list[number] == 1:
            if all_target_list[number] == 1:
                TP = TP + 1
            else:
                FP = FP + 1
        elif all_target_list[number] == 1:
            FN = FN + 1

    # 计算精确率、召回率和F1分数
    P = float(TP) / (TP + FP) if (TP + FP != 0) else 0
    R = float(TP) / (TP + FN) if (TP + FN != 0) else 0
    F1Score = float((2 * P * R) / (P + R)) if P + R != 0 else 0

    # 计算PRAUC
    prauc = 0.0
    if np.isfinite(all_prob_list[:, 1]).all():
        prauc = average_precision_score(all_target_list, all_prob_list[:, 1], pos_label=1)

    # 计算准确率
    acc = accuracy_score(all_target_list, all_predict_list)

    # 打印最终的评估结果
    logger.info(f' * Acc {acc:.3f} PRECISION {P:.3f} RECALL {R:.3f} F1 {F1Score:.3f} PRAUC {prauc:.3f}')

    # 返回平均准确率、平均损失、F1分数和PRAUC
    return acc1_meter.avg, loss_meter.avg, F1Score, prauc

    # 定义一个函数，用于计算列表中每个唯一元素的计数
def count(list):
        mask = np.unique(list)
        tmp = []
        for v in mask:
            tmp.append(np.sum(list == v))
        print(tmp)
        ts = np.max(tmp)
        max_v = mask[np.argmax(tmp)]
        return ts, max_v
# 配置日志记录器
logging.basicConfig(filename='validation.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
def validate2(config, data_loader, model):
    # 设置批处理大小
    batch_size = config.DATA.BATCH_SIZE
    # 配置日志记录器


    # 定义损失函数，这里使用的是交叉熵损失
    criterion = torch.nn.CrossEntropyLoss()
    # 将模型设置为评估模式
    model.eval()

    # 初始化用于记录批处理时间的平均器
    batch_time = AverageMeter()
    # 初始化用于记录损失的平均器
    loss_meter = AverageMeter()
    # 初始化用于记录准确率的平均器
    acc1_meter = AverageMeter()

    # 初始化变量，用于标记是否开始验证
    start_validate = True
    # 记录每个批处理开始时间
    end = time.time()

    # 打印开始加载数据的信息
    print("===============data loader start")
    # 用于记录漏洞函数的ID
    vulnerable_function_ids = []
    # 用于记录漏洞函数的预测情况
    vulnerable_function_predictions = []
    # 用于记录漏洞函数的真实情况
    vulnerable_function_targets = []
    # 遍历数据加载器中的每个批处理
    for idx, (g, img_embedding, func_text_embedding, target, func_ids) in enumerate(data_loader):
        # 将图数据移动到模型所在的设备
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # 将图像嵌入移动到GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # 将文本嵌入移动到GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # 将目标标签移动到GPU
        targets = target.cuda(non_blocking=True)

        # 计算输出
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # 合并输出和概率
        if start_validate:
            all_output = outputs.data.float()
            all_prob = probs.data.float()
            all_target = targets.data.float()
            start_validate = False
        else:
            all_output = torch.cat((all_output, outputs.data.float()), 0)
            all_prob = torch.cat((all_prob, probs.data.float()), 0)
            all_target = torch.cat((all_target, targets.data.float()), 0)

        # 计算准确率和记录损失
        loss = criterion(outputs, targets)
        acc1, _ = accuracy(outputs, targets, topk=(1, 2))

        acc1 = reduce_tensor(acc1)
        loss = reduce_tensor(loss)
        loss_meter.update(loss.item(), targets.size(0))
        acc1_meter.update(acc1.item(), targets.size(0))

        # 测量经过的时间
        batch_time.update(time.time() - end)
        end = time.time()
        # 记录漏洞函数的ID和预测情况
        predicted_labels = probs[:, 1] > 0.5
        for i in range(len(predicted_labels)):
            if targets[i] == 1:  # 只记录真实为漏洞的函数
                vulnerable_function_ids.append(func_ids[i])
                vulnerable_function_predictions.append(predicted_labels[i].item())
                vulnerable_function_targets.append(targets[i].item())

        # 打印验证信息
        if idx % config.PRINT_FREQ == 0:
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            logger.info(
                f'Test: [{idx}/{len(data_loader)}]\t'
                f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                f'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'Acc@1 {acc1_meter.val:.3f} ({acc1_meter.avg:.3f})\t'
                f'Mem {memory_used:.0f}MB')

    # 计算整体的准确率、精确率、召回率和F1分数
    all_predict = all_prob[:, 1] > 0.5
    all_predict_list = all_predict.cpu().numpy()
    all_target_list = all_target.cpu().numpy()
    all_prob_list = all_prob.cpu().numpy()

    # 计算TP、FP、FN和TN
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for number in range(len(all_target_list)):
        if all_predict_list[number] == 1:
            if all_target_list[number] == 1:
                TP = TP + 1
            else:
                FP = FP + 1
        elif all_target_list[number] == 1:
            FN = FN + 1

    # 计算精确率、召回率和F1分数
    P = float(TP) / (TP + FP) if (TP + FP != 0) else 0
    R = float(TP) / (TP + FN) if (TP + FN != 0) else 0
    F1Score = float((2 * P * R) / (P + R)) if P + R != 0 else 0

    # 计算漏洞函数的识别率
    if len(vulnerable_function_targets) > 0:
        vulnerable_function_accuracy = accuracy_score(vulnerable_function_targets, vulnerable_function_predictions)
    else:
        vulnerable_function_accuracy = 0.0

    # 计算PRAUC
    prauc = 0.0
    if np.isfinite(all_prob_list[:, 1]).all():
        prauc = average_precision_score(all_target_list, all_prob_list[:, 1], pos_label=1)

    # 计算准确率
    acc = accuracy_score(all_target_list, all_predict_list)

    # 打印最终的评估结果
    logger.info(f' * Acc {acc:.3f} PRECISION {P:.3f} RECALL {R:.3f} F1 {F1Score:.3f} PRAUC {prauc:.3f}vulnerable_function_accuracy {vulnerable_function_accuracy:.3f}')
    # 将预测结果记录到日志中
    logging.info('Vulnerable Function Predictions: %s', vulnerable_function_predictions)
    # 返回平均准确率、平均损失、F1分数和PRAUC
    return acc1_meter.avg, loss_meter.avg, F1Score, prauc,vulnerable_function_accuracy
def validate1(config, data_loader, model):
    # 设置批处理大小
    batch_size = config.DATA.BATCH_SIZE

    # 定义损失函数，这里使用的是交叉熵损失
    criterion = torch.nn.CrossEntropyLoss()
    # 将模型设置为评估模式
    model.eval()

    # 初始化用于记录批处理时间的平均器
    batch_time = AverageMeter()
    # 初始化用于记录损失的平均器
    loss_meter = AverageMeter()
    # 初始化用于记录准确率的平均器
    acc1_meter = AverageMeter()

    # 初始化变量，用于标记是否开始验证
    start_validate = True
    # 记录每个批处理开始时间
    end = time.time()

    # 打印开始加载数据的信息
    print("===============data loader start")

    # 用于记录漏洞函数的ID
    vulnerable_function_ids = []
    # 用于记录漏洞函数的预测情况
    vulnerable_function_predictions = []
    # 用于记录漏洞函数的真实情况
    vulnerable_function_targets = []

    # 遍历数据加载器中的每个批处理
    for idx, (g, img_embedding, func_text_embedding, target, func_ids) in enumerate(data_loader):
        # 将图数据移动到模型所在的设备
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # 将图像嵌入移动到GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # 将文本嵌入移动到GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # 将目标标签移动到GPU
        targets = target.cuda(non_blocking=True)

        # 计算输出
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # 合并输出和概率
        if start_validate:
            all_output = outputs.data.float()
            all_prob = probs.data.float()
            all_target = targets.data.float()
            start_validate = False
        else:
            all_output = torch.cat((all_output, outputs.data.float()), 0)
            all_prob = torch.cat((all_prob, probs.data.float()), 0)
            all_target = torch.cat((all_target, targets.data.float()), 0)

        # 计算准确率和记录损失
        loss = criterion(outputs, targets)
        acc1, _ = accuracy(outputs, targets, topk=(1, 2))

        acc1 = reduce_tensor(acc1)
        loss = reduce_tensor(loss)
        loss_meter.update(loss.item(), targets.size(0))
        acc1_meter.update(acc1.item(), targets.size(0))

        # 测量经过的时间
        batch_time.update(time.time() - end)
        end = time.time()

        # 记录漏洞函数的ID和预测情况
        predicted_labels = probs[:, 1] > 0.5
        for i in range(len(predicted_labels)):
            if targets[i] == 1:  # 只记录真实为漏洞的函数
                vulnerable_function_ids.append(func_ids[i])
                vulnerable_function_predictions.append(predicted_labels[i].item())
                vulnerable_function_targets.append(targets[i].item())

        # 打印验证信息
        if idx % config.PRINT_FREQ == 0:
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            logger.info(
                f'Test: [{idx}/{len(data_loader)}]\t'
                f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                f'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'Acc@1 {acc1_meter.val:.3f} ({acc1_meter.avg:.3f})\t'
                f'Mem {memory_used:.0f}MB')

    # 计算漏洞函数的识别率
    if len(vulnerable_function_targets) > 0:
        vulnerable_function_accuracy = accuracy_score(vulnerable_function_targets, vulnerable_function_predictions)
    else:
        vulnerable_function_accuracy = 0.0
        # 计算整体的准确率、精确率、召回率和F1分数
        all_predict = all_prob[:, 1] > 0.5
        all_predict_list = all_predict.cpu().numpy()
        all_target_list = all_target.cpu().numpy()
        all_prob_list = all_prob.cpu().numpy()


    # 打印最终的评估结果
    logger.info(f' * Vulnerable Function IDs: {vulnerable_function_ids}')
    logger.info(f' * Vulnerable Function Accuracy: {vulnerable_function_accuracy:.3f}')

    # 返回平均准确率、平均损失、F1分数和PRAUC
    return acc1_meter.avg, loss_meter.avg, F1Score, prauc


if __name__ == '__main__':
    # 解析命令行参数和配置文件，返回命令行参数和配置对象
    print(os.getcwd())
    RANK = 0
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '12826'
    WORLD_SIZE = 1

    MASTER_ADDR = 'localhost'

    MASTER_PORT = 12345

    args, config = parse_option()

    # 检查是否有可用的GPU，并根据GPU数量设置是否使用CUDA
    args.cuda = args.ngpu > 0 and torch.cuda.is_available()

    # 如果配置中指定了AMP_OPT_LEVEL，则打印警告信息，提示使用PyTorch的AMP而不是Apex的AMP
    # if config.AMP_OPT_LEVEL:
    #     print("[warning] Apex amp has been deprecated, please use pytorch amp instead!")
    # print("---------------------")
    # print(os.environ)

    # 如果启用了CUDA并且环境变量中包含RANK和WORLD_SIZE，则初始化分布式训练环境
    # print(os.environ)
    if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
        rank = int(os.environ["RANK"])
        world_size = int(os.environ['WORLD_SIZE'])
        print(f"RANK and WORLD_SIZE in environ: {rank}/{world_size}")
    else:
        rank = -1
        world_size = -1
    torch.cuda.set_device(config.LOCAL_RANK)  #
    # 设置分布式环境
    dist.init_process_group(backend='nccl', init_method='env://',
                            world_size=1,
                            rank=0)
    #  torch.distributed.init_process_group(backend='nccl', init_method='env://', world_size=world_size, rank=rank)
    # user NCCL for GPU, use gloo for CPU
    torch.distributed.barrier()

    # 设置随机种子，以确保结果的可重复性
    seed = config.SEED + dist.get_rank()
    seed = args.seed
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if args.ngpu > 0:
        torch.cuda.manual_seed_all(args.seed)
    # 启用CuDNN的基准模式，以加速训练
    cudnn.benchmark = True

    # 根据分布式训练的总批量大小和梯度累积步数调整学习率
    linear_scaled_lr = config.TRAIN.BASE_LR * config.DATA.BATCH_SIZE * dist.get_world_size() / 512.0
    linear_scaled_warmup_lr = config.TRAIN.WARMUP_LR * config.DATA.BATCH_SIZE * dist.get_world_size() / 512.0
    linear_scaled_min_lr = config.TRAIN.MIN_LR * config.DATA.BATCH_SIZE * dist.get_world_size() / 512.0
    if config.TRAIN.ACCUMULATION_STEPS > 1:
        linear_scaled_lr = linear_scaled_lr * config.TRAIN.ACCUMULATION_STEPS
        linear_scaled_warmup_lr = linear_scaled_warmup_lr * config.TRAIN.ACCUMULATION_STEPS
        linear_scaled_min_lr = linear_scaled_min_lr * config.TRAIN.ACCUMULATION_STEPS
    config.defrost()
    config.TRAIN.BASE_LR = linear_scaled_lr
    print(f"==============> TRAIN.BASE_LR{config.TRAIN.BASE_LR}....................")
    config.TRAIN.WARMUP_LR = linear_scaled_warmup_lr
    config.TRAIN.MIN_LR = linear_scaled_min_lr
    config.freeze()

    # 创建输出目录
    os.makedirs(config.OUTPUT, exist_ok=True)
    # 创建日志记录器
    logger = create_logger(output_dir=config.OUTPUT, dist_rank=dist.get_rank(), name=f"{config.MODEL.NAME}")

    # 如果当前进程是主进程，则保存配置文件
    if dist.get_rank() == 0:
        path = os.path.join(config.OUTPUT, "config.json")
        with open(path, "w") as f:
            f.write(config.dump())
        logger.info(f"Full config saved to {path}")

    # 打印配置信息
    logger.info(config.dump())
    logger.info(json.dumps(vars(args)))

    # 调用主函数开始训练
    # main(config)
    myMain(config, args)

