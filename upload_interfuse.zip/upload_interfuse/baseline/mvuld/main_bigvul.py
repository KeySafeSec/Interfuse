from xmlrpc.client import FastMarshaller
import torch as th
import os
import sys
import dgl
from torchmetrics import F1Score
os.environ['CUDA_LAUNCH_BLOCKING'] = "1"
import time
import json
import random
import argparse
import datetime
import numpy as np
import torch.nn.functional as F
from tqdm import tqdm
import gc
import logging
import torch
import torch.backends.cudnn as cudnn
import torch.distributed as dist

from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy
from timm.utils import accuracy, AverageMeter

from models.new_model import Multi_DefectModel_noFunc,Multi_DefectModel_noGlobalImage

from models.GraphModel import Multi_DefectModel_100,Multi_DefectModel_110,Multi_DefectModel_011,\
    Multi_DefectModel_001,Multi_DefectModel_NOGAT3,Multi_DefectModel_NOGAT,Multi_DefectModel_NOGAT4,Multi_DefectModel_noGraph,\
    Multi_DefectModel_GATPOS,Multi_DefectModel,Multi_DefectModel_NOGAT2,Multi_DefectModel_new_GCN

from models.MotivationModel import Multi_DefectModel_Image,Multi_DefectModel_FuncText,Multi_DefectModel_Graph,\
    Multi_DefectModel_Graph1,Multi_DefectModel_Graph2

import ml
from sklearn import metrics
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)

from config import get_config
from models import build_model
from data.bigvul_dataset import bigvul_dataset,bigvul_loader_graph
from lr_scheduler import build_scheduler
from optimizer import build_optimizer
from logger import create_logger
# from utils import load_checkpoint, load_pretrained, save_checkpoint, NativeScalerWithGradNormCount, auto_resume_helper, \
#     reduce_tensor
from utils_multi import load_checkpoint, load_pretrained, save_checkpoint, NativeScalerWithGradNormCount, auto_resume_helper, \
    reduce_tensor,save_bestf1_checkpoint,resume_bestf1_helper

from IPython.core.ultratb import ColorTB
sys.excepthook = ColorTB()

import warnings
warnings.filterwarnings("ignore")


def parse_option():
    parser = argparse.ArgumentParser('Swin Transformer training and evaluation script', add_help=False)
    parser.add_argument('--seed', type=int, default=12345,
                        help="random seed for initialization")
    parser.add_argument('--cfg', type=str, default="configs/mySwin/swinv2_base_patch4_window24to28_384to448_1ktoMYDATA_ft.yaml",metavar="FILE", help='path to config file', )
    parser.add_argument(
        "--opts",
        help="Modify config options by adding 'KEY VALUE' pairs. ",
        default=None,
        nargs='+',
    )
    # early stop
    parser.add_argument("--patience", default=50, type=int) 
    parser.add_argument('--test', type=int, default=0, help='Train mode=0;Test mode=1')
    # easy config modification 
    parser.add_argument('--batch-size', type=int,default=4, help="batch size for single GPU")
    parser.add_argument('--data-path', type=str, help='path to dataset')
    parser.add_argument('--test_data_path', type=str, help='path to test dataset')
    parser.add_argument('--zip', action='store_true', help='use zipped dataset instead of folder dataset')
    parser.add_argument('--cache-mode', type=str, default='part', choices=['no', 'full', 'part'],
                        help='no: no cache, '
                             'full: cache all data, '
                             'part: sharding the dataset into nonoverlapping pieces and only cache one piece')
    parser.add_argument('--pretrained',default="configs/mySwin/swinv2_base_patch4_window12to24_192to384_22kto1k_ft.pth",
                        help='pretrained weight from checkpoint, could be imagenet22k pretrained weight')
    parser.add_argument('--resume',default=True ,help='resume from swin checkpoint')
    parser.add_argument('--myresume', help='resume from multimodel checkpoint')
    parser.add_argument('--accumulation-steps', type=int, help="gradient accumulation steps")
    # Gradient Accumulation
    parser.add_argument('--use-checkpoint', action='store_true',
                        help="whether to use gradient checkpointing to save memory")
    parser.add_argument('--disable_amp', action='store_true', help='Disable pytorch amp')
    parser.add_argument('--amp-opt-level', type=str, choices=['O0', 'O1', 'O2'],
                        help='mixed precision opt level, if O0, no amp is used (deprecated!)')
    parser.add_argument('--output', default='my_output', type=str, metavar='PATH',
                        help='root of output folder, the full path is <output>/<model_name>/<tag> (default: output)')
    parser.add_argument('--tag', help='tag of experiment')
    parser.add_argument('--eval', action='store_true', help='Perform evaluation only')
    parser.add_argument('--throughput', action='store_true', help='Test throughput only')
    parser.add_argument('--ngpu', type=int, default=1, help='0 = CPU, 1 = CUDA, 1 < DataParallel')
    # distributed training
    parser.add_argument("--local_rank", type=int,default=0, help='local rank for DistributedDataParallel')

    args, unparsed = parser.parse_known_args()

    config = get_config(args)

    return args, config


def myMain(config,args):
    # set random seeds for reproducibility (currently commented out; uncomment if needed in actual runs)
    # setup_seed()

    # load datasets and create data loaders
    # bigvul_loader_graph loads the training, validation, and test datasets according to the configuration and creates the corresponding data loaders
    # mixup_fn is used for data augmentation such as mixup
    train_data, val_data, test_data, data_loader_train, data_loader_val, data_loader_test, mixup_fn = bigvul_loader_graph(
        config)

    # print the sizes of the training, validation, and test datasets
    print(f"train={len(train_data)} val={len(val_data)} test={len(test_data)}")

    # select different model architectures according to the research question (RQ)
    # # Multi_DefectModel_new_GCN is a new GCN-based model
    model = Multi_DefectModel_new_GCN(config=config)
    #
    # # the following are other model architectures for different research questions or experimental purposes
    # model = Multi_DefectModel_Image(config=config)
    # model = Multi_DefectModel_FuncText(config=config)
    # model = Multi_DefectModel_Graph(config=config)
    # model = Multi_DefectModel_Graph1(config=config)
    # model = Multi_DefectModel_Graph2(config=config)
    #
    # model = Multi_DefectModel_noGlobalImage(config=config) # model without global image features
    # model = Multi_DefectModel_noFunc(config=config) # model without function-text features
    # model = Multi_DefectModel_noGraph(config=config) # model without graph features
    #
    # model = Multi_DefectModel(config=config) # model using GAT
    # # model = Multi_DefectModel_NOGAT2(config=config) # model using POS+GCN
    # #
    # model = Multi_DefectModel_100(config=config)
    # # model = Multi_DefectModel_110(config=config)
    # # model = Multi_DefectModel_011(config=config)
    # # model = Multi_DefectModel_001(config=config)

    # move the model to the GPU
    model.cuda()

    # create a non-DDP reference to the model for later operations
    model_without_ddp = model

    # create the optimizer from the configuration
    optimizer = build_optimizer(config, model)  # use the AdamW optimizer

    # wrap the model with DDP for multi-GPU training
    model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[config.LOCAL_RANK], broadcast_buffers=False,
                                                      find_unused_parameters=True)

    # log the CUDA device used for training
    cuda = next(model.parameters()).device
    logger.info(f"train cuda device :{cuda} ")

    # create the loss scaler
    # loss_scaler = NativeScalerWithGradNormCount()
    loss_scaler=NativeScalerWithGradNormCount.AmpScaler()

    # print the learning-rate scheduler name
    print(f"--------lr = {config.TRAIN.LR_SCHEDULER.NAME}---------")

    # create the learning-rate scheduler from the configuration and data-loader length
    if config.TRAIN.ACCUMULATION_STEPS > 1:
        lr_scheduler = build_scheduler(config, optimizer, len(data_loader_train) // config.TRAIN.ACCUMULATION_STEPS)
    else:
        lr_scheduler = build_scheduler(config, optimizer, len(data_loader_train))

    # select the loss function according to the configuration
    if config.AUG.MIXUP > 0.:
        criterion = SoftTargetCrossEntropy()
    elif config.MODEL.LABEL_SMOOTHING > 0.:
        criterion = LabelSmoothingCrossEntropy(smoothing=config.MODEL.LABEL_SMOOTHING)
    else:
        criterion = torch.nn.CrossEntropyLoss()

    # initialize the best accuracy and F1 score
    max_accuracy = 0.0
    best_f1 = 0.0

    # try to resume training from the best-F1 model
    if config.TRAIN.BEST_RESUME:
        if not os.path.exists(config.MULTI_OUTPUT):
            os.makedirs(config.MULTI_OUTPUT)
        resume_file = resume_bestf1_helper(config.MULTI_OUTPUT)
        if resume_file:
            if config.MODEL.MULTI.RESUME:
                logger.warning(f"best-resume changing resume file from {config.MODEL.MULTI.RESUME} to {resume_file}")
            config.defrost()
            config.MODEL.MULTI.RESUME = resume_file
            config.freeze()
            logger.info(f'best-f1 resuming from {resume_file}')
        else:
            logger.info(f'no checkpoint found in {config.MODEL.MULTI.RESUME}, ignoring auto resume')

    # try automatic training resumption
    if config.TRAIN.AUTO_RESUME:
        if not os.path.exists(config.MULTI_OUTPUT):
            os.makedirs(config.MULTI_OUTPUT)
        resume_file = auto_resume_helper(config.MULTI_OUTPUT)
        if resume_file:
            if config.MODEL.MULTI.RESUME:
                logger.warning(f"auto-resume changing resume file from {config.MODEL.MULTI.RESUME} to {resume_file}")
            config.defrost()
            config.MODEL.MULTI.RESUME = resume_file
            config.freeze()
            logger.info(f'auto resuming from {resume_file}')
        else:
            logger.info(f'no checkpoint found in {config.MODEL.MULTI.RESUME}, ignoring auto resume')

    # load pretrained weights if a pretrained model is specified in the configuration
    if config.MODEL.MULTI.RESUME:
        print(f"======> multi-model Resuming from {config.MODEL.MULTI.RESUME}....................")
        max_accuracy, epoch = load_checkpoint(config, model_without_ddp, optimizer, lr_scheduler, loss_scaler, logger)

    # if the command-line arguments request training
    if args.test == 0:
        logger.info("----------- Start training -----------")
        print('\n*** Start training ***\n')
        start_time = time.time()
        # add early stopping
        global_step = 0
        not_f1_inc_cnt = 0
        is_early_stop = False

        # training loop
        for epoch in range(config.TRAIN.START_EPOCH, config.TRAIN.EPOCHS):
            data_loader_train.sampler.set_epoch(epoch)
            train_one_epoch(config, model, criterion, data_loader_train, optimizer, epoch, mixup_fn, lr_scheduler,
                            loss_scaler)

            acc1, loss, f1, prauc,vulnerable_function_accuracy = validate2(config, data_loader_val, model)
            # save the model with the best F1 score
            if f1 > best_f1 and prauc != 0:
                not_f1_inc_cnt = 0
                logger.info("  Best f1: %s", round(f1, 4))
                logger.info("  prauc: %s", round(prauc, 4))
                logger.info("  " + "*" * 20)
                logger.info("[%d] Best f1 changed into %.4f\n" % (epoch, round(f1, 4)))
                best_f1 = f1
                output_dir = os.path.join(config.MULTI_OUTPUT, 'checkpoint-best-f1')
                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)
                if True or args.data_num == -1:
                    model_to_save = model_without_ddp
                    output_model_file = os.path.join(output_dir, "pytorch_model.bin")
                    max_accuracy = max(max_accuracy, acc1)
                    save_bestf1_checkpoint(config, epoch, model_without_ddp, max_accuracy, optimizer, lr_scheduler,
                                           loss_scaler, logger)
                    torch.save(model_to_save.state_dict(), output_model_file)
                    logger.info("Save the best f1 model into %s", output_model_file)
            else:
                not_f1_inc_cnt += 1
                logger.info("f1 does not increase for %d epochs", not_f1_inc_cnt)
                if not_f1_inc_cnt > args.patience:
                    logger.info("Early stop as f1 do not increase for %d times", not_f1_inc_cnt)
                    logger.info("[%d] Early stop as not_f1_inc_cnt=%d\n" % (epoch, not_f1_inc_cnt))
                    is_early_stop = True
                    break

            logger.info(f"Accuracy of the network on the {len(val_data)} test images: {acc1:.4f}%")
            logger.info(f"loss of the network on the {len(val_data)} test images: {loss:.4f}%")
            logger.info(f"vulnerable_function_accuracy of the network on the {len(val_data)} test images: {vulnerable_function_accuracy:.4f}")
            logger.info(f'Max accuracy: {max_accuracy:.4f}%')
            best_f1 = max(best_f1, f1)
            logger.info(f'best f1 : {best_f1:.4f}%')

            logger.info("***** CUDA.empty_cache() *****")
            gc.collect()
            torch.cuda.empty_cache()

        total_time = time.time() - start_time
        total_time_str = str(datetime.timedelta(seconds=int(total_time)))
        logger.info('Training time {}'.format(total_time_str))

    # if the command-line arguments request testing
    else:
        print('\n*** Start testing ***\n')
        acc1, loss, f1, prauc,vulnerable_function_accuracy = validate2(config, data_loader_test, model)
        logger.info(f"Accuracy of the network on the {len(test_data)} test images: {acc1:.1f}%")


def train_one_epoch(config, model, criterion, data_loader, optimizer, epoch, mixup_fn, lr_scheduler, loss_scaler):
    # set the model to training mode
    model.train()
    # clear optimizer gradients
    optimizer.zero_grad()
    # define the loss function; cross-entropy loss is used here
    criterion = torch.nn.CrossEntropyLoss()

    # compute the total number of steps in the data loader
    num_steps = len(data_loader)
    # initialize the meter for batch-processing time
    batch_time = AverageMeter()
    # initialize the meter for loss
    loss_meter = AverageMeter()
    # initialize the meter for gradient norm
    norm_meter = AverageMeter()
    # initialize the meter for loss-scaling values
    scaler_meter = AverageMeter()

    # record the training start time
    start = time.time()
    # record the start time of each batch
    end = time.time()

    # iterate over each batch in the data loader
    for idx, (g, img_embedding, func_text_embedding, target,func_ids) in enumerate(data_loader):
        # move graph data to the model device
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # move image embeddings to the GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # move text embeddings to the GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # move target labels to the GPU
        targets = target.cuda(non_blocking=True)

        # compute outputs
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # compute the loss
        loss = criterion(outputs, targets)
        # scale the loss according to the accumulation steps
        loss = loss / config.TRAIN.ACCUMULATION_STEPS

        # compute the gradient norm and update gradients
        is_second_order = hasattr(optimizer, 'is_second_order') and optimizer.is_second_order
        grad_norm = loss_scaler(loss, optimizer, clip_grad=config.TRAIN.CLIP_GRAD,
                                parameters=model.parameters(), create_graph=is_second_order,
                                update_grad=(idx + 1) % config.TRAIN.ACCUMULATION_STEPS == 0)
        lr = optimizer.param_groups[0]['lr']
        if (idx + 1) % config.TRAIN.ACCUMULATION_STEPS == 0:
            optimizer.zero_grad()
            lr_scheduler.step_update((epoch * num_steps + idx) // config.TRAIN.ACCUMULATION_STEPS)
        loss_scale_value = loss_scaler.state_dict()["scale"]

        # synchronize the GPU for accurate timing
        torch.cuda.synchronize()

        # update the meters for loss, gradient norm, and loss scale
        loss_meter.update(loss.item(), targets.size(0))
        if grad_norm is not None:
            norm_meter.update(grad_norm)
        scaler_meter.update(loss_scale_value)
        batch_time.update(time.time() - end)
        end = time.time()

        # print training information
        if idx % config.PRINT_FREQ == 0:
            lr = optimizer.param_groups[0]['lr']
            wd = optimizer.param_groups[0]['weight_decay']
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            etas = batch_time.avg * (num_steps - idx)
            logger.info(
                f'Train: [{epoch}/{config.TRAIN.EPOCHS}][{idx}/{num_steps}]\t'
                f'eta {datetime.timedelta(seconds=int(etas))} lr {lr:.6f}\t wd {wd:.4f}\t'
                f'time {batch_time.val:.4f} ({batch_time.avg:.4f})\t'
                f'loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'grad_norm {norm_meter.val:.4f} ({norm_meter.avg:.4f})\t'
                f'loss_scale {scaler_meter.val:.4f} ({scaler_meter.avg:.4f})\t'
                f'mem {memory_used:.0f}MB')

    # record and print the training time for each epoch
    epoch_time = time.time() - start
    logger.info(f"EPOCH {epoch} training takes {datetime.timedelta(seconds=int(epoch_time))}")


@torch.no_grad()
def validate(config, data_loader, model):
    # set the batch size
    batch_size = config.DATA.BATCH_SIZE

    # define the loss function; cross-entropy loss is used here
    criterion = torch.nn.CrossEntropyLoss()
    # set the model to evaluation mode
    model.eval()

    # initialize the meter for batch-processing time
    batch_time = AverageMeter()
    # initialize the meter for loss
    loss_meter = AverageMeter()
    # initialize the meter for accuracy
    acc1_meter = AverageMeter()

    # initialize a flag indicating whether validation has started
    start_validate = True
    # record the start time of each batch
    end = time.time()

    # print a message indicating that data loading has started
    print("===============data loader start")

    # iterate over each batch in the data loader
    for idx, (g, img_embedding, func_text_embedding, target) in enumerate(data_loader):
        # move graph data to the model device
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # move image embeddings to the GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # move text embeddings to the GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # move target labels to the GPU
        targets = target.cuda(non_blocking=True)

        # compute outputs
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # concatenate outputs and probabilities
        if start_validate:
            all_output = outputs.data.float()
            all_prob = probs.data.float()
            all_target = targets.data.float()
            start_validate = False
        else:
            all_output = torch.cat((all_output, outputs.data.float()), 0)
            all_prob = torch.cat((all_prob, probs.data.float()), 0)
            all_target = torch.cat((all_target, targets.data.float()), 0)

        # compute accuracy and record the loss
        loss = criterion(outputs, targets)
        acc1, _ = accuracy(outputs, targets, topk=(1, 2))

        acc1 = reduce_tensor(acc1)
        loss = reduce_tensor(loss)
        loss_meter.update(loss.item(), targets.size(0))
        acc1_meter.update(acc1.item(), targets.size(0))

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # print validation information
        if idx % config.PRINT_FREQ == 0:
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            logger.info(
                f'Test: [{idx}/{len(data_loader)}]\t'
                f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                f'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'Acc@1 {acc1_meter.val:.3f} ({acc1_meter.avg:.3f})\t'
                f'Mem {memory_used:.0f}MB')

    # compute overall accuracy, precision, recall, and F1 score
    all_predict = all_prob[:, 1] > 0.5
    all_predict_list = all_predict.cpu().numpy()
    all_target_list = all_target.cpu().numpy()
    all_prob_list = all_prob.cpu().numpy()

    # compute TP, FP, FN, and TN
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for number in range(len(all_target_list)):
        if all_predict_list[number] == 1:
            if all_target_list[number] == 1:
                TP = TP + 1
            else:
                FP = FP + 1
        elif all_target_list[number] == 1:
            FN = FN + 1

    # compute precision, recall, and F1 score
    P = float(TP) / (TP + FP) if (TP + FP != 0) else 0
    R = float(TP) / (TP + FN) if (TP + FN != 0) else 0
    F1Score = float((2 * P * R) / (P + R)) if P + R != 0 else 0

    # compute PR-AUC
    prauc = 0.0
    if np.isfinite(all_prob_list[:, 1]).all():
        prauc = average_precision_score(all_target_list, all_prob_list[:, 1], pos_label=1)

    # compute accuracy
    acc = accuracy_score(all_target_list, all_predict_list)

    # print the final evaluation results
    logger.info(f' * Acc {acc:.3f} PRECISION {P:.3f} RECALL {R:.3f} F1 {F1Score:.3f} PRAUC {prauc:.3f}')

    # return mean accuracy, mean loss, F1 score, and PR-AUC
    return acc1_meter.avg, loss_meter.avg, F1Score, prauc

    # define a function to count occurrences of each unique element in a list
def count(list):
        mask = np.unique(list)
        tmp = []
        for v in mask:
            tmp.append(np.sum(list == v))
        print(tmp)
        ts = np.max(tmp)
        max_v = mask[np.argmax(tmp)]
        return ts, max_v
# configure the logger
logging.basicConfig(filename='validation.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
def validate2(config, data_loader, model):
    # set the batch size
    batch_size = config.DATA.BATCH_SIZE
    # configure the logger


    # define the loss function; cross-entropy loss is used here
    criterion = torch.nn.CrossEntropyLoss()
    # set the model to evaluation mode
    model.eval()

    # initialize the meter for batch-processing time
    batch_time = AverageMeter()
    # initialize the meter for loss
    loss_meter = AverageMeter()
    # initialize the meter for accuracy
    acc1_meter = AverageMeter()

    # initialize a flag indicating whether validation has started
    start_validate = True
    # record the start time of each batch
    end = time.time()

    # print a message indicating that data loading has started
    print("===============data loader start")
    # store IDs of vulnerable functions
    vulnerable_function_ids = []
    # store predictions for vulnerable functions
    vulnerable_function_predictions = []
    # store ground truth for vulnerable functions
    vulnerable_function_targets = []
    # iterate over each batch in the data loader
    for idx, (g, img_embedding, func_text_embedding, target, func_ids) in enumerate(data_loader):
        # move graph data to the model device
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # move image embeddings to the GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # move text embeddings to the GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # move target labels to the GPU
        targets = target.cuda(non_blocking=True)

        # compute outputs
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # concatenate outputs and probabilities
        if start_validate:
            all_output = outputs.data.float()
            all_prob = probs.data.float()
            all_target = targets.data.float()
            start_validate = False
        else:
            all_output = torch.cat((all_output, outputs.data.float()), 0)
            all_prob = torch.cat((all_prob, probs.data.float()), 0)
            all_target = torch.cat((all_target, targets.data.float()), 0)

        # compute accuracy and record the loss
        loss = criterion(outputs, targets)
        acc1, _ = accuracy(outputs, targets, topk=(1, 2))

        acc1 = reduce_tensor(acc1)
        loss = reduce_tensor(loss)
        loss_meter.update(loss.item(), targets.size(0))
        acc1_meter.update(acc1.item(), targets.size(0))

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()
        # record vulnerable-function IDs and predictions
        predicted_labels = probs[:, 1] > 0.5
        for i in range(len(predicted_labels)):
            if targets[i] == 1:  # only record functions whose ground-truth label is vulnerable
                vulnerable_function_ids.append(func_ids[i])
                vulnerable_function_predictions.append(predicted_labels[i].item())
                vulnerable_function_targets.append(targets[i].item())

        # print validation information
        if idx % config.PRINT_FREQ == 0:
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            logger.info(
                f'Test: [{idx}/{len(data_loader)}]\t'
                f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                f'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'Acc@1 {acc1_meter.val:.3f} ({acc1_meter.avg:.3f})\t'
                f'Mem {memory_used:.0f}MB')

    # compute overall accuracy, precision, recall, and F1 score
    all_predict = all_prob[:, 1] > 0.5
    all_predict_list = all_predict.cpu().numpy()
    all_target_list = all_target.cpu().numpy()
    all_prob_list = all_prob.cpu().numpy()

    # compute TP, FP, FN, and TN
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for number in range(len(all_target_list)):
        if all_predict_list[number] == 1:
            if all_target_list[number] == 1:
                TP = TP + 1
            else:
                FP = FP + 1
        elif all_target_list[number] == 1:
            FN = FN + 1

    # compute precision, recall, and F1 score
    P = float(TP) / (TP + FP) if (TP + FP != 0) else 0
    R = float(TP) / (TP + FN) if (TP + FN != 0) else 0
    F1Score = float((2 * P * R) / (P + R)) if P + R != 0 else 0

    # compute the detection rate for vulnerable functions
    if len(vulnerable_function_targets) > 0:
        vulnerable_function_accuracy = accuracy_score(vulnerable_function_targets, vulnerable_function_predictions)
    else:
        vulnerable_function_accuracy = 0.0

    # compute PR-AUC
    prauc = 0.0
    if np.isfinite(all_prob_list[:, 1]).all():
        prauc = average_precision_score(all_target_list, all_prob_list[:, 1], pos_label=1)

    # compute accuracy
    acc = accuracy_score(all_target_list, all_predict_list)

    # print the final evaluation results
    logger.info(f' * Acc {acc:.3f} PRECISION {P:.3f} RECALL {R:.3f} F1 {F1Score:.3f} PRAUC {prauc:.3f}vulnerable_function_accuracy {vulnerable_function_accuracy:.3f}')
    # write prediction results to the log
    logging.info('Vulnerable Function Predictions: %s', vulnerable_function_predictions)
    # return mean accuracy, mean loss, F1 score, and PR-AUC
    return acc1_meter.avg, loss_meter.avg, F1Score, prauc,vulnerable_function_accuracy
def validate1(config, data_loader, model):
    # set the batch size
    batch_size = config.DATA.BATCH_SIZE

    # define the loss function; cross-entropy loss is used here
    criterion = torch.nn.CrossEntropyLoss()
    # set the model to evaluation mode
    model.eval()

    # initialize the meter for batch-processing time
    batch_time = AverageMeter()
    # initialize the meter for loss
    loss_meter = AverageMeter()
    # initialize the meter for accuracy
    acc1_meter = AverageMeter()

    # initialize a flag indicating whether validation has started
    start_validate = True
    # record the start time of each batch
    end = time.time()

    # print a message indicating that data loading has started
    print("===============data loader start")

    # store IDs of vulnerable functions
    vulnerable_function_ids = []
    # store predictions for vulnerable functions
    vulnerable_function_predictions = []
    # store ground truth for vulnerable functions
    vulnerable_function_targets = []

    # iterate over each batch in the data loader
    for idx, (g, img_embedding, func_text_embedding, target, func_ids) in enumerate(data_loader):
        # move graph data to the model device
        cuda = next(model.parameters()).device
        g = g.to(cuda)

        # move image embeddings to the GPU
        img_embedding = img_embedding.cuda(non_blocking=True)
        # move text embeddings to the GPU
        func_text_embedding = func_text_embedding.cuda(non_blocking=True)
        # move target labels to the GPU
        targets = target.cuda(non_blocking=True)

        # compute outputs
        with torch.cuda.amp.autocast(enabled=False):
            outputs = model(g, img_embedding, func_text_embedding)
            probs = F.softmax(outputs, dim=1)

        # concatenate outputs and probabilities
        if start_validate:
            all_output = outputs.data.float()
            all_prob = probs.data.float()
            all_target = targets.data.float()
            start_validate = False
        else:
            all_output = torch.cat((all_output, outputs.data.float()), 0)
            all_prob = torch.cat((all_prob, probs.data.float()), 0)
            all_target = torch.cat((all_target, targets.data.float()), 0)

        # compute accuracy and record the loss
        loss = criterion(outputs, targets)
        acc1, _ = accuracy(outputs, targets, topk=(1, 2))

        acc1 = reduce_tensor(acc1)
        loss = reduce_tensor(loss)
        loss_meter.update(loss.item(), targets.size(0))
        acc1_meter.update(acc1.item(), targets.size(0))

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        # record vulnerable-function IDs and predictions
        predicted_labels = probs[:, 1] > 0.5
        for i in range(len(predicted_labels)):
            if targets[i] == 1:  # only record functions whose ground-truth label is vulnerable
                vulnerable_function_ids.append(func_ids[i])
                vulnerable_function_predictions.append(predicted_labels[i].item())
                vulnerable_function_targets.append(targets[i].item())

        # print validation information
        if idx % config.PRINT_FREQ == 0:
            memory_used = torch.cuda.max_memory_allocated() / (1024.0 * 1024.0)
            logger.info(
                f'Test: [{idx}/{len(data_loader)}]\t'
                f'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                f'Loss {loss_meter.val:.4f} ({loss_meter.avg:.4f})\t'
                f'Acc@1 {acc1_meter.val:.3f} ({acc1_meter.avg:.3f})\t'
                f'Mem {memory_used:.0f}MB')

    # compute the detection rate for vulnerable functions
    if len(vulnerable_function_targets) > 0:
        vulnerable_function_accuracy = accuracy_score(vulnerable_function_targets, vulnerable_function_predictions)
    else:
        vulnerable_function_accuracy = 0.0
        # compute overall accuracy, precision, recall, and F1 score
        all_predict = all_prob[:, 1] > 0.5
        all_predict_list = all_predict.cpu().numpy()
        all_target_list = all_target.cpu().numpy()
        all_prob_list = all_prob.cpu().numpy()


    # print the final evaluation results
    logger.info(f' * Vulnerable Function IDs: {vulnerable_function_ids}')
    logger.info(f' * Vulnerable Function Accuracy: {vulnerable_function_accuracy:.3f}')

    # return mean accuracy, mean loss, F1 score, and PR-AUC
    return acc1_meter.avg, loss_meter.avg, F1Score, prauc


if __name__ == '__main__':
    # parse command-line arguments and the configuration file, returning the argument and configuration objects
    print(os.getcwd())
    RANK = 0
    os.environ['MASTER_ADDR'] = 'localhost'
    os.environ['MASTER_PORT'] = '12826'
    WORLD_SIZE = 1

    MASTER_ADDR = 'localhost'

    MASTER_PORT = 12345

    args, config = parse_option()

    # check for available GPUs and decide whether to use CUDA based on the GPU count
    args.cuda = args.ngpu > 0 and torch.cuda.is_available()

    # if AMP_OPT_LEVEL is specified, print a warning recommending PyTorch AMP instead of Apex AMP
    # if config.AMP_OPT_LEVEL:
    #     print("[warning] Apex amp has been deprecated, please use pytorch amp instead!")
    # print("---------------------")
    # print(os.environ)

    # if CUDA is enabled and RANK and WORLD_SIZE are present in the environment, initialize distributed training
    # print(os.environ)
    if 'RANK' in os.environ and 'WORLD_SIZE' in os.environ:
        rank = int(os.environ["RANK"])
        world_size = int(os.environ['WORLD_SIZE'])
        print(f"RANK and WORLD_SIZE in environ: {rank}/{world_size}")
    else:
        rank = -1
        world_size = -1
    torch.cuda.set_device(config.LOCAL_RANK)  #
    # set up the distributed environment
    dist.init_process_group(backend='nccl', init_method='env://',
                            world_size=1,
                            rank=0)
    #  torch.distributed.init_process_group(backend='nccl', init_method='env://', world_size=world_size, rank=rank)
    # user NCCL for GPU, use gloo for CPU
    torch.distributed.barrier()

    # set random seeds for reproducibility
    seed = config.SEED + dist.get_rank()
    seed = args.seed
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if args.ngpu > 0:
        torch.cuda.manual_seed_all(args.seed)
    # enable CuDNN benchmark mode to speed up training
    cudnn.benchmark = True

    # adjust the learning rate based on the global distributed batch size and gradient-accumulation steps
    linear_scaled_lr = config.TRAIN.BASE_LR * config.DATA.BATCH_SIZE * dist.get_world_size() / 512.0
    linear_scaled_warmup_lr = config.TRAIN.WARMUP_LR * config.DATA.BATCH_SIZE * dist.get_world_size() / 512.0
    linear_scaled_min_lr = config.TRAIN.MIN_LR * config.DATA.BATCH_SIZE * dist.get_world_size() / 512.0
    if config.TRAIN.ACCUMULATION_STEPS > 1:
        linear_scaled_lr = linear_scaled_lr * config.TRAIN.ACCUMULATION_STEPS
        linear_scaled_warmup_lr = linear_scaled_warmup_lr * config.TRAIN.ACCUMULATION_STEPS
        linear_scaled_min_lr = linear_scaled_min_lr * config.TRAIN.ACCUMULATION_STEPS
    config.defrost()
    config.TRAIN.BASE_LR = linear_scaled_lr
    print(f"==============> TRAIN.BASE_LR{config.TRAIN.BASE_LR}....................")
    config.TRAIN.WARMUP_LR = linear_scaled_warmup_lr
    config.TRAIN.MIN_LR = linear_scaled_min_lr
    config.freeze()

    # create the output directory
    os.makedirs(config.OUTPUT, exist_ok=True)
    # create the logger
    logger = create_logger(output_dir=config.OUTPUT, dist_rank=dist.get_rank(), name=f"{config.MODEL.NAME}")

    # save the configuration file if the current process is the main process
    if dist.get_rank() == 0:
        path = os.path.join(config.OUTPUT, "config.json")
        with open(path, "w") as f:
            f.write(config.dump())
        logger.info(f"Full config saved to {path}")

    # print configuration information
    logger.info(config.dump())
    logger.info(json.dumps(vars(args)))

    # call the main function to start training
    # main(config)
    myMain(config, args)

