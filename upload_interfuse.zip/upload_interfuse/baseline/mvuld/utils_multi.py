import os
import torch
import torch.distributed as dist
import math
inf = math.inf
# from torch._six import inf


def load_checkpoint(config, model, optimizer, lr_scheduler, loss_scaler, logger):
    # log that the model state is being restored from the specified checkpoint
    logger.info(f"==============> Resuming form {config.MODEL.MULTI.RESUME}....................")

    # if the checkpoint path starts with 'https', load the state dictionary from the URL
    if config.MODEL.MULTI.RESUME.startswith('https'):
        checkpoint = torch.hub.load_state_dict_from_url(
            config.MODEL.MULTI.RESUME, map_location='cpu', check_hash=True)
    # otherwise, load the checkpoint directly from the file path
    else:
        checkpoint = torch.load(config.MODEL.MULTI.RESUME, map_location='cpu')

    # try to load the checkpoint model state into the current model while ignoring mismatched keys
    msg = model.load_state_dict(checkpoint['model'], strict=False)

    # log that the model state from the checkpoint was loaded successfully
    # logger.info(msg)

    # initialize a variable to store the highest accuracy
    max_accuracy = 0.0

    # get the current training epoch from the checkpoint
    epoch = checkpoint['epoch']

    # if not in evaluation mode and the checkpoint contains optimizer, scheduler, and epoch information, load those states
    if not config.EVAL_MODE and 'optimizer' in checkpoint and 'lr_scheduler' in checkpoint and 'epoch' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer'])
        lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
        # defrost the configuration to update the starting epoch
        config.defrost()
        config.TRAIN.START_EPOCH = checkpoint['epoch'] + 1
        config.freeze()
        # load the gradient-scaler state if it is present in the checkpoint
        if 'scaler' in checkpoint:
            loss_scaler.load_state_dict(checkpoint['scaler'])
        # log that the checkpoint was loaded successfully
        logger.info(f"=> loaded successfully '{config.MODEL.MULTI.RESUME}' (epoch {checkpoint['epoch']})")
        # update max_accuracy if the checkpoint contains a maximum-accuracy value
        if 'max_accuracy' in checkpoint:
            max_accuracy = checkpoint['max_accuracy']

    # delete the loaded checkpoint to free memory
    del checkpoint

    # clear the CUDA cache
    torch.cuda.empty_cache()

    # return the highest accuracy and current epoch
    return max_accuracy, epoch


# load_pretrain
def load_pretrained(config, model, logger):
    # log that pretrained weights are being loaded for fine-tuning
    logger.info(f"==============> Loading weight {config.MODEL.PRETRAINED} for fine-tuning......")

    # load the pretrained model weight file
    checkpoint = torch.load(config.MODEL.PRETRAINED, map_location='cpu')

    # extract the model state dictionary from the loaded checkpoint
    state_dict = checkpoint['model']

    # remove 'relative_position_index' keys because these values are recomputed at each initialization
    relative_position_index_keys = [k for k in state_dict.keys() if "relative_position_index" in k]
    for k in relative_position_index_keys:
        del state_dict[k]

    # remove 'relative_coords_table' keys because these values are recomputed at each initialization
    relative_position_index_keys = [k for k in state_dict.keys() if "relative_coords_table" in k]
    for k in relative_position_index_keys:
        del state_dict[k]

    # remove 'attn_mask' keys because these values are recomputed at each initialization
    attn_mask_keys = [k for k in state_dict.keys() if "attn_mask" in k]
    for k in attn_mask_keys:
        del state_dict[k]

    # if the 'relative_position_bias_table' size does not match, resize it with bicubic interpolation
    relative_position_bias_table_keys = [k for k in state_dict.keys() if "relative_position_bias_table" in k]
    for k in relative_position_bias_table_keys:
        relative_position_bias_table_pretrained = state_dict[k]
        relative_position_bias_table_current = model.state_dict()[k]
        L1, nH1 = relative_position_bias_table_pretrained.size()
        L2, nH2 = relative_position_bias_table_current.size()
        if nH1 != nH2:
            logger.warning(f"Error in loading {k}, passing......")
        else:
            if L1 != L2:
                # resize 'relative_position_bias_table' with bicubic interpolation
                S1 = int(L1 ** 0.5)
                S2 = int(L2 ** 0.5)
                relative_position_bias_table_pretrained_resized = torch.nn.functional.interpolate(
                    relative_position_bias_table_pretrained.permute(1, 0).view(1, nH1, S1, S1), size=(S2, S2),
                    mode='bicubic')
                state_dict[k] = relative_position_bias_table_pretrained_resized.view(nH2, L2).permute(1, 0)

    # if the 'absolute_pos_embed' size does not match, resize it with bicubic interpolation
    absolute_pos_embed_keys = [k for k in state_dict.keys() if "absolute_pos_embed" in k]
    for k in absolute_pos_embed_keys:
        absolute_pos_embed_pretrained = state_dict[k]
        absolute_pos_embed_current = model.state_dict()[k]
        _, L1, C1 = absolute_pos_embed_pretrained.size()
        _, L2, C2 = absolute_pos_embed_current.size()
        if C1 != C1:
            logger.warning(f"Error in loading {k}, passing......")
        else:
            if L1 != L2:
                # resize 'absolute_pos_embed' with bicubic interpolation
                S1 = int(L1 ** 0.5)
                S2 = int(L2 ** 0.5)
                absolute_pos_embed_pretrained = absolute_pos_embed_pretrained.reshape(-1, S1, S1, C1)
                absolute_pos_embed_pretrained = absolute_pos_embed_pretrained.permute(0, 3, 1, 2)
                absolute_pos_embed_pretrained_resized = torch.nn.functional.interpolate(
                    absolute_pos_embed_pretrained, size=(S2, S2), mode='bicubic')
                absolute_pos_embed_pretrained_resized = absolute_pos_embed_pretrained_resized.permute(0, 2, 3, 1)
                absolute_pos_embed_pretrained_resized = absolute_pos_embed_pretrained_resized.flatten(1, 2)
                state_dict[k] = absolute_pos_embed_pretrained_resized

    # check whether the classifier-head dimensions match; reinitialize to zero if they do not
    head_bias_pretrained = state_dict['head.bias']
    Nc1 = head_bias_pretrained.shape[0]
    Nc2 = model.head.bias.shape[0]
    if (Nc1 != Nc2):
        if Nc1 == 21841 and Nc2 == 1000:
            logger.info("loading ImageNet-22K weight to ImageNet-1K ......")
            map22kto1k_path = f'data/map22kto1k.txt'
            with open(map22kto1k_path) as f:
                map22kto1k = f.readlines()
            map22kto1k = [int(id22k.strip()) for id22k in map22kto1k]
            state_dict['head.weight'] = state_dict['head.weight'][map22kto1k, :]
            state_dict['head.bias'] = state_dict['head.bias'][map22kto1k]
        else:
            torch.nn.init.constant_(model.head.bias, 0.)
            torch.nn.init.constant_(model.head.weight, 0.)
            del state_dict['head.weight']
            del state_dict['head.bias']
            logger.warning(f"Error in loading classifier head, re-init classifier head to 0")

    # try to load the adjusted state dictionary into the model while ignoring mismatched keys
    msg = model.load_state_dict(state_dict, strict=False)
    logger.warning(msg)

    # log that pretrained weights were loaded successfully
    logger.info(f"=> loaded successfully '{config.MODEL.PRETRAINED}'")

    # delete the loaded checkpoint to free memory
    del checkpoint

    # clear the CUDA cache
    torch.cuda.empty_cache()


def save_checkpoint(config, epoch, model, max_accuracy, optimizer, lr_scheduler, loss_scaler, logger):
    # create a dictionary holding the current model state
    save_state = {
        'model': model.state_dict(),  # model state dictionary containing weights and biases for all layers
        'optimizer': optimizer.state_dict(),  # optimizer state dictionary containing its internal state
        'lr_scheduler': lr_scheduler.state_dict(),  # learning-rate scheduler state dictionary containing its internal state
        'max_accuracy': max_accuracy,  # highest accuracy achieved so far
        'scaler': loss_scaler.state_dict(),  # gradient-scaler state dictionary for mixed-precision training
        'epoch': epoch,  # current training epoch
        'config': config  # current configuration information for restoring the training environment
    }

    # build the path for saving the checkpoint file
    save_path = os.path.join(config.MULTI_OUTPUT, f'ckpt_epoch_{epoch}.pth')

    # log that the checkpoint file is being saved
    logger.info(f"{save_path} saving......")

    # save the current model state to the checkpoint file
    torch.save(save_state, save_path)

    # log that the checkpoint file was saved successfully
    logger.info(f"{save_path} saved !!!")


def save_bestf1_checkpoint(config, epoch, model, max_accuracy, optimizer, lr_scheduler, loss_scaler, logger):
    save_state = {'model': model.state_dict(),
                  'optimizer': optimizer.state_dict(),
                  'lr_scheduler': lr_scheduler.state_dict(),
                  'max_accuracy': max_accuracy,
                  'scaler': loss_scaler.state_dict(),
                  'epoch': epoch,
                  'config': config}

    save_path = os.path.join(config.MULTI_OUTPUT, 'checkpoint-best-f1', f'mymodel.pth')

    logger.info(f"{save_path} best f1 saving......")
    torch.save(save_state, save_path)
    logger.info(f"{save_path} best f1 saved !!!")


def resume_bestf1_helper(output_dir):
    output_dir = os.path.join(output_dir, 'checkpoint-best-f1')
    print(f"utils output dir:{output_dir}")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    checkpoints = os.listdir(output_dir)
    checkpoints = [ckpt for ckpt in checkpoints if ckpt.endswith('pth')]
    # print(f"All checkpoints founded in {output_dir}: {checkpoints}")
    if len(checkpoints) > 0:
        best_f1_checkpoint = max([os.path.join(output_dir, d) for d in checkpoints], key=os.path.getmtime)
        print(f"The best f1 checkpoint founded: {best_f1_checkpoint}")
        resume_file = best_f1_checkpoint
    else:
        resume_file = None
    return resume_file


def get_grad_norm(parameters, norm_type=2):
    # if the argument is a PyTorch tensor, convert it to a list of tensors
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]

    # filter parameters to those with non-null gradients
    parameters = list(filter(lambda p: p.grad is not None, parameters))

    # convert the norm type to a float
    norm_type = float(norm_type)

    # initialize the total norm to zero
    total_norm = 0

    # iterate over all parameters with gradients
    for p in parameters:
        # compute the gradient norm for each parameter
        param_norm = p.grad.data.norm(norm_type)
        # add each parameter gradient norm raised to norm_type to the total norm
        total_norm += param_norm.item() ** norm_type

    # take the norm_type root of the accumulated value to obtain the total norm
    total_norm = total_norm ** (1. / norm_type)

    # return the total norm
    return total_norm


def auto_resume_helper(output_dir):
    print(f"utils output dir:{output_dir}")
    checkpoints = os.listdir(output_dir)
    # output_dir = cconfig.MULTI_OUTPUT= os.path.join(config.MULTI_OUTPUT,config.MODEL.NAME, config.TAG)
    checkpoints = [ckpt for ckpt in checkpoints if ckpt.endswith('pth')]
    # print(f"All checkpoints founded in {output_dir}: {checkpoints}")
    if len(checkpoints) > 0:
        latest_checkpoint = max([os.path.join(output_dir, d) for d in checkpoints], key=os.path.getmtime)
        print(f"The latest checkpoint founded: {latest_checkpoint}")
        resume_file = latest_checkpoint
    else:
        resume_file = None
    return resume_file


def reduce_tensor(tensor):
    rt = tensor.clone()
    dist.all_reduce(rt, op=dist.ReduceOp.SUM)
    rt /= dist.get_world_size()
    return rt


def ampscaler_get_grad_norm(parameters, norm_type: float = 2.0) -> torch.Tensor:
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]
    parameters = [p for p in parameters if p.grad is not None]
    norm_type = float(norm_type)
    if len(parameters) == 0:
        return torch.tensor(0.)
    device = parameters[0].grad.device
    if norm_type == inf:
        total_norm = max(p.grad.detach().abs().max().to(device) for p in parameters)
    else:
        total_norm = torch.norm(torch.stack([torch.norm(p.grad.detach(),
                                                        norm_type).to(device) for p in parameters]), norm_type)
    return total_norm


class NativeScalerWithGradNormCount:
    # define a class for managing gradient scaling in mixed-precision training
    class AmpScaler:
        # define the state-dictionary key name
        state_dict_key = "amp_scaler"

        # initialize by creating a GradScaler instance
        def __init__(self):
            self._scaler = torch.cuda.amp.GradScaler()

        # define the callable method for forward pass, backward pass, and gradient update
        def __call__(self, loss, optimizer, clip_grad=None, parameters=None, create_graph=False, update_grad=True):
            # scale the loss with the gradient scaler and perform backpropagation
            self._scaler.scale(loss).backward(create_graph=create_graph)
            # if gradients should be updated
            if update_grad:
                # if gradient clipping is required
                if clip_grad is not None:
                    assert parameters is not None  # ensure the parameter list is not empty
                    # unscale the optimizer parameters
                    self._scaler.unscale_(optimizer)
                    # compute and clip the gradient norm
                    norm = torch.nn.utils.clip_grad_norm_(parameters, clip_grad)
                else:
                    # if no clipping value is specified, only compute the gradient norm
                    self._scaler.unscale_(optimizer)
                    norm = ampscaler_get_grad_norm(parameters)
                # use the gradient scaler to step the optimizer
                self._scaler.step(optimizer)
                # update the gradient-scaler state
                self._scaler.update()
            else:
                # if gradients are not updated, the norm is None
                norm = None
            # return the gradient norm
            return norm

        # define a method to get the gradient-scaler state dictionary
        def state_dict(self):
            return self._scaler.state_dict()

        # define a method to load the gradient-scaler state dictionary
        def load_state_dict(self, state_dict):
            self._scaler.load_state_dict(state_dict)



