import os
import torch
import torch.distributed as dist
import math
inf = math.inf
# from torch._six import inf


def load_checkpoint(config, model, optimizer, lr_scheduler, loss_scaler, logger):
    # 记录日志，表示正在从指定的检查点恢复模型状态
    logger.info(f"==============> Resuming form {config.MODEL.MULTI.RESUME}....................")

    # 如果检查点路径以'https'开头，则通过URL加载状态字典
    if config.MODEL.MULTI.RESUME.startswith('https'):
        checkpoint = torch.hub.load_state_dict_from_url(
            config.MODEL.MULTI.RESUME, map_location='cpu', check_hash=True)
    # 否则，直接从文件路径加载检查点
    else:
        checkpoint = torch.load(config.MODEL.MULTI.RESUME, map_location='cpu')

    # 尝试加载检查点中的模型状态字典到当前模型，忽略不匹配的键
    msg = model.load_state_dict(checkpoint['model'], strict=False)

    # 记录日志，表示检查点中的模型状态字典已成功加载
    # logger.info(msg)

    # 初始化变量以存储最高准确率
    max_accuracy = 0.0

    # 从检查点中获取当前的训练周期
    epoch = checkpoint['epoch']

    # 如果当前不是评估模式，并且检查点中包含优化器、学习率调度器和当前周期信息，则加载这些状态
    if not config.EVAL_MODE and 'optimizer' in checkpoint and 'lr_scheduler' in checkpoint and 'epoch' in checkpoint:
        optimizer.load_state_dict(checkpoint['optimizer'])
        lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
        # 解冻配置以更新训练起始周期
        config.defrost()
        config.TRAIN.START_EPOCH = checkpoint['epoch'] + 1
        config.freeze()
        # 如果检查点中包含梯度缩放器，则加载其状态
        if 'scaler' in checkpoint:
            loss_scaler.load_state_dict(checkpoint['scaler'])
        # 记录日志，表示检查点已成功加载
        logger.info(f"=> loaded successfully '{config.MODEL.MULTI.RESUME}' (epoch {checkpoint['epoch']})")
        # 如果检查点中包含最高准确率，则更新max_accuracy变量
        if 'max_accuracy' in checkpoint:
            max_accuracy = checkpoint['max_accuracy']

    # 删除加载的检查点以释放内存
    del checkpoint

    # 清空CUDA缓存
    torch.cuda.empty_cache()

    # 返回最高准确率和当前周期
    return max_accuracy, epoch


# load_pretrain
def load_pretrained(config, model, logger):
    # 记录日志，表示正在加载用于微调的预训练权重
    logger.info(f"==============> Loading weight {config.MODEL.PRETRAINED} for fine-tuning......")

    # 加载预训练模型的权重文件
    checkpoint = torch.load(config.MODEL.PRETRAINED, map_location='cpu')

    # 从加载的检查点中提取模型的状态字典
    state_dict = checkpoint['model']

    # 删除状态字典中的'relative_position_index'键，因为这些值在每次初始化时都会重新计算
    relative_position_index_keys = [k for k in state_dict.keys() if "relative_position_index" in k]
    for k in relative_position_index_keys:
        del state_dict[k]

    # 删除状态字典中的'relative_coords_table'键，因为这些值在每次初始化时都会重新计算
    relative_position_index_keys = [k for k in state_dict.keys() if "relative_coords_table" in k]
    for k in relative_position_index_keys:
        del state_dict[k]

    # 删除状态字典中的'attn_mask'键，因为这些值在每次初始化时都会重新计算
    attn_mask_keys = [k for k in state_dict.keys() if "attn_mask" in k]
    for k in attn_mask_keys:
        del state_dict[k]

    # 如果'relative_position_bias_table'的尺寸不匹配，使用双三次插值调整其尺寸
    relative_position_bias_table_keys = [k for k in state_dict.keys() if "relative_position_bias_table" in k]
    for k in relative_position_bias_table_keys:
        relative_position_bias_table_pretrained = state_dict[k]
        relative_position_bias_table_current = model.state_dict()[k]
        L1, nH1 = relative_position_bias_table_pretrained.size()
        L2, nH2 = relative_position_bias_table_current.size()
        if nH1 != nH2:
            logger.warning(f"Error in loading {k}, passing......")
        else:
            if L1 != L2:
                # 使用双三次插值调整'relative_position_bias_table'的尺寸
                S1 = int(L1 ** 0.5)
                S2 = int(L2 ** 0.5)
                relative_position_bias_table_pretrained_resized = torch.nn.functional.interpolate(
                    relative_position_bias_table_pretrained.permute(1, 0).view(1, nH1, S1, S1), size=(S2, S2),
                    mode='bicubic')
                state_dict[k] = relative_position_bias_table_pretrained_resized.view(nH2, L2).permute(1, 0)

    # 如果'absolute_pos_embed'的尺寸不匹配，使用双三次插值调整其尺寸
    absolute_pos_embed_keys = [k for k in state_dict.keys() if "absolute_pos_embed" in k]
    for k in absolute_pos_embed_keys:
        absolute_pos_embed_pretrained = state_dict[k]
        absolute_pos_embed_current = model.state_dict()[k]
        _, L1, C1 = absolute_pos_embed_pretrained.size()
        _, L2, C2 = absolute_pos_embed_current.size()
        if C1 != C1:
            logger.warning(f"Error in loading {k}, passing......")
        else:
            if L1 != L2:
                # 使用双三次插值调整'absolute_pos_embed'的尺寸
                S1 = int(L1 ** 0.5)
                S2 = int(L2 ** 0.5)
                absolute_pos_embed_pretrained = absolute_pos_embed_pretrained.reshape(-1, S1, S1, C1)
                absolute_pos_embed_pretrained = absolute_pos_embed_pretrained.permute(0, 3, 1, 2)
                absolute_pos_embed_pretrained_resized = torch.nn.functional.interpolate(
                    absolute_pos_embed_pretrained, size=(S2, S2), mode='bicubic')
                absolute_pos_embed_pretrained_resized = absolute_pos_embed_pretrained_resized.permute(0, 2, 3, 1)
                absolute_pos_embed_pretrained_resized = absolute_pos_embed_pretrained_resized.flatten(1, 2)
                state_dict[k] = absolute_pos_embed_pretrained_resized

    # 检查分类器头的尺寸是否匹配，如果不匹配，则重新初始化为零
    head_bias_pretrained = state_dict['head.bias']
    Nc1 = head_bias_pretrained.shape[0]
    Nc2 = model.head.bias.shape[0]
    if (Nc1 != Nc2):
        if Nc1 == 21841 and Nc2 == 1000:
            logger.info("loading ImageNet-22K weight to ImageNet-1K ......")
            map22kto1k_path = f'data/map22kto1k.txt'
            with open(map22kto1k_path) as f:
                map22kto1k = f.readlines()
            map22kto1k = [int(id22k.strip()) for id22k in map22kto1k]
            state_dict['head.weight'] = state_dict['head.weight'][map22kto1k, :]
            state_dict['head.bias'] = state_dict['head.bias'][map22kto1k]
        else:
            torch.nn.init.constant_(model.head.bias, 0.)
            torch.nn.init.constant_(model.head.weight, 0.)
            del state_dict['head.weight']
            del state_dict['head.bias']
            logger.warning(f"Error in loading classifier head, re-init classifier head to 0")

    # 尝试加载调整后的状态字典到模型中，忽略不匹配的键
    msg = model.load_state_dict(state_dict, strict=False)
    logger.warning(msg)

    # 记录日志，表示预训练权重已成功加载
    logger.info(f"=> loaded successfully '{config.MODEL.PRETRAINED}'")

    # 删除加载的检查点以释放内存
    del checkpoint

    # 清空CUDA缓存
    torch.cuda.empty_cache()


def save_checkpoint(config, epoch, model, max_accuracy, optimizer, lr_scheduler, loss_scaler, logger):
    # 创建一个字典来保存模型的当前状态
    save_state = {
        'model': model.state_dict(),  # 模型的状态字典，包含所有层的权重和偏置
        'optimizer': optimizer.state_dict(),  # 优化器的状态字典，包含优化器的内部状态
        'lr_scheduler': lr_scheduler.state_dict(),  # 学习率调度器的状态字典，包含学习率调度器的内部状态
        'max_accuracy': max_accuracy,  # 目前为止达到的最高准确率
        'scaler': loss_scaler.state_dict(),  # 梯度缩放器的状态字典，用于混合精度训练
        'epoch': epoch,  # 当前的训练周期
        'config': config  # 当前的配置信息，用于恢复训练环境
    }

    # 构建保存检查点文件的路径
    save_path = os.path.join(config.MULTI_OUTPUT, f'ckpt_epoch_{epoch}.pth')

    # 记录日志，表示正在保存检查点文件
    logger.info(f"{save_path} saving......")

    # 将模型的当前状态保存到检查点文件
    torch.save(save_state, save_path)

    # 记录日志，表示检查点文件已成功保存
    logger.info(f"{save_path} saved !!!")


def save_bestf1_checkpoint(config, epoch, model, max_accuracy, optimizer, lr_scheduler, loss_scaler, logger):
    save_state = {'model': model.state_dict(),
                  'optimizer': optimizer.state_dict(),
                  'lr_scheduler': lr_scheduler.state_dict(),
                  'max_accuracy': max_accuracy,
                  'scaler': loss_scaler.state_dict(),
                  'epoch': epoch,
                  'config': config}

    save_path = os.path.join(config.MULTI_OUTPUT, 'checkpoint-best-f1', f'mymodel.pth')

    logger.info(f"{save_path} best f1 saving......")
    torch.save(save_state, save_path)
    logger.info(f"{save_path} best f1 saved !!!")


def resume_bestf1_helper(output_dir):
    output_dir = os.path.join(output_dir, 'checkpoint-best-f1')
    print(f"utils output dir:{output_dir}")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    checkpoints = os.listdir(output_dir)
    checkpoints = [ckpt for ckpt in checkpoints if ckpt.endswith('pth')]
    # print(f"All checkpoints founded in {output_dir}: {checkpoints}")
    if len(checkpoints) > 0:
        best_f1_checkpoint = max([os.path.join(output_dir, d) for d in checkpoints], key=os.path.getmtime)
        print(f"The best f1 checkpoint founded: {best_f1_checkpoint}")
        resume_file = best_f1_checkpoint
    else:
        resume_file = None
    return resume_file


def get_grad_norm(parameters, norm_type=2):
    # 如果参数是一个PyTorch张量，将其转换为张量列表
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]

    # 过滤出那些具有非空梯度的参数
    parameters = list(filter(lambda p: p.grad is not None, parameters))

    # 将范数类型转换为浮点数
    norm_type = float(norm_type)

    # 初始化总范数为0
    total_norm = 0

    # 遍历所有具有梯度的参数
    for p in parameters:
        # 计算每个参数梯度的范数
        param_norm = p.grad.data.norm(norm_type)
        # 将每个参数梯度范数的norm_type次方加到总范数上
        total_norm += param_norm.item() ** norm_type

    # 计算所有参数梯度范数的norm_type次方根，得到总范数
    total_norm = total_norm ** (1. / norm_type)

    # 返回总范数
    return total_norm


def auto_resume_helper(output_dir):
    print(f"utils output dir:{output_dir}")
    checkpoints = os.listdir(output_dir)
    # output_dir = cconfig.MULTI_OUTPUT= os.path.join(config.MULTI_OUTPUT,config.MODEL.NAME, config.TAG)
    checkpoints = [ckpt for ckpt in checkpoints if ckpt.endswith('pth')]
    # print(f"All checkpoints founded in {output_dir}: {checkpoints}")
    if len(checkpoints) > 0:
        latest_checkpoint = max([os.path.join(output_dir, d) for d in checkpoints], key=os.path.getmtime)
        print(f"The latest checkpoint founded: {latest_checkpoint}")
        resume_file = latest_checkpoint
    else:
        resume_file = None
    return resume_file


def reduce_tensor(tensor):
    rt = tensor.clone()
    dist.all_reduce(rt, op=dist.ReduceOp.SUM)
    rt /= dist.get_world_size()
    return rt


def ampscaler_get_grad_norm(parameters, norm_type: float = 2.0) -> torch.Tensor:
    if isinstance(parameters, torch.Tensor):
        parameters = [parameters]
    parameters = [p for p in parameters if p.grad is not None]
    norm_type = float(norm_type)
    if len(parameters) == 0:
        return torch.tensor(0.)
    device = parameters[0].grad.device
    if norm_type == inf:
        total_norm = max(p.grad.detach().abs().max().to(device) for p in parameters)
    else:
        total_norm = torch.norm(torch.stack([torch.norm(p.grad.detach(),
                                                        norm_type).to(device) for p in parameters]), norm_type)
    return total_norm


class NativeScalerWithGradNormCount:
    # 定义一个类，用于管理混合精度训练中的梯度缩放
    class AmpScaler:
        # 定义状态字典的键名
        state_dict_key = "amp_scaler"

        # 初始化方法，创建一个GradScaler实例
        def __init__(self):
            self._scaler = torch.cuda.amp.GradScaler()

        # 定义类的调用方法，用于执行前向传播、反向传播和梯度更新
        def __call__(self, loss, optimizer, clip_grad=None, parameters=None, create_graph=False, update_grad=True):
            # 使用梯度缩放器缩放损失，并进行反向传播
            self._scaler.scale(loss).backward(create_graph=create_graph)
            # 如果需要更新梯度
            if update_grad:
                # 如果需要梯度裁剪
                if clip_grad is not None:
                    assert parameters is not None  # 确保参数列表不为空
                    # 对优化器的参数进行梯度缩放
                    self._scaler.unscale_(optimizer)
                    # 计算并裁剪梯度的范数
                    norm = torch.nn.utils.clip_grad_norm_(parameters, clip_grad)
                else:
                    # 如果没有指定裁剪值，则仅计算梯度的范数
                    self._scaler.unscale_(optimizer)
                    norm = ampscaler_get_grad_norm(parameters)
                # 使用梯度缩放器更新优化器的参数
                self._scaler.step(optimizer)
                # 更新梯度缩放器的状态
                self._scaler.update()
            else:
                # 如果不更新梯度，则范数为None
                norm = None
            # 返回梯度的范数
            return norm

        # 定义方法，用于获取梯度缩放器的状态字典
        def state_dict(self):
            return self._scaler.state_dict()

        # 定义方法，用于加载梯度缩放器的状态字典
        def load_state_dict(self, state_dict):
            self._scaler.load_state_dict(state_dict)



