# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors and The HuggingFace Inc. team.
# Copyright (c) 2018, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Fine-tuning the library models for language modeling on a text file (GPT, GPT-2, BERT, RoBERTa).
GPT and GPT-2 are fine-tuned using a causal language modeling (CLM) loss while BERT and RoBERTa are fine-tuned
using a masked language modeling (MLM) loss.
"""

# coding=utf-8
# import required libraries
from __future__ import absolute_import, division, print_function

import argparse  # for parsing command-line arguments
import logging  # for logging
import os  # for operating-system functions
import random  # provides random-number functions
import json  # for processing JSON-formatted data
import torch  # PyTorch deep-learning framework
import numpy as np  # NumPy for array operations
import pandas as pd  # Pandas for data processing

# set visible CUDA devices
os.environ["CUDA_VISIBLE_DEVICES"] = "1,0,2,3"
import torch
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler, TensorDataset
from utils.early_stopping import EarlyStopping  # import early stopping

# import model- and transformer-related utilities
from model import Model
from transformers import (WEIGHTS_NAME, get_linear_schedule_with_warmup,
                          RobertaConfig, RobertaModel, RobertaTokenizer)

from torch.optim import AdamW  # import the AdamW optimizer
from sklearn.metrics import (accuracy_score, recall_score, precision_score, 
                             f1_score, roc_auc_score, auc, average_precision_score)

# suppress warning messages
no_deprecation_warning = True
logger = logging.getLogger(__name__)  # create a logger
early_stopping = EarlyStopping()  # initialize early stopping

class InputFeatures(object):
    """stores features for a single training/test sample."""
    def __init__(self,
                 input_tokens,  # input token list
                 input_ids,  # input token-ID list
                 contrast_tokens,  # contrast-sample token list
                 contrast_ids,  # contrast-sample token-ID list
                 label,  # label
                 index  # index
    ):
        self.input_tokens = input_tokens
        self.input_ids = input_ids
        self.contrast_tokens = contrast_tokens
        self.contrast_ids = contrast_ids
        self.label = label
        self.index = index

def convert_examples_to_features(js, tokenizer, args):
    """convert an example to token IDs"""
    code = ' '.join(js['code'].split())  # remove redundant whitespace and join the code
    code_tokens = tokenizer.tokenize(code)[:args.block_size - 4]  # tokenize the code and limit its length
    # create input tokens and their IDs
    source_tokens = [tokenizer.cls_token, "<encoder_only>", tokenizer.sep_token] + code_tokens + [tokenizer.sep_token]
    source_ids = tokenizer.convert_tokens_to_ids(source_tokens)  # convert to IDs
    padding_length = args.block_size - len(source_ids)  # compute padding length
    source_ids += [tokenizer.pad_token_id] * padding_length  # add padding

    # process the contrast sample
    contrast = ' '.join(js['contrast'].split())  # remove redundant whitespace and join the contrast content
    contrast_tokens = tokenizer.tokenize(contrast)[:args.block_size - 4]  # tokenize the contrast sample
    contrast_tokens = [tokenizer.cls_token, "<encoder_only>", tokenizer.sep_token] + contrast_tokens + [tokenizer.sep_token]
    contrast_ids = tokenizer.convert_tokens_to_ids(contrast_tokens)  # convert to IDs
    padding_length = args.block_size - len(contrast_ids)  # compute padding length
    contrast_ids += [tokenizer.pad_token_id] * padding_length  # add padding
    
    return InputFeatures(source_tokens, source_ids,
                         contrast_tokens, contrast_ids,
                         js['label'], js['index'])  # return the feature object

class TextDataset(Dataset):
    def __init__(self, tokenizer, args, file_path=None):
        self.examples = []  # list storing samples
        data = []
        with open(file_path) as f:
            for line in f:
                line = line.strip()  # strip leading and trailing whitespace
                js = json.loads(line)  # convert the JSON line to a dictionary
                data.append(js)  # append to the data list
        for js in data:
            self.examples.append(convert_examples_to_features(js, tokenizer, args))  # convert to a feature object
        if 'train' in file_path:  # if this is a training-data file
            for idx, example in enumerate(self.examples[:3]):  # inspect only the first three samples
                logger.info("*** Example ***")
                logger.info("idx: {}".format(idx))
                logger.info("label: {}".format(example.label))
                logger.info("input_tokens: {}".format([x.replace('\u0120', '_') for x in example.input_tokens]))
                logger.info("input_ids: {}".format(' '.join(map(str, example.input_ids))))
        
    def __len__(self):
        return len(self.examples)  # return the number of samples

    def __getitem__(self, i):
        # return the input and label for sample i
        input_ids = self.examples[i].input_ids
        contrast_ids = self.examples[i].contrast_ids
        label = self.examples[i].label
        index = self.examples[i].index
        return (torch.tensor(input_ids), torch.tensor(contrast_ids),
                torch.tensor(label), torch.tensor(index))  # return tensor-form values

def set_seed(seed=42):
    random.seed(seed)  # set random seeds
    os.environ['PYHTONHASHSEED'] = str(seed)  # set the Python hash seed
    np.random.seed(seed)  # set the NumPy random seed
    torch.manual_seed(seed)  # set the PyTorch CPU random seed
    torch.cuda.manual_seed(seed)  # set the PyTorch GPU random seed
    torch.backends.cudnn.deterministic = True  # set CuDNN to deterministic mode

def train(args, train_dataset, model, tokenizer):
    """train the model"""
    train_sampler = SequentialSampler(train_dataset)  # use a sequential sampler
    train_dataloader = DataLoader(train_dataset, sampler=train_sampler, 
                                  batch_size=args.train_batch_size, 
                                  num_workers=4, pin_memory=True)  # create the data loader
    
    args.max_steps = args.num_train_epochs * len(train_dataloader)  # compute total steps

    # prepare the optimizer and learning-rate scheduler
    no_decay = ['bias', 'LayerNorm.weight']  # parameters excluded from weight decay
    optimizer_grouped_parameters = [
        {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': args.weight_decay},  # weight decay
        {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}  # no decay
    ]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)  # initialize the AdamW optimizer
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=args.max_steps*0.1,
                                                num_training_steps=args.max_steps)  # learning-rate scheduler

    # start training
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_dataset))
    logger.info("  Num Epochs = %d", args.num_train_epochs)
    logger.info("  Instantaneous batch size per GPU = %d", args.train_batch_size // args.n_gpu)
    logger.info("  Total train batch size = %d", args.train_batch_size)
    logger.info("  Total optimization steps = %d", args.max_steps)

    losses, best_f1 = [], 0  # initialize the loss list and best F1 score
    model.zero_grad()  # clear gradients
    for idx in range(args.num_train_epochs):  # iterate over each training epoch
        for step, batch in enumerate(train_dataloader):  # iterate over each batch
            inputs = batch[0].to(args.device)  # get input IDs
            contrasts = batch[1].to(args.device)  # get contrast IDs
            labels = batch[2].to(args.device)  # get labels
            
            model.train()  # set the model to training mode
            loss, _, = model(inputs, contrasts, labels)  # compute the loss in the forward pass

            if args.n_gpu > 1:
                loss = loss.mean()  # average the loss across multiple GPUs
                
            loss.backward()  # backpropagation
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)  # gradient clipping

            losses.append(loss.item())  # record the loss

            if (step + 1) % 100 == 0:  # print the loss every 100 steps
                logger.info("epoch {} step {} loss {}".format(idx, step + 1, round(np.mean(losses[-100:]), 4)))

            optimizer.step()  # update parameters
            optimizer.zero_grad()  # clear gradients
            scheduler.step()  # update the learning rate

        # evaluate the model
        results, eval_loss = evaluate(args, model, tokenizer, args.eval_data_file)
        
        # save the model if the current F1 score is better
        if results['f1'] > best_f1:
            best_f1 = results['f1']
            logger.info("  "+"*"*20)  
            logger.info("  Best f1:%s", round(best_f1, 4))
            logger.info("  "+"*"*20)                          

            checkpoint_prefix = 'checkpoint-best-f1'
            output_dir = os.path.join(args.output_dir, '{}'.format(checkpoint_prefix))                        
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)                        
            output_dir = os.path.join(output_dir, 'model.bin')
            model_to_save = model.module if hasattr(model, 'module') else model
            torch.save(model_to_save.state_dict(), output_dir)  # save model state
            logger.info("Saving model checkpoint to %s", output_dir)

        early_stopping(eval_loss)  # check whether early stopping is needed
        if early_stopping.early_stop:  # if early stopping is triggered
            print("Early stopping")
            break  # exit training

def evaluate(args, model, tokenizer, data_file):
    """evaluate the model"""
    eval_dataset = TextDataset(tokenizer, args, data_file)  # create the evaluation dataset
    eval_sampler = SequentialSampler(eval_dataset)  # use a sequential sampler
    eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler,
                                batch_size=args.eval_batch_size, num_workers=4)  # create the evaluation data loader

    # start evaluation
    logger.info("***** Running evaluation *****")
    logger.info("  Num examples = %d", len(eval_dataset))
    logger.info("  Batch size = %d", args.eval_batch_size)

    eval_loss = 0.0  # initialize evaluation loss
    nb_eval_steps = 0  # initialize the evaluation-step counter
    model.eval()  # set the model to evaluation mode
    logits = []  # store output logits
    labels = []  # store ground-truth labels
    for batch in eval_dataloader:  # iterate over evaluation data
        input = batch[0].to(args.device) 
        contrast = batch[1].to(args.device)
        label = batch[2].to(args.device)
        with torch.no_grad():  # perform the forward pass without gradient computation
            lm_loss, logit = model(input, contrast, label)  # compute loss and logits
            eval_loss += lm_loss.mean().item()  # accumulate the loss
            logits.append(logit.cpu().numpy())  # append logits to the list
            labels.append(label.cpu().numpy())  # append labels to the list
        nb_eval_steps += 1  # increment the evaluation-step counter

    # concatenate all logits and labels
    logits = np.concatenate(logits, 0)
    labels = np.concatenate(labels, 0)
    preds = logits[:, 1] > 0.5  # obtain predictions using the threshold
    
    # compute evaluation metrics
    acc = accuracy_score(labels, preds)
    recall = recall_score(labels, preds)
    precision = precision_score(labels, preds)
    f1 = f1_score(labels, preds)
    pr_auc = average_precision_score(labels, logits[:, 1])
    roc_auc = roc_auc_score(labels, logits[:, 1])

    # return evaluation results and total loss
    results = {
        "acc": float(acc),
        "recall": float(recall),
        "precision": float(precision),
        "f1": float(f1),
        "pr_auc": float(pr_auc),
        "roc_auc": float(roc_auc)
    }
    return results, eval_loss

def detect(args, model, tokenizer, data_file):
    """run detection"""
    detect_dataset = TextDataset(tokenizer, args, data_file)  # create the detection dataset
    detect_sampler = SequentialSampler(detect_dataset)  # use a sequential sampler
    detect_dataloader = DataLoader(detect_dataset, sampler=detect_sampler,
                                batch_size=args.eval_batch_size, num_workers=4)  # create the detection data loader
    
    eval_output_dir = args.output_dir  # output directory
    if not os.path.exists(eval_output_dir):
        os.makedirs(eval_output_dir)  # create the output directory

    # start detection
    logger.info("***** Running detect *****")
    logger.info("  Num examples = %d", len(detect_dataset))
    logger.info("  Batch size = %d", args.eval_batch_size)

    nb_eval_steps = 0  # initialize the evaluation-step counter
    model.eval()  # set the model to evaluation mode
    logits = []  # store output logits
    labels = []  # store ground-truth labels
    indices = []  # store indices
    for batch in detect_dataloader:  # iterate over detection data
        contrast = batch[1].to(args.device)
        label = batch[2].to(args.device)
        index = batch[3].to(args.device)
        with torch.no_grad():  # perform the forward pass without gradient computation
            _, logit = model(contrast, None, label)  # compute logits
            logits.append(logit.cpu().numpy())  # append logits to the list
            labels.append(label.cpu().numpy())  # append labels to the list
            indices.append(index.cpu().numpy())  # append indices to the list
        nb_eval_steps += 1  # increment the evaluation-step counter

    # concatenate all logits, labels, and indices
    logits = np.concatenate(logits, 0)
    labels = np.concatenate(labels, 0)
    indices = np.concatenate(indices, 0)
    preds = logits[:, 1] > 0.5  # obtain predictions using the threshold
    
    # compute accuracy
    acc = accuracy_score(labels, preds)
    results = {
        "acc": float(acc)
    }
    return results, indices, preds  # return results, indices, and predictions

def main():
    parser = argparse.ArgumentParser()  # create the argument parser

    # required arguments
    parser.add_argument("--output_dir", default=None, type=str, required=True,
                        help="模型预测和检查点的输出目录。")

    # other arguments
    parser.add_argument("--train_data_file", default=None, type=str,
                        help="输入训练数据文件（jsonl格式）。")    
    parser.add_argument("--eval_data_file", default=None, type=str,
                        help="可选的输入评估数据文件（jsonl格式）。")
    parser.add_argument("--test_data_file", default=None, type=str,
                        help="可选的输入测试数据文件（jsonl格式）。")
    parser.add_argument("--model_name_or_path", default=None, type=str,
                        help="用于权重初始化的模型检查点。")

    parser.add_argument("--block_size", default=-1, type=int,
                        help="标记化后的可选输入序列长度。")
    parser.add_argument("--do_train", action='store_true',
                        help="是否进行训练。")
    parser.add_argument("--do_test", action='store_true',
                        help="是否在开发集上进行测试。")     
    parser.add_argument("--do_detect", action='store_true',
                        help="是否在开发集上进行检测。")       
    parser.add_argument("--train_batch_size", default=4, type=int,
                        help="每个GPU/CPU的训练批量大小。")
    parser.add_argument("--eval_batch_size", default=4, type=int,
                        help="每个GPU/CPU的评估批量大小。")
    parser.add_argument("--learning_rate", default=5e-5, type=float,
                        help="Adam优化器的初始学习率。")
    parser.add_argument("--weight_decay", default=0.0, type=float,
                        help="如果应用则为权重衰减。")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Adam优化器的epsilon值。")
    parser.add_argument("--max_grad_norm", default=1.0, type=float,
                        help="最大梯度范数。")
    parser.add_argument("--num_train_epochs", default=1, type=int,
                        help="执行的训练周期总数。")
    parser.add_argument('--seed', type=int, default=42,
                        help="初始化随机种子")
    parser.add_argument('--simcse', action='store_true',
                        help="用于SimCSE的参数")
    parser.add_argument('--simct', action='store_true',
                        help="用于SimCT的参数")
    parser.add_argument('--r_drop', action='store_true',
                        help="用于R-Drop的参数")
    parser.add_argument('--sigma', type=float, default=0.2,
                        help="用于R-Drop的sigma值")                  

    # parse arguments
    args = parser.parse_args()
    args.output_dir = '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/saved_models/r_drop'
    args.model_name_or_path = '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/microsoft/unixcoder-base-nine'
    args.train_data_file ='/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/Source_Code/dataset/train.jsonl'
    args.eval_data_file = '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/Source_Code/dataset/valid.jsonl'
    args.num_train_epochs = 20
    args.block_size=400

    args.train_batch_size=32

    args.eval_batch_size = 32
    args.learning_rate = 2e-5
    args.max_grad_norm = 1.0
    args.seed= 99

    # configure logging
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S', level=logging.INFO )
    
    # set the device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # check whether CUDA is available
    args.n_gpu = torch.cuda.device_count()  # get the number of GPUs
    args.device = device  # store device information in args
    logger.info("device: %s, n_gpu: %s", device, args.n_gpu)  # print device information
    
    # set random seeds
    set_seed(args.seed)
    
    # build the model
    tokenizer = RobertaTokenizer.from_pretrained(args.model_name_or_path)  # load the tokenizer
    config = RobertaConfig.from_pretrained(args.model_name_or_path)  # load the model configuration
    model = RobertaModel.from_pretrained(args.model_name_or_path)  # load the pretrained model

    model = Model(model, config, tokenizer, args)  # wrap the model
    logger.info("Training/evaluation parameters %s", args)  # print parameter information

    model.to(args.device)  # move the model to the specified device
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)  # use DataParallel for parallel training when multiple GPUs are available
            
    # training 
    if args.do_train:
        train_dataset = TextDataset(tokenizer, args, args.train_data_file)  # create the training dataset
        train(args, train_dataset, model, tokenizer)  # start training
        
    # testing 
    if args.do_test:
        checkpoint_prefix = 'checkpoint-best-f1/model.bin'  # set the checkpoint filename
        output_dir = os.path.join(args.output_dir, '{}'.format(checkpoint_prefix))  
        model_to_load = model.module if hasattr(model, 'module') else model  # get the model
        model_to_load.load_state_dict(torch.load(output_dir))  # load model state 
        result, _ = evaluate(args, model, tokenizer, args.test_data_file)  # evaluate
        logger.info("***** Test results *****")
        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(round(result[key] * 100 if "map" in key else result[key], 4)))       
    
    # detect
    if args.do_detect:
        checkpoint_prefix = 'checkpoint-best-f1/model.bin'  # set the checkpoint filename
        output_dir = os.path.join(args.output_dir, '{}'.format(checkpoint_prefix))  
        model_to_load = model.module if hasattr(model, 'module') else model  # get the model
        model_to_load.load_state_dict(torch.load(output_dir))  # load model state 
        result, indices, preds = detect(args, model, tokenizer, args.test_data_file)  # detect
        logger.info("***** Detect results *****")
        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(round(result[key] * 100 if "map" in key else result[key], 4)))
        dataframe = pd.DataFrame({"index": indices, "pred": preds})  # create a DataFrame
        dataframe.to_csv(f'{args.output_dir.replace("saved_models", "detect")}.csv', sep=',', index=False)  # save results to a CSV file

if __name__ == "__main__":
    main()  # call the main function

