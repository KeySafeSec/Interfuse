# coding=utf-8
# Copyright 2018 The Google AI Language Team Authors and The HuggingFace Inc. team.
# Copyright (c) 2018, NVIDIA CORPORATION.  All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
Fine-tuning the library models for language modeling on a text file (GPT, GPT-2, BERT, RoBERTa).
GPT and GPT-2 are fine-tuned using a causal language modeling (CLM) loss while BERT and RoBERTa are fine-tuned
using a masked language modeling (MLM) loss.
"""

# coding=utf-8
# 引入必要的库
from __future__ import absolute_import, division, print_function

import argparse  # 用于解析命令行参数
import logging  # 用于日志记录
import os  # 用于操作系统功能
import random  # 提供随机数函数
import json  # 用于处理JSON格式数据
import torch  # PyTorch深度学习框架
import numpy as np  # NumPy库用于数组运算
import pandas as pd  # Pandas库用于数据处理

# 设置可见的CUDA设备
os.environ["CUDA_VISIBLE_DEVICES"] = "1,0,2,3"
import torch
from torch.utils.data import DataLoader, Dataset, SequentialSampler, RandomSampler, TensorDataset
from utils.early_stopping import EarlyStopping  # 导入早停机制

# 导入模型和变换器相关的工具
from model import Model
from transformers import (WEIGHTS_NAME, get_linear_schedule_with_warmup,
                          RobertaConfig, RobertaModel, RobertaTokenizer)

from torch.optim import AdamW  # 导入AdamW优化器
from sklearn.metrics import (accuracy_score, recall_score, precision_score, 
                             f1_score, roc_auc_score, auc, average_precision_score)

# 设置不显示的警告信息
no_deprecation_warning = True
logger = logging.getLogger(__name__)  # 创建一个日志记录器
early_stopping = EarlyStopping()  # 初始化早停机制

class InputFeatures(object):
    """用于存储单个训练/测试样本的特征。"""
    def __init__(self,
                 input_tokens,  # 输入的token列表
                 input_ids,  # 输入的token ID列表
                 contrast_tokens,  # 对比样本的token列表
                 contrast_ids,  # 对比样本的token ID列表
                 label,  # 标签
                 index  # 索引
    ):
        self.input_tokens = input_tokens
        self.input_ids = input_ids
        self.contrast_tokens = contrast_tokens
        self.contrast_ids = contrast_ids
        self.label = label
        self.index = index

def convert_examples_to_features(js, tokenizer, args):
    """将示例转换为token ID"""
    code = ' '.join(js['code'].split())  # 清除多余空格并拼接代码
    code_tokens = tokenizer.tokenize(code)[:args.block_size - 4]  # Tokenize代码，限制大小
    # 创建输入tokens及其ID
    source_tokens = [tokenizer.cls_token, "<encoder_only>", tokenizer.sep_token] + code_tokens + [tokenizer.sep_token]
    source_ids = tokenizer.convert_tokens_to_ids(source_tokens)  # 转换为ID
    padding_length = args.block_size - len(source_ids)  # 计算填充长度
    source_ids += [tokenizer.pad_token_id] * padding_length  # 添加填充

    # 处理对比样本
    contrast = ' '.join(js['contrast'].split())  # 清除多余空格并拼接对比内容
    contrast_tokens = tokenizer.tokenize(contrast)[:args.block_size - 4]  # Tokenize对比样本
    contrast_tokens = [tokenizer.cls_token, "<encoder_only>", tokenizer.sep_token] + contrast_tokens + [tokenizer.sep_token]
    contrast_ids = tokenizer.convert_tokens_to_ids(contrast_tokens)  # 转换为ID
    padding_length = args.block_size - len(contrast_ids)  # 计算填充长度
    contrast_ids += [tokenizer.pad_token_id] * padding_length  # 添加填充
    
    return InputFeatures(source_tokens, source_ids,
                         contrast_tokens, contrast_ids,
                         js['label'], js['index'])  # 返回特征对象

class TextDataset(Dataset):
    def __init__(self, tokenizer, args, file_path=None):
        self.examples = []  # 存储样本的列表
        data = []
        with open(file_path) as f:
            for line in f:
                line = line.strip()  # 去除行首尾空格
                js = json.loads(line)  # 将JSON格式的行转为字典
                data.append(js)  # 添加到数据列表
        for js in data:
            self.examples.append(convert_examples_to_features(js, tokenizer, args))  # 转换为特征对象
        if 'train' in file_path:  # 如果是训练数据文件
            for idx, example in enumerate(self.examples[:3]):  # 只查看前3个样本
                logger.info("*** Example ***")
                logger.info("idx: {}".format(idx))
                logger.info("label: {}".format(example.label))
                logger.info("input_tokens: {}".format([x.replace('\u0120', '_') for x in example.input_tokens]))
                logger.info("input_ids: {}".format(' '.join(map(str, example.input_ids))))
        
    def __len__(self):
        return len(self.examples)  # 返回样本数

    def __getitem__(self, i):
        # 返回第i个样本的输入和标签
        input_ids = self.examples[i].input_ids
        contrast_ids = self.examples[i].contrast_ids
        label = self.examples[i].label
        index = self.examples[i].index
        return (torch.tensor(input_ids), torch.tensor(contrast_ids),
                torch.tensor(label), torch.tensor(index))  # 返回tensor格式

def set_seed(seed=42):
    random.seed(seed)  # 设置随机种子
    os.environ['PYHTONHASHSEED'] = str(seed)  # 设置Python哈希种子
    np.random.seed(seed)  # 设置NumPy随机种子
    torch.manual_seed(seed)  # 设置PyTorch CPU随机种子
    torch.cuda.manual_seed(seed)  # 设置PyTorch GPU随机种子
    torch.backends.cudnn.deterministic = True  # 设置CuDNN为确定模式

def train(args, train_dataset, model, tokenizer):
    """训练模型"""
    train_sampler = SequentialSampler(train_dataset)  # 使用顺序采样器
    train_dataloader = DataLoader(train_dataset, sampler=train_sampler, 
                                  batch_size=args.train_batch_size, 
                                  num_workers=4, pin_memory=True)  # 创建数据加载器
    
    args.max_steps = args.num_train_epochs * len(train_dataloader)  # 计算总步数

    # 准备优化器和学习率调度器
    no_decay = ['bias', 'LayerNorm.weight']  # 不做权重衰减的参数
    optimizer_grouped_parameters = [
        {'params': [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': args.weight_decay},  # 权重衰减
        {'params': [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)], 'weight_decay': 0.0}  # 不衰减
    ]
    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)  # 初始化AdamW优化器
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=args.max_steps*0.1,
                                                num_training_steps=args.max_steps)  # 学习率调度器

    # 开始训练
    logger.info("***** Running training *****")
    logger.info("  Num examples = %d", len(train_dataset))
    logger.info("  Num Epochs = %d", args.num_train_epochs)
    logger.info("  Instantaneous batch size per GPU = %d", args.train_batch_size // args.n_gpu)
    logger.info("  Total train batch size = %d", args.train_batch_size)
    logger.info("  Total optimization steps = %d", args.max_steps)

    losses, best_f1 = [], 0  # 初始化损失和最佳F1分数
    model.zero_grad()  # 清空梯度
    for idx in range(args.num_train_epochs):  # 遍历每个训练周期
        for step, batch in enumerate(train_dataloader):  # 遍历每个批次
            inputs = batch[0].to(args.device)  # 获取输入ID
            contrasts = batch[1].to(args.device)  # 获取对比ID
            labels = batch[2].to(args.device)  # 获取标签
            
            model.train()  # 设置模型为训练模式
            loss, _, = model(inputs, contrasts, labels)  # 前向传播计算损失

            if args.n_gpu > 1:
                loss = loss.mean()  # 在多GPU上取平均损失
                
            loss.backward()  # 反向传播
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)  # 梯度裁剪

            losses.append(loss.item())  # 记录损失

            if (step + 1) % 100 == 0:  # 每100步打印一次损失
                logger.info("epoch {} step {} loss {}".format(idx, step + 1, round(np.mean(losses[-100:]), 4)))

            optimizer.step()  # 更新参数
            optimizer.zero_grad()  # 清空梯度
            scheduler.step()  # 更新学习率

        # 评估模型
        results, eval_loss = evaluate(args, model, tokenizer, args.eval_data_file)
        
        # 如果当前F1分数更好，则保存模型
        if results['f1'] > best_f1:
            best_f1 = results['f1']
            logger.info("  "+"*"*20)  
            logger.info("  Best f1:%s", round(best_f1, 4))
            logger.info("  "+"*"*20)                          

            checkpoint_prefix = 'checkpoint-best-f1'
            output_dir = os.path.join(args.output_dir, '{}'.format(checkpoint_prefix))                        
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)                        
            output_dir = os.path.join(output_dir, 'model.bin')
            model_to_save = model.module if hasattr(model, 'module') else model
            torch.save(model_to_save.state_dict(), output_dir)  # 保存模型状态
            logger.info("Saving model checkpoint to %s", output_dir)

        early_stopping(eval_loss)  # 检查是否需要早停
        if early_stopping.early_stop:  # 如果需要早停
            print("Early stopping")
            break  # 退出训练

def evaluate(args, model, tokenizer, data_file):
    """评估模型"""
    eval_dataset = TextDataset(tokenizer, args, data_file)  # 创建评估数据集
    eval_sampler = SequentialSampler(eval_dataset)  # 使用顺序采样器
    eval_dataloader = DataLoader(eval_dataset, sampler=eval_sampler,
                                batch_size=args.eval_batch_size, num_workers=4)  # 创建评估数据加载器

    # 开始评估
    logger.info("***** Running evaluation *****")
    logger.info("  Num examples = %d", len(eval_dataset))
    logger.info("  Batch size = %d", args.eval_batch_size)

    eval_loss = 0.0  # 初始化评估损失
    nb_eval_steps = 0  # 初始化评估步骤计数
    model.eval()  # 设置模型为评估模式
    logits = []  # 存储输出logits
    labels = []  # 存储真实标签
    for batch in eval_dataloader:  # 遍历评估数据
        input = batch[0].to(args.device) 
        contrast = batch[1].to(args.device)
        label = batch[2].to(args.device)
        with torch.no_grad():  # 在不计算梯度的情况下进行前向传播
            lm_loss, logit = model(input, contrast, label)  # 计算损失和logits
            eval_loss += lm_loss.mean().item()  # 累加损失
            logits.append(logit.cpu().numpy())  # 将logits添加到列表
            labels.append(label.cpu().numpy())  # 将标签添加到列表
        nb_eval_steps += 1  # 评估步骤计数加1

    # 合并所有logits和labels
    logits = np.concatenate(logits, 0)
    labels = np.concatenate(labels, 0)
    preds = logits[:, 1] > 0.5  # 根据阈值获取预测结果
    
    # 计算各类评估指标
    acc = accuracy_score(labels, preds)
    recall = recall_score(labels, preds)
    precision = precision_score(labels, preds)
    f1 = f1_score(labels, preds)
    pr_auc = average_precision_score(labels, logits[:, 1])
    roc_auc = roc_auc_score(labels, logits[:, 1])

    # 返回评估结果和总损失
    results = {
        "acc": float(acc),
        "recall": float(recall),
        "precision": float(precision),
        "f1": float(f1),
        "pr_auc": float(pr_auc),
        "roc_auc": float(roc_auc)
    }
    return results, eval_loss

def detect(args, model, tokenizer, data_file):
    """进行检测"""
    detect_dataset = TextDataset(tokenizer, args, data_file)  # 创建检测数据集
    detect_sampler = SequentialSampler(detect_dataset)  # 使用顺序采样器
    detect_dataloader = DataLoader(detect_dataset, sampler=detect_sampler,
                                batch_size=args.eval_batch_size, num_workers=4)  # 创建检测数据加载器
    
    eval_output_dir = args.output_dir  # 输出目录
    if not os.path.exists(eval_output_dir):
        os.makedirs(eval_output_dir)  # 创建输出目录

    # 开始检测
    logger.info("***** Running detect *****")
    logger.info("  Num examples = %d", len(detect_dataset))
    logger.info("  Batch size = %d", args.eval_batch_size)

    nb_eval_steps = 0  # 初始化评估步骤计数
    model.eval()  # 设置模型为评估模式
    logits = []  # 存储输出logits
    labels = []  # 存储真实标签
    indices = []  # 存储索引
    for batch in detect_dataloader:  # 遍历检测数据
        contrast = batch[1].to(args.device)
        label = batch[2].to(args.device)
        index = batch[3].to(args.device)
        with torch.no_grad():  # 在不计算梯度的情况下进行前向传播
            _, logit = model(contrast, None, label)  # 计算logits
            logits.append(logit.cpu().numpy())  # 将logits添加到列表
            labels.append(label.cpu().numpy())  # 将标签添加到列表
            indices.append(index.cpu().numpy())  # 将索引添加到列表
        nb_eval_steps += 1  # 评估步骤计数加1

    # 合并所有logits、labels和indices
    logits = np.concatenate(logits, 0)
    labels = np.concatenate(labels, 0)
    indices = np.concatenate(indices, 0)
    preds = logits[:, 1] > 0.5  # 根据阈值获取预测结果
    
    # 计算准确率
    acc = accuracy_score(labels, preds)
    results = {
        "acc": float(acc)
    }
    return results, indices, preds  # 返回结果、索引和预测

def main():
    parser = argparse.ArgumentParser()  # 创建参数解析器

    # 必选参数
    parser.add_argument("--output_dir", default=None, type=str, required=True,
                        help="模型预测和检查点的输出目录。")

    # 其他参数
    parser.add_argument("--train_data_file", default=None, type=str,
                        help="输入训练数据文件（jsonl格式）。")    
    parser.add_argument("--eval_data_file", default=None, type=str,
                        help="可选的输入评估数据文件（jsonl格式）。")
    parser.add_argument("--test_data_file", default=None, type=str,
                        help="可选的输入测试数据文件（jsonl格式）。")
    parser.add_argument("--model_name_or_path", default=None, type=str,
                        help="用于权重初始化的模型检查点。")

    parser.add_argument("--block_size", default=-1, type=int,
                        help="标记化后的可选输入序列长度。")
    parser.add_argument("--do_train", action='store_true',
                        help="是否进行训练。")
    parser.add_argument("--do_test", action='store_true',
                        help="是否在开发集上进行测试。")     
    parser.add_argument("--do_detect", action='store_true',
                        help="是否在开发集上进行检测。")       
    parser.add_argument("--train_batch_size", default=4, type=int,
                        help="每个GPU/CPU的训练批量大小。")
    parser.add_argument("--eval_batch_size", default=4, type=int,
                        help="每个GPU/CPU的评估批量大小。")
    parser.add_argument("--learning_rate", default=5e-5, type=float,
                        help="Adam优化器的初始学习率。")
    parser.add_argument("--weight_decay", default=0.0, type=float,
                        help="如果应用则为权重衰减。")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Adam优化器的epsilon值。")
    parser.add_argument("--max_grad_norm", default=1.0, type=float,
                        help="最大梯度范数。")
    parser.add_argument("--num_train_epochs", default=1, type=int,
                        help="执行的训练周期总数。")
    parser.add_argument('--seed', type=int, default=42,
                        help="初始化随机种子")
    parser.add_argument('--simcse', action='store_true',
                        help="用于SimCSE的参数")
    parser.add_argument('--simct', action='store_true',
                        help="用于SimCT的参数")
    parser.add_argument('--r_drop', action='store_true',
                        help="用于R-Drop的参数")
    parser.add_argument('--sigma', type=float, default=0.2,
                        help="用于R-Drop的sigma值")                  

    # 解析参数
    args = parser.parse_args()
    args.output_dir = '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/saved_models/r_drop'
    args.model_name_or_path = '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/microsoft/unixcoder-base-nine'
    args.train_data_file ='/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/Source_Code/dataset/train.jsonl'
    args.eval_data_file = '/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/procedure/proc/SVulD/SVulD-master/Source_Code/dataset/valid.jsonl'
    args.num_train_epochs = 20
    args.block_size=400

    args.train_batch_size=32

    args.eval_batch_size = 32
    args.learning_rate = 2e-5
    args.max_grad_norm = 1.0
    args.seed= 99

    # 设置日志
    logging.basicConfig(format='%(asctime)s - %(levelname)s - %(name)s -   %(message)s',
                    datefmt='%m/%d/%Y %H:%M:%S', level=logging.INFO )
    
    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 检查CUDA是否可用
    args.n_gpu = torch.cuda.device_count()  # 获取GPU数量
    args.device = device  # 将设备信息传递给args
    logger.info("device: %s, n_gpu: %s", device, args.n_gpu)  # 打印设备信息
    
    # 设置随机种子
    set_seed(args.seed)
    
    # 构建模型
    tokenizer = RobertaTokenizer.from_pretrained(args.model_name_or_path)  # 加载分词器
    config = RobertaConfig.from_pretrained(args.model_name_or_path)  # 加载模型配置
    model = RobertaModel.from_pretrained(args.model_name_or_path)  # 加载预训练模型

    model = Model(model, config, tokenizer, args)  # 包装模型
    logger.info("Training/evaluation parameters %s", args)  # 打印参数信息

    model.to(args.device)  # 将模型移动到指定设备
    if args.n_gpu > 1:
        model = torch.nn.DataParallel(model)  # 如果有多个GPU，则使用DataParallel进行并行训练
            
    # 训练     
    if args.do_train:
        train_dataset = TextDataset(tokenizer, args, args.train_data_file)  # 创建训练数据集
        train(args, train_dataset, model, tokenizer)  # 开始训练
        
    # 测试          
    if args.do_test:
        checkpoint_prefix = 'checkpoint-best-f1/model.bin'  # 设置检查点文件名
        output_dir = os.path.join(args.output_dir, '{}'.format(checkpoint_prefix))  
        model_to_load = model.module if hasattr(model, 'module') else model  # 获取模型
        model_to_load.load_state_dict(torch.load(output_dir))  # 加载模型状态      
        result, _ = evaluate(args, model, tokenizer, args.test_data_file)  # 评估
        logger.info("***** Test results *****")
        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(round(result[key] * 100 if "map" in key else result[key], 4)))       
    
    # 检测
    if args.do_detect:
        checkpoint_prefix = 'checkpoint-best-f1/model.bin'  # 设置检查点文件名
        output_dir = os.path.join(args.output_dir, '{}'.format(checkpoint_prefix))  
        model_to_load = model.module if hasattr(model, 'module') else model  # 获取模型
        model_to_load.load_state_dict(torch.load(output_dir))  # 加载模型状态      
        result, indices, preds = detect(args, model, tokenizer, args.test_data_file)  # 检测
        logger.info("***** Detect results *****")
        for key in sorted(result.keys()):
            logger.info("  %s = %s", key, str(round(result[key] * 100 if "map" in key else result[key], 4)))
        dataframe = pd.DataFrame({"index": indices, "pred": preds})  # 创建DataFrame
        dataframe.to_csv(f'{args.output_dir.replace("saved_models", "detect")}.csv', sep=',', index=False)  # 保存结果为CSV文件

if __name__ == "__main__":
    main()  # 调用主函数

