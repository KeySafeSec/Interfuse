import argparse
import yaml
# import only the processing module for the main GNN model
from core_gnnmodel.model_handler import ModelHandler_GNN
from core_gnnmodel.model_handler_extend import ModelHandlerExtend_GNN
# remove core_submodel imports because submodels and ensembles are no longer used

import torch
import numpy as np
import os
import random


# import json # no longer needed
# import pandas as pd # no longer needed
# import gc # no longer needed

def set_random_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)


def train_gnn(config):
    print_config(config)
    set_random_seed(config['random_seed'])
    model = ModelHandler_GNN(config)
    model.train()


def test_gnn(config):
    print_config(config)
    set_random_seed(config['random_seed'])
    # ensure the pretrained-model path is correct
    if config['out_dir'] is not None:
        config['pretrained'] = config['out_dir']
        config['out_dir'] = None  # clear out_dir to avoid conflicts inside ModelHandlerExtend_GNN
    model_handle = ModelHandlerExtend_GNN(config)
    metrics = model_handle.test()
    return metrics


def get_config(config_path):
    with open(config_path, "r") as setting:
        config = yaml.load(setting, Loader=yaml.FullLoader)
    return config


def print_config(config):
    print("**************** MODEL CONFIGURATION ****************")
    for key in sorted(config.keys()):
        val = config[key]
        print(f"{key:24} -->   {val}")  # format the output for readability
    print("**************** MODEL CONFIGURATION ****************")


if __name__ == '__main__':
    # ========================== 1. load configuration (no command-line arguments required) ==========================
    # ⚠️ the configuration-file path is specified directly here
    config_file_path = "config/train_graph_hybrid.yml"
    print(f"👉 Loading configuration from: {config_file_path}")

    config = get_config(config_file_path)

    # ========================== 2. core path configuration ==========================
    # point to the generated dataset directory (dataset_v60_final_ready)
    # ⚠️ ensure this path is correct and the 'dataset_v60_final_ready' directory exists
    d2a_data_dir = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/zhangyao/proc/snapvuln2/snpvuln/snapvuln/dataset_v60_final_ready"

    # vocab and output directory configuration
    # prefer values defined in the config file; otherwise use defaults
    vocab_dir = os.path.dirname(config.get('saved_vocab_file', './vocabs/vocab.pkl'))
    out_dir = config.get('out_dir', './output/model')
    result_dir = os.path.join(os.path.dirname(out_dir), "results")

    # define common file paths for the new dataset (D2A)
    # as confirmed, these files contain only multi_graph
    new_train_file = os.path.join(d2a_data_dir, 'd2a_multi_train_cdata.jsonl.gz')
    new_valid_file = os.path.join(d2a_data_dir, 'd2a_multi_valid_cdata.jsonl.gz')
    new_test_file = os.path.join(d2a_data_dir, 'test_cdata_merged.jsonl.gz')
    # ==================================================================

    #### set mode (0: D2A training, 1: D2A testing) #####
    # ⚠️ tip: set to 0 for training first, then change to 1 for testing after training completes
    mode = 0

    ##################################################################################
    ################################## D2A (main GNN model) ###############################
    ##################################################################################

    ## Train for D2A ####
    if mode == 0:
        print("🚀 Starting Training Process for D2A Main GNN Model...")

        # GNN model (Main Model)
        config['trainset'] = new_train_file
        config['devset'] = new_valid_file
        config['testset'] = new_test_file
        config['saved_vocab_file'] = os.path.join(vocab_dir, "d2a_all_vocab.pkl")  # the GNN model typically uses a combined vocabulary
        config['out_dir'] = os.path.join(out_dir, "d2a_all/")  # model output directory
        config['result'] = os.path.join(result_dir, "d2a_all")  # result output directory

        train_gnn(config)

    ## test for D2A ####
    elif mode == 1:
        print("🚀 Starting Testing Process for D2A Main GNN Model...")

        # GNN model (Main Model)
        config['testset'] = new_test_file
        config['saved_vocab_file'] = os.path.join(vocab_dir, "d2a_all_vocab.pkl")
        config['out_dir'] = os.path.join(out_dir, "d2a_all/")
        config['result'] = os.path.join(result_dir, "d2a_all")

        test_gnn(config)

    # ⚠️ tip: the Juliet section has been removed; add it back from the earlier code if needed
    # if the Juliet data also contain only multi_graph, only the main GNN model can be trained
