import argparse
import yaml
# 仅导入 GNN 主模型的处理模块
from core_gnnmodel.model_handler import ModelHandler_GNN
from core_gnnmodel.model_handler_extend import ModelHandlerExtend_GNN
# 删除了 core_submodel 相关导入，因为不再使用子模型和集成

import torch
import numpy as np
import os
import random


# import json # 不再需要
# import pandas as pd # 不再需要
# import gc # 不再需要

def set_random_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)


def train_gnn(config):
    print_config(config)
    set_random_seed(config['random_seed'])
    model = ModelHandler_GNN(config)
    model.train()


def test_gnn(config):
    print_config(config)
    set_random_seed(config['random_seed'])
    # 确保加载预训练模型的路径正确
    if config['out_dir'] is not None:
        config['pretrained'] = config['out_dir']
        config['out_dir'] = None  # 清空 out_dir 以避免ModelHandlerExtend_GNN内部冲突
    model_handle = ModelHandlerExtend_GNN(config)
    metrics = model_handle.test()
    return metrics


def get_config(config_path):
    with open(config_path, "r") as setting:
        config = yaml.load(setting, Loader=yaml.FullLoader)
    return config


def print_config(config):
    print("**************** MODEL CONFIGURATION ****************")
    for key in sorted(config.keys()):
        val = config[key]
        print(f"{key:24} -->   {val}")  # 格式化输出，更整齐
    print("**************** MODEL CONFIGURATION ****************")


if __name__ == '__main__':
    # ========================== 1. 加载配置 (无需命令行参数) ==========================
    # ⚠️ 这里直接指定了你的配置文件路径
    config_file_path = "config/train_graph_hybrid.yml"
    print(f"👉 Loading configuration from: {config_file_path}")

    config = get_config(config_file_path)

    # ========================== 2. 核心路径配置 ==========================
    # 指向你生成的新数据集目录 (dataset_v60_final_ready)
    # ⚠️ 请确保这个路径是正确的，并且 'dataset_v60_final_ready' 文件夹存在
    d2a_data_dir = "/media/server207/aba0a710-3866-4f68-92c9-ddd95f86d712/server207/zhangyao/proc/snapvuln2/snpvuln/snapvuln/dataset_v60_final_ready"

    # vocab 和 output 目录配置
    # 优先使用 config 文件中的定义，如果没有则使用默认值
    vocab_dir = os.path.dirname(config.get('saved_vocab_file', './vocabs/vocab.pkl'))
    out_dir = config.get('out_dir', './output/model')
    result_dir = os.path.join(os.path.dirname(out_dir), "results")

    # 定义通用的新数据集文件路径 (D2A)
    # 根据你的确认，这些文件只包含 multi_graph
    new_train_file = os.path.join(d2a_data_dir, 'd2a_multi_train_cdata.jsonl.gz')
    new_valid_file = os.path.join(d2a_data_dir, 'd2a_multi_valid_cdata.jsonl.gz')
    new_test_file = os.path.join(d2a_data_dir, 'test_cdata_merged.jsonl.gz')
    # ==================================================================

    #### 设置模式 (0: D2A训练, 1: D2A测试) #####
    # ⚠️ 提示：先设为 0 运行训练，训练完后再改成 1 运行测试
    mode = 0

    ##################################################################################
    ################################## D2A (GNN 主模型) ###############################
    ##################################################################################

    ## Train for D2A ####
    if mode == 0:
        print("🚀 Starting Training Process for D2A Main GNN Model...")

        # GNN model (Main Model)
        config['trainset'] = new_train_file
        config['devset'] = new_valid_file
        config['testset'] = new_test_file
        config['saved_vocab_file'] = os.path.join(vocab_dir, "d2a_all_vocab.pkl")  # GNN 模型通常用一个综合的词表
        config['out_dir'] = os.path.join(out_dir, "d2a_all/")  # 模型输出目录
        config['result'] = os.path.join(result_dir, "d2a_all")  # 结果输出目录

        train_gnn(config)

    ## test for D2A ####
    elif mode == 1:
        print("🚀 Starting Testing Process for D2A Main GNN Model...")

        # GNN model (Main Model)
        config['testset'] = new_test_file
        config['saved_vocab_file'] = os.path.join(vocab_dir, "d2a_all_vocab.pkl")
        config['out_dir'] = os.path.join(out_dir, "d2a_all/")
        config['result'] = os.path.join(result_dir, "d2a_all")

        test_gnn(config)

    # ⚠️ 提示：Juliet 部分已移除，如果你需要，可以参考之前的代码自行添加
    # 并且如果你的 Juliet 数据也只包含 multi_graph，那么也只能训练 GNN 主模型。
